import crypto from "crypto"
import axios from "axios"

class savetube {
  constructor() {
    this.ky = 'C5D58EF67A7584E4A29F6C35BBC4EB12'
    this.m = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/
    this.is = axios.create({
      headers: {
        'content-type': 'application/json',
        'origin': 'https://yt.savetube.me',
        'user-agent': 'Mozilla/5.0 (Android)'
      }
    })
  }

  async decrypt(enc) {
    const sr = Buffer.from(enc,'base64')
    const ky = Buffer.from(this.ky,'hex')
    const iv = sr.slice(0,16)
    const dt = sr.slice(16)
    const dc = crypto.createDecipheriv('aes-128-cbc', ky, iv)
    return JSON.parse(Buffer.concat([dc.update(dt), dc.final()]).toString())
  }

  async getCdn() {
    const r = await this.is.get("https://media.savetube.vip/api/random-cdn")
    return r.data.cdn
  }

  async download(url) {
    const id = url.match(this.m)?.[3]
    if (!id) return null

    const cdn = await this.getCdn()
    const info = await this.is.post(`https://${cdn}/v2/info`, {
      url: `https://www.youtube.com/watch?v=${id}`
    })

    const dec = await this.decrypt(info.data.data)
    const dl = await this.is.post(`https://${cdn}/download`, {
      id,
      downloadType: 'audio',
      quality: '128',
      key: dec.key
    })

    return {
      title: dec.title,
      thumb: dec.thumbnail || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
      duration: dec.duration,
      dl: dl.data.data.downloadUrl,
      url: `https://www.youtube.com/watch?v=${id}`
    }
  }
}

let handler = async (m, { KazzTzy, text, usedPrefix, command }) => {
  if (!text) return m.reply(`${usedPrefix + command} judul lagu`)

  try {
    await m.react("⏳")

    const q = await axios.get(
      `https://www.youtube.com/results?search_query=${encodeURIComponent(text)}`,
      { headers: { 'User-Agent': 'Mozilla/5.0' } }
    )

    const id = q.data.match(/"videoId":"([^"]+)"/)?.[1]
    if (!id) throw 0

    const st = new savetube()
    const r = await st.download(`https://www.youtube.com/watch?v=${id}`)
    if (!r?.dl) throw 0

    await KazzTzy.sendMessage(
      m.chat,
      {
        audio: { url: r.dl },
        mimetype: "audio/mpeg",
        fileName: `${r.title}.mp3`,
        contextInfo: {
          externalAdReply: {
            title: r.title,
            body: "MP3 Download",
            mediaType: 2,
            thumbnailUrl: r.thumb,
            sourceUrl: r.url
          }
        }
      },
      { quoted: m }
    )

    await m.react("✅")
  } catch {
    await m.react("❌")
    m.reply("❌ Gagal mengambil audio")
  }
}

handler.help = ["play <judul lagu>"]
handler.tags = ["music"]
handler.command = /^(play2|song|music)$/i
handler.limit = true

export default handler