import axios from 'axios'

const veniceAI = async (question) => {
  const { data } = await axios.post(
    'https://outerface.venice.ai/api/inference/chat',
    {
      requestId: 'nekorinn',
      modelId: 'dolphin-3.0-mistral-24b',
      prompt: [{ content: question, role: 'user' }],
      systemPrompt: 'Jawablah menggunakan Bahasa Indonesia yang baik dan benar.',
      conversationType: 'text',
      temperature: 0.8,
      webEnabled: true,
      topP: 0.9,
      isCharacter: false,
      clientProcessingTime: 15
    },
    {
      headers: {
        accept: '*/*',
        'content-type': 'application/json',
        origin: 'https://venice.ai',
        referer: 'https://venice.ai/',
        'user-agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
        'x-venice-version': 'interface@20250523.214528+393d253'
      }
    }
  )

  const chunks = data
    .split('\n')
    .filter(v => v.trim())
    .map(v => JSON.parse(v))

  return chunks.map(v => v.content).join('')
}

let handler = async (m, { text }) => {
  if (!text) return m.reply('Masukkan pertanyaan.')

  try {
    await m.react('⏳')
    const res = await veniceAI(text)
    await m.reply(res)
  } catch (e) {
    m.reply('Terjadi kesalahan.')
  }
}

handler.command = ['venice', 'ai']
handler.help = ['venice <teks>']
handler.tags = ['ai']

export default handler