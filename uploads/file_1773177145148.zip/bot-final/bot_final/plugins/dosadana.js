import figlet from "figlet";
import { promisify } from "util";

const figletAsync = promisify(figlet.text);

let handler = async (m, { usedPrefix, command, text }) => {
    if (!text) return m.reply(`Contoh penggunaan:\n${usedPrefix + command} Halo`);

    try {
        const ascii = await figletAsync(text, { horizontalLayout: 'default', verticalLayout: 'default' });
        await m.reply("```\n" + ascii + "\n```");
    } catch (e) {
        await m.reply("❌ Terjadi kesalahan saat membuat ASCII art");
    }
};

handler.help = ["ascii"];
handler.tags = ["maker"];
handler.command = /^ascii$/i;
handler.register = true;
handler.limit = true;

export default handler;