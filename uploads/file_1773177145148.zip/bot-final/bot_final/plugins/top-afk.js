
let handler = async (m, { KazzTzy, usedPrefix, command }) => {
  const users = global.db.data.users || {};
  const now   = Date.now();

  let list = Object.entries(users)
    .filter(([, u]) => u?.afk && u.afk > 0)
    .map(([jid, u]) => ({
      jid,
      name     : KazzTzy.getName(jid) || jid.split("@")[0],
      duration : now - u.afk,
      reason   : u.afkReason || "-",
    }))
    .sort((a, b) => b.duration - a.duration)
    .slice(0, 10);

  if (!list.length) return m.reply("𖣂 Belum ada yang AFK saat ini.");

  const fmtTime = (ms) => {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const h = Math.floor(m / 60);
    const d = Math.floor(h / 24);
    if (d > 0)  return `${d}h ${h % 24}j ${m % 60}m`;
    if (h > 0)  return `${h}j ${m % 60}m ${s % 60}d`;
    if (m > 0)  return `${m}m ${s % 60}d`;
    return `${s}d`;
  };

  const rows = list.map((u, i) =>
    `𖣂 #${i + 1} ${u.name}\n    Durasi : ${fmtTime(u.duration)}\n    Alasan : ${u.reason}`
  ).join("\n\n");

  await KazzTzy.sendMessage(m.chat, {
    text: [
      "╔══[ TOP AFK TERLAMA ]══╗",
      "",
      rows,
      "",
      "╚════════════════════════╝",
    ].join("\n"),
  }, { quoted: m });
};

handler.help    = ["topafk"];
handler.tags    = ["main"];
handler.command = /^topafk$/i;

export default handler;
