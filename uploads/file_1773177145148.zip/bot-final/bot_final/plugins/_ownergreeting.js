export async function before(m) {
    if (!m.isGroup) return false;
    if (m.fromMe) return false;
    
    const owners = global.owner.map(([n]) => n + "@s.whatsapp.net");
    const isOwnerMessage = owners.includes(m.sender);
    
    if (!isOwnerMessage) return false;
    
    const chats = global.db.data.chats;
    if (!chats[m.chat]) chats[m.chat] = {};
    
    const chat = chats[m.chat];
    const now = Date.now();
    const cooldown = 5 * 60 * 1000;
    
    if (chat.lastOwnerGreeting && (now - chat.lastOwnerGreeting) < cooldown) {
        return false;
    }
    
    chat.lastOwnerGreeting = now;
    
    const greetings = [
        "👑 King KazzTzy Datang Jir",
        "🔥 Raja Bot Telah Tiba!",
        "⚡ Owner Legendaris Hadir!",
        "💎 KazzTzy The Great Is Here",
        "🌟 Semua Hormat! Owner Datang",
        "👾 Big Boss Arrived!"
    ];
    
    const randomGreeting = greetings[Math.floor(Math.random() * greetings.length)];
    
    await this.sendMessage(m.chat, {
        text: randomGreeting,
        mentions: [m.sender]
    }, { quoted: m });
    
    return false;
}
