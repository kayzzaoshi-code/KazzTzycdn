import { createHash } from 'crypto';

let handler = async (m) => {
    let user = global.db.data.users[m.sender];
    if (!user.registered) return m.reply('Kamu belum registrasi! Gunakan .daftar <nama>.<umur>');

    const pp = await KazzTzy.profilePictureUrl(m.sender, 'image', 'buffer');
    let sn = createHash('md5').update(m.sender).digest('hex');

    let cap = `
─── LIMIT INFO ───
• Name: ${user.name}
• Limit: ${user.limit || 0}
• Serial: ${sn}
`;

    await KazzTzy.sendMessage(
        m.chat,
        {
            text: cap,
            contextInfo: {
                isForwarded: true,
                forwarded: true,
                externalAdReply: {
                    title: global.namebot,
                    body: '',
                    thumbnail: pp,
                    mediaType: 1,
                    renderLargerThumbnail: false,
                },
            },
        },
        { quoted: m }
    );
};

handler.help = ['ceklimit', 'limit'];
handler.tags = ['xp'];
handler.command = /^(ceklimit|limit)$/i;

export default handler;