import { proto, generateWAMessage, areJidsSameUser } from 'baileys';
import fs from 'fs';

const allTags = {
	maker: 'Maker',
	sticker: 'Sticker',
	rpg: 'RPG',
	anime: 'Anime',
	random: 'Random',
	downloader: 'Downloader',
	tools: 'Tools',
	asupan: 'Asupan',
	search: 'Search',
	ai: 'AI',
	group: 'Group',
	nsfw: 'NSFW',
	game: 'Game',
	owner: 'Owner',
};



const handler = async (m, { KazzTzy, usedPrefix: _p, isOwner, args }) => {
	const plugins = Object.values(global.plugins).filter((p) => !p.disabled);
	const help = plugins.map((p) => ({
		help: Array.isArray(p.help) ? p.help : [p.help],
		tags: Array.isArray(p.tags) ? p.tags : [p.tags],
		prefix: 'customPrefix' in p,
		limit: p.limit ? '[L]' : '',
		premium: p.premium ? '[P]' : '',
		owner: p.owner ? '[O]' : '',
	}));

	const teks = (args[0] || '').toLowerCase().trim();
	const tagKeys = Object.keys(allTags).filter((k) => isOwner || k !== 'owner');
	const botName = global.namebot || 'Z4Z';
	const version = global.version || '1.0.0';
		const totalFeature = plugins.filter(p => p.tags).length;
	const totalCmd = plugins.flatMap(p => Array.isArray(p.help) ? p.help : [p.help]).filter(Boolean).length;

	const fakeNewsletter = {
		key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: '0@s.whatsapp.net' },
		message: {
			newsletterAdminInviteMessage: {
				newsletterJid: global.idch || '120363426225124869@newsletter',
				newsletterName: botName,
				caption: `${global.namaOwner || 'Owner'}`,
				inviteExpiration: '1757494779',
			},
		},
	};

	const fakePoll = {
		key: {
			fromMe: false,
			participant: '0@s.whatsapp.net',
			...(m.chat ? { remoteJid: '13135550202@s.whatsapp.net' } : {}),
		},
		message: {
			pollCreationMessageV3: {
				name: `${global.namaOwner || 'Owner'}`,
				options: [{ optionName: '1' }, { optionName: '2' }],
				selectableOptionsCount: 1,
			},
		},
	};

	const sendDoc = (caption) => KazzTzy.sendMessage(m.chat, {
		document: fs.readFileSync('./media/menu.jpg'),
		mimetype: 'application/pdf',
		fileLength: 99999999999999,
		fileName: `© ${botName}`,
		jpegThumbnail: fs.readFileSync('./media/menu.jpg'),
		caption,
		contextInfo: {
			forwardingScore: 999,
			isForwarded: true,
			quotedMessage: fakeNewsletter.message,
			forwardedNewsletterMessageInfo: {
				newsletterJid: global.idch || '120363426225124869@newsletter',
				newsletterName: botName,
			},
			externalAdReply: {
				title: `© ${botName}`,
				body: `version • ${version}`,
				thumbnailUrl: 'https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1772657255245.jpeg',
				sourceUrl: 'https://whatsapp.com/channel/0029VbCEBa77j6g2KN3NYB3A',
				mediaType: 1,
				renderLargerThumbnail: true,
				previewType: 0,
			},
		},
	}, { quoted: fakePoll });

	if (teks === 'all') {
		const allItems = tagKeys.map((tag) => {
			const items = help
				.filter((p) => p.tags.includes(tag))
				.flatMap((p) => p.help.map((h) => `${p.prefix ? h : `${_p}${h}`} ${[p.limit, p.premium, p.owner].join(' ')}`.trim()))
				.join('\n');
			return `༺ ${allTags[tag]} ༺\n${items}`;
		}).join('\n\n');
		return sendDoc(allItems);
	}

	if (teks && tagKeys.includes(teks)) {
		const items = help
			.filter((p) => p.tags.includes(teks))
			.flatMap((p) => p.help.map((h) => `${p.prefix ? h : `${_p}${h}`} ${[p.limit, p.premium, p.owner].join(' ')}`.trim()))
			.join('\n');
		return sendDoc(`༺ ${allTags[teks]} ༺\n\n${items || 'Tidak ada command'}`);
	}

	const katList = tagKeys.map(k => `༺ ${_p}menu ${k}`).join('\n');
	const caption = [
		`——[ ABOUT BOT ]——`,
		``,
		`༺ Nama-Bot  : © ${botName}`,
		`༺ Version   : ${version}`,		`༺ Feature   : ${totalFeature}`,
		`༺ Commands  : ${totalCmd}`,
		``,
		`——[ KATEGORI ]——`,
		``,
		katList,
		``,
		`༺ ${_p}menu all — Semua fitur`,
	].join('\n');

	return sendDoc(caption);
};

handler.all = async function (m, chatUpdate) {
	if (m.isBaileys) return;
	if (!m.message) return;
	if (!(m.message.buttonsResponseMessage || m.message.templateButtonReplyMessage || m.message.listResponseMessage || m.message.interactiveResponseMessage || m.message.pollUpdateMessage)) return;

	let id = '';
	if (m.mtype === 'buttonsResponseMessage') {
		id = m.message.buttonsResponseMessage.selectedButtonId;
	} else if (m.mtype === 'listResponseMessage') {
		id = m.message.listResponseMessage.singleSelectReply.selectedRowId;
	} else if (m.mtype === 'templateButtonReplyMessage') {
		id = m.message.templateButtonReplyMessage.selectedId;
	} else if (m.mtype === 'interactiveResponseMessage') {
		try {
			const parsed = JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson);
			id = parsed.id || parsed.rowId || parsed.selected_row_id || '';
			if (!id && parsed.selection) id = parsed.selection.rowId || '';
		} catch {
			id = m.msg?.nativeFlowResponseMessage?.paramsJson || '';
		}
	} else if (m.mtype === 'messageContextInfo') {
		id = m.message.buttonsResponseMessage?.selectedButtonId
			|| m.message.listResponseMessage?.singleSelectReply.selectedRowId
			|| m.text || '';
	}
	if (!id) return;

	let messages = await generateWAMessage(m.chat, { text: id, mentions: m.mentionedJid }, {
		userJid: this.user.jid,
		quoted: m.quoted && m.quoted.fakeObj,
	});
	messages.key.remoteJid = m.chat;
	messages.key.fromMe = areJidsSameUser(m.sender, this.user.id);
	messages.key.id = m.key.id;
	messages.pushName = m.pushName;
	if (m.isGroup) messages.key.participant = messages.participant = m.sender;
	this.ev.emit('messages.upsert', {
		...chatUpdate,
		messages: [proto.WebMessageInfo.create(messages)].map((v) => ((v.KazzTzy = this), v)),
		type: 'append',
	});
};

handler.help = ['menu [all|kategori]'];
handler.command = /^(menu|help|\?)$/i;
handler.exp = 3;
export default handler;
