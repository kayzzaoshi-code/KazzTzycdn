import axios from "axios"
import cheerio from "cheerio"

async function sendAIReply(KazzTzy, m, text) {
  return KazzTzy.sendMessage(m.chat, {
    text: String(text),
    mentions: [m.sender],
    contextInfo: {
      externalAdReply: {
        title: "Z4Z Bot",
        body: "KazzTzy",
        thumbnailUrl: "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1772016271450.jpeg",
        sourceUrl: global.source || "https://wa.me/6285795269956",
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m });
}

async function letmeGPT(text) {
    if (!text) throw new Error("Parameter q diperlukan")

    const { data } = await axios.get(
        "https://letmegpt.com/search",
        {
            params: { q: text },
            headers: {
                "User-Agent": "Mozilla/5.0",
                Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                Referer: "https://letmegpt.com/"
            }
        }
    )

    const $ = cheerio.load(data)
    const result = $("#gptans").text().trim()

    if (!result) throw new Error("Gagal mendapatkan respon.")

    return result
}

let handler = async (m, { text }) => {
    const input = m.quoted ? m.quoted.text : text
    if (!input) return m.reply("Masukkan pertanyaan.")

    try {
        await m.react("⏳")
        const res = await letmeGPT(input)
        await m.reply(res)
        await m.react("✅")
    } catch (err) {
        await m.react("❌")
        m.reply("Error:\n" + err.message)
    }
}

handler.help = ["letmegpt <text>"]
handler.tags = ["ai"]
handler.command = /^letmegpt$/i
handler.limit = true

export default handler