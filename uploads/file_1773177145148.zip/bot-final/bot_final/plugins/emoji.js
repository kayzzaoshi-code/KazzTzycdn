import fs from "fs"
import path from "path"
import { Sticker, StickerTypes } from "wa-sticker-formatter"

function toUnified(str) {
  return Array.from(str)
    .map(e => e.codePointAt(0).toString(16))
    .join("-")
    .toLowerCase()
}

let handler = async (m, { KazzTzy, text }) => {
  try {
    await m.react("⏳")
    if (!text) return m.reply("Masukkan emoji")

    const emoji = text.trim()
    const unified = toUnified(emoji)

    const filePath = path.join(
      process.cwd(),
      "node_modules",
      "emoji-datasource-apple",
      "img",
      "apple",
      "64",
      `${unified}.png`
    )

    if (!fs.existsSync(filePath)) {
      await m.react("❌")
      return m.reply("Emoji tidak tersedia di Apple dataset.")
    }

    const buffer = fs.readFileSync(filePath)

    const sticker = new Sticker(buffer, {
      pack: global.packname || "KazzTzy",
      author: global.author || "Bot",
      type: StickerTypes.FULL,
      quality: 100
    })

    const stickerBuffer = await sticker.toBuffer()

    await KazzTzy.sendMessage(
      m.chat,
      { sticker: stickerBuffer },
      { quoted: m }
    )

    await m.react("✅")

  } catch (e) {
    await m.react("❌")
    m.reply("Gagal memproses emoji.")
  }
}

handler.command = /^emoji$/i
handler.tags = ["sticker"]
handler.help = ["emoji <emoji>"]

export default handler