let handler = async (m, { KazzTzy, usedPrefix }) => {
    let user = global.db.data.users[m.sender];
    if (!user.registered) return m.reply('Kamu belum registrasi! Gunakan .daftar <nama>.<umur>');

    let now = Date.now();
    let timer = now - (user.lastTaxi || 0);
    if (user.lastTaxi && timer < 120000) return m.reply(`Tunggu ${Math.ceil((120000 - timer)/1000)} detik lagi`);

    let money = Math.floor(Math.random() * 5000) + 1000;
    let limit = Math.floor(Math.random() * 5) + 1;
    let exp = Math.floor(Math.random() * 50) + 10;
    let gagal = Math.floor(Math.random() * 100) < 25;

    let stage1 = `
🚶⬛⬛⬛⬛⬛⬛⬛⬛⬛
⬛⬜⬜⬜⬛⬜⬜⬜⬛⬛
⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛
🏘️🏘️🏘️🏘️🌳  🌳 🏘️       🚕

Mengambil Orderan....
`;

    let stage2 = `
🚶⬛⬛⬛⬛⬛🚐⬛⬛⬛🚓🚚
🚖⬜⬜⬜⬛⬜⬜⬜🚓⬛🚑
⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛🚙
🏘️🏘️🏢️🌳  🌳 🏘️  🏘️🏡

Mengantar Ke Tujuan.....
`;

    let stage3 = `
⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛🚓
⬛⬜🚗⬜⬜⬛⬜🚐⬜⬜⬛🚙🚚🚑
⬛⬛⬛⬛🚒⬛⬛⬛⬛⬛⬛🚚
🏘️🏘️🏘️🏘️🌳  🌳 🏘️

Sampai Tujuan....
`;

    let stage4Success = `
*—[ Hasil Taxi ${user.name} ]—*
➕ 💹 Money = [ ${money} ]
➕ ✨ Limit = [ ${limit} ]
➕ ⚡ Exp = [ ${exp} ]
➕ 😍 Order Selesai = +1
➕ 📥 Total Order Sebelumnya : ${user.order || 0}
`;

    let stage4Fail = `
❌ Penumpang Kabur...
➖ 💹 Money -1000
`;

    const { key } = await m.reply(`Mengambil Orderan...`);

    setTimeout(() => m.edit(stage1, key), 0);
    setTimeout(() => m.edit(stage2, key), 10000);
    setTimeout(() => m.edit(stage3, key), 20000);
    setTimeout(() => {
        if (gagal) {
            user.money = Math.max((user.money || 0) - 1000, 0);
            m.edit(stage4Fail, key);
            return;
        }

        user.money = (user.money || 0) + money;
        user.limit = (user.limit || 0) + limit;
        user.exp = (user.exp || 0) + exp;
        user.order = (user.order || 0) + 1;

        m.edit(stage4Success, key);
    }, 30000);

    user.lastTaxi = Date.now();
};

handler.help = ['taxi'];
handler.tags = ['game'];
handler.command = /^(taxi)$/i;

export default handler;