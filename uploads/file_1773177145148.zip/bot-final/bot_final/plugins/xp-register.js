import { createHash } from 'crypto';

let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i;

let handler = async function (m, { text, usedPrefix }) {
    let user = global.db.data.users[m.sender];
    const pp = await KazzTzy.profilePictureUrl(m.sender, 'image', 'buffer');

    if (user.registered === true) throw `You Have Already Registered In The Database, Do You Want To Re-Register? *${usedPrefix}unreg*`;
    if (!Reg.test(text)) return m.reply(`Masukkan Nama.Umur kamu\nContoh: ${usedPrefix}daftar Tio.17`);

    let [_, name, _splitter, age] = text.match(Reg);
    if (!name) throw 'Nama Tidak Boleh Kosong';
    if (!age) throw 'Umur Tidak Boleh Kosong';

    age = parseInt(age);
    if (age > 50) throw 'Tua Banget amjir';
    if (age < 12) throw 'Esempe Dilarang masuk';

    user.name = name.trim();
    user.age = age;
    user.regTime = Date.now();
    user.registered = true;
    user.axe = 1;
    user.axedurability = 30;
    user.pickaxe = 1;
    user.pickaxedurability = 40;

    let sn = createHash('md5').update(m.sender).digest('hex');

    let cap = `
─── USER INFO ───
• Name: ${name}
• Age: ${age} Years
• Status: Success
• Serial: ${sn}

── STARTER PACK ──
• Axe: 1 (30 Durability)
• Pickaxe: 1 (40 Durability)
`;

    await KazzTzy.sendMessage(
        m.chat,
        {
            text: cap,
            contextInfo: {
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: global.idch || '120363426225124869@newsletter',
                    newsletterName: global.namebot,
                },
                externalAdReply: {
                    title: global.namebot,
                    body: '',
                    thumbnailUrl: global.thumbnail,
                    sourceUrl: global.source,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                },
            },
        },
        { quoted: m }
    );
};

handler.help = ['daftar <nama>.<umur>'];
handler.tags = ['xp'];
handler.command = /^(daftar|verify|reg(ister)?)$/i;

export default handler;