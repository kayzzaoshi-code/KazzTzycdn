let handler = async (m, { KazzTzy, usedPrefix, command, args, text }) => {
    let user = global.db.data.users[m.sender];
    
    if (!user.bank) user.bank = 0;
    if (!user.atm) user.atm = 0;
    
    const subCmd = args[0]?.toLowerCase();
    
    if (!subCmd) {
        const bankText = `
╔══════════════╗
    🏦 BANK RPG 🏦
╚══════════════╝

💰 Saldo Bank: ${user.bank.toLocaleString()}
💳 ATM: ${user.atm.toLocaleString()}
💵 Cash: ${user.money.toLocaleString()}

━━━━━━━━━━━━━━
📋 MENU BANK:
━━━━━━━━━━━━━━

${usedPrefix}bank deposit <jumlah>
  → Setor uang ke bank

${usedPrefix}bank withdraw <jumlah>
  → Ambil uang dari bank

${usedPrefix}bank transfer @user <jumlah>
  → Transfer ke user lain

${usedPrefix}bank upgrade
  → Upgrade ATM limit

${usedPrefix}bank info
  → Info detail bank

━━━━━━━━━━━━━━
💡 Uang di bank aman dari rampok!
━━━━━━━━━━━━━━
        `.trim();
        return m.reply(bankText);
    }
    
    if (subCmd === "deposit" || subCmd === "nabung" || subCmd === "setor") {
        let amount = parseInt(args[1]);
        
        if (!amount || isNaN(amount)) return m.reply("❌ Masukkan jumlah yang valid!");
        if (amount < 1) return m.reply("❌ Minimal deposit 1!");
        if (user.money < amount) return m.reply(`❌ Uang cash kamu hanya ${user.money.toLocaleString()}`);
        
        user.money -= amount;
        user.bank += amount;
        
        return m.reply(`✅ Berhasil deposit!\n\n💰 ${amount.toLocaleString()} masuk ke bank\n🏦 Saldo bank: ${user.bank.toLocaleString()}`);
    }
    
    if (subCmd === "withdraw" || subCmd === "tarik" || subCmd === "wd") {
        let amount = parseInt(args[1]);
        
        if (!amount || isNaN(amount)) return m.reply("❌ Masukkan jumlah yang valid!");
        if (amount < 1) return m.reply("❌ Minimal withdraw 1!");
        if (user.bank < amount) return m.reply(`❌ Saldo bank kamu hanya ${user.bank.toLocaleString()}`);
        
        const maxWithdraw = user.atm || 100000;
        if (amount > maxWithdraw) return m.reply(`❌ ATM limit: ${maxWithdraw.toLocaleString()}\n\nUpgrade ATM untuk tarik lebih banyak!\n${usedPrefix}bank upgrade`);
        
        user.bank -= amount;
        user.money += amount;
        
        return m.reply(`✅ Berhasil withdraw!\n\n💵 ${amount.toLocaleString()} masuk ke cash\n🏦 Sisa bank: ${user.bank.toLocaleString()}`);
    }
    
    if (subCmd === "transfer" || subCmd === "tf") {
        let who = m.mentionedJid && m.mentionedJid[0] 
                  ? m.mentionedJid[0] 
                  : m.quoted ? m.quoted.sender : null;
        
        if (!who) return m.reply("❌ Tag user yang mau di-transfer!");
        if (who === m.sender) return m.reply("❌ Tidak bisa transfer ke diri sendiri!");
        
        let amount = parseInt(args[2] || args[1]);
        if (!amount || isNaN(amount)) return m.reply("❌ Masukkan jumlah yang valid!");
        if (amount < 1) return m.reply("❌ Minimal transfer 1!");
        if (user.bank < amount) return m.reply(`❌ Saldo bank kamu hanya ${user.bank.toLocaleString()}`);
        
        let target = global.db.data.users[who];
        if (!target) return m.reply("❌ User tidak ditemukan di database!");
        if (!target.bank) target.bank = 0;
        
        const fee = Math.floor(amount * 0.01);
        const totalDeduct = amount + fee;
        
        if (user.bank < totalDeduct) return m.reply(`❌ Butuh ${totalDeduct.toLocaleString()} (transfer + fee 1%)`);
        
        user.bank -= totalDeduct;
        target.bank += amount;
        
        await m.reply(`✅ Transfer berhasil!\n\n💸 Transfer: ${amount.toLocaleString()}\n📋 Fee: ${fee.toLocaleString()}\n🏦 Sisa bank: ${user.bank.toLocaleString()}`);
        
        await this.sendMessage(who, {
            text: `💰 Kamu menerima transfer!\n\n📨 Dari: @${m.sender.split('@')[0]}\n💵 Jumlah: ${amount.toLocaleString()}\n🏦 Saldo bank: ${target.bank.toLocaleString()}`,
            mentions: [m.sender]
        });
    }
    
    if (subCmd === "upgrade") {
        const upgradeLevels = [
            { level: 1, limit: 100000, cost: 0 },
            { level: 2, limit: 500000, cost: 50000 },
            { level: 3, limit: 1000000, cost: 100000 },
            { level: 4, limit: 5000000, cost: 500000 },
            { level: 5, limit: 10000000, cost: 1000000 },
            { level: 6, limit: 50000000, cost: 5000000 },
            { level: 7, limit: 100000000, cost: 10000000 },
            { level: 8, limit: 999999999, cost: 50000000 }
        ];
        
        const currentLimit = user.atm || 100000;
        const currentLevel = upgradeLevels.find(l => l.limit === currentLimit);
        const nextLevel = upgradeLevels.find(l => l.limit > currentLimit);
        
        if (!nextLevel) return m.reply("🎉 ATM kamu sudah level MAX!");
        
        if (user.money < nextLevel.cost) {
            return m.reply(`❌ Butuh ${nextLevel.cost.toLocaleString()} cash untuk upgrade!\n\n💳 Upgrade ke level ${nextLevel.level}\n📊 Limit withdraw: ${nextLevel.limit.toLocaleString()}`);
        }
        
        user.money -= nextLevel.cost;
        user.atm = nextLevel.limit;
        
        return m.reply(`✅ ATM berhasil di-upgrade!\n\n📈 Level ${nextLevel.level}\n💳 Limit withdraw: ${nextLevel.limit.toLocaleString()}\n💰 Biaya: ${nextLevel.cost.toLocaleString()}`);
    }
    
    if (subCmd === "info") {
        const atmLimit = user.atm || 100000;
        const bankInterest = 0.001;
        const dailyInterest = Math.floor(user.bank * bankInterest);
        
        return m.reply(`
╔══════════════╗
    🏦 INFO BANK 🏦
╚══════════════╝

💰 Saldo Bank: ${user.bank.toLocaleString()}
💳 ATM Limit: ${atmLimit.toLocaleString()}
💵 Cash: ${user.money.toLocaleString()}

━━━━━━━━━━━━━━
📊 DETAIL:
━━━━━━━━━━━━━━

📈 Bunga harian: ${dailyInterest.toLocaleString()}
🔒 Aman dari rampok: Ya
💸 Transfer fee: 1%

━━━━━━━━━━━━━━
💡 Tips: Nabung uang biar aman!
━━━━━━━━━━━━━━
        `.trim());
    }
};

handler.help = ["bank"];
handler.tags = ["rpg"];
handler.command = /^(bank|atm)$/i;
handler.register = true;

export default handler;
