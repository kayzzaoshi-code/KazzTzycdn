import axios from "axios";

let handler = async (m, { KazzTzy, text }) => {
    try {
        await m.react(global.react || "⏳");

        if (!text) return m.reply("Contoh:\n.aio https://link");

        const res = await axios.get(
            `https://savevideoid.vercel.app/api/download?url=${encodeURIComponent(text)}`
        );

        const data = res.data;
        if (!data.success) return m.reply("❌ Gagal download!");

        const results = data.results || [];
        if (!results.length) return m.reply("❌ Media tidak ditemukan");

        for (let r of results) {
            let videoUrl = r.hd_url || r.download_url;
            let audioUrl = r.music;
            let thumb = r.thumbnail;

            let caption =
`📥 *AIO Downloader*

🌐 Platform: ${data.platform}
📌 Title: ${r.title || "-"}
⏱ Duration: ${r.duration || "-"} sec
🔗 Source: ${data.original_url}`;

            if (videoUrl) {
                await KazzTzy.sendMessage(m.chat, {
                    video: { url: videoUrl },
                    mimetype: "video/mp4",
                    caption
                }, { quoted: m });
            }

            if (audioUrl) {
                await KazzTzy.sendMessage(m.chat, {
                    audio: { url: audioUrl },
                    mimetype: "audio/mpeg",
                    fileName: "aio.mp3"
                }, { quoted: m });
            }

            if (thumb) {
                await KazzTzy.sendMessage(m.chat, {
                    image: { url: thumb },
                    caption: "🖼 Thumbnail"
                }, { quoted: m });
            }
        }

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply("❌ Error AIO Downloader");
    }
};

handler.help = ["aio"];
handler.tags = ["downloader"];
handler.command = /^aio$/i;
handler.register = true;
handler.limit = true;

export default handler;