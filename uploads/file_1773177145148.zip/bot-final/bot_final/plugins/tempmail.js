import axios from "axios";

const BASE_URL = "https://multi-tools.cloud";
const SESSION = "d2f4mr5d7gmgmkom026ek9iqpk";

const headers = {
  accept: "*/*",
  "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
  "x-requested-with": "XMLHttpRequest",
  referer: "https://multi-tools.cloud/",
  "user-agent":
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
  cookie: `PHPSESSID=${SESSION}`,
};

const generateEmail = async () => {
  const res = await axios.get(
    `${BASE_URL}/?action=generate&_=${Date.now()}`,
    { headers }
  );
  return res.data;
};

const saveEmail = async (email) => {
  const res = await axios.post(
    `${BASE_URL}/?action=save_email&_=${Date.now()}`,
    { email, uptime: "232", status: "good" },
    {
      headers: {
        ...headers,
        "content-type": "application/json",
        origin: "https://multi-tools.cloud",
      },
    }
  );
  return res.data;
};

const getInbox = async (email) => {
  const res = await axios.get(
    `${BASE_URL}/?action=inbox&email=${encodeURIComponent(email)}&_=${Date.now()}`,
    { headers }
  );
  return res.data?.result?.inbox ?? [];
};

let handler = async (m, { KazzTzy }) => {
  try {
    await m.react("⏳");

    const generated = await generateEmail();
    const email =
      generated?.result?.email ?? generated?.email ?? generated;

    if (!email) throw new Error("Gagal generate email");

    await saveEmail(email);

    await KazzTzy.sendMessage(
      m.chat,
      {
        text: `📩 *Temporary Email*\n\n${email}\n\nGunakan email ini untuk daftar.\nKetik *.inbox ${email}* untuk cek inbox.`,
      },
      { quoted: m }
    );

    await m.react("✅");
  } catch (e) {
    await m.react("❌");
    m.reply("Error: " + e.message);
  }
};

handler.help = ["tempmail"];
handler.tags = ["tools"];
handler.command = /^tempmail$/i;
handler.limit = true;

export default handler;