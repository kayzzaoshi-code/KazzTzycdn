import fetch from 'node-fetch';

const API_URL = 'https://kayzzidgf.my.id';
const ADMIN_PASS = '200812';

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Penggunaan:\n${usedPrefix + command} <NamaKey>\n\nContoh:\n${usedPrefix + command} KazzTzy`;

  const key = text.trim();

  let res = await fetch(`${API_URL}/api/apikey/delete`, {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: ADMIN_PASS, key }),
  });

  let d = await res.json();
  if (!d.success) throw `❌ Gagal hapus key: ${d.message}`;

  m.reply(
    `╔══〔 *API KEY DELETED* 〕══╗\n` +
    `║\n` +
    `║ 🗑️ Key berhasil dihapus!\n` +
    `║ 🔑 *Key:* ${key}\n` +
    `║\n` +
    `╚══════════════════════╝`
  );
};

handler.help = ['delkey <NamaKey>'];
handler.tags = ['owner'];
handler.command = /^delkey$/i;
handler.owner = true;

export default handler;