import axios from "axios";

async function sendAIReply(KazzTzy, m, text) {
  return KazzTzy.sendMessage(m.chat, {
    text: String(text),
    mentions: [m.sender],
    contextInfo: {
      externalAdReply: {
        title: "Z4Z Bot",
        body: "KazzTzy",
        thumbnailUrl: "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1772016271450.jpeg",
        sourceUrl: global.source || "https://wa.me/6285795269956",
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m });
}

async function bypassai(text) {
    if (!text) throw new Error("Parameter text diperlukan");

    const { data } = await axios.get(
        "https://31jnx1hcnk.execute-api.us-east-1.amazonaws.com/default/test_7_aug_24",
        {
            headers: {
                origin: "https://bypassai.writecream.com",
                referer: "https://bypassai.writecream.com/",
                "user-agent":
                    "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36"
            },
            params: { content: text }
        }
    );

    if (!data?.finalContent) throw new Error("Gagal mendapatkan respons");

    return data.finalContent.replace(/<span[^>]*>|<\/span>/g, "");
}

let handler = async (m, { text }) => {
    const input = m.quoted ? m.quoted.text : text;
    if (!input) return sendAIReply(KazzTzy, m, "Masukkan teks yang ingin dibypass.");

    try {
        await m.react("⏳");

        const result = await bypassai(input);

        await sendAIReply(KazzTzy, m, result);
        await m.react("✅");

    } catch (err) {
        await m.react("❌");
        m.reply("Error:\n" + (err.response?.data?.message || err.message));
    }
};

handler.help = ["bypassai <text>"];
handler.tags = ["tools"];
handler.command = /^bypassai$/i;
handler.limit = true;

export default handler;