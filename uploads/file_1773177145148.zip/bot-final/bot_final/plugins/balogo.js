import baLogo from "ba-logo";

let handler = async (m, { KazzTzy, usedPrefix, command, text }) => {
    try {
        await m.react(global.react || '⏳');

        if (!text) return m.reply(`Contoh penggunaan:\n\n${usedPrefix + command} <teks>`);

        const image = await baLogo(text);
        const buffer = await image.toBuffer();

        await KazzTzy.sendMessage(
            m.chat,
            {
                image: buffer,
                caption: `BA Logo: ${text}`
            },
            { quoted: m }
        );

        await m.react(global.reactSuccess || '✅');
    } catch (e) {
        await m.react(global.reactError || '❌');
        m.reply(String(e?.response?.data || e.message || e));
    }
};

handler.help = ["balogo"];
handler.tags = ["maker"];
handler.command = /^balogo$/i;
handler.register = true;
handler.limit = true;

export default handler;