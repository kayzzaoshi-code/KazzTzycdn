import axios from "axios";

const API = "https://kayzzidgf.my.id";
export const sessions = {};

let handler = async (m, { KazzTzy, usedPrefix }) => {
  const chat = m.chat;
  if (sessions[chat]) return m.reply("𖣂 Masih ada soal aktif! Jawab dulu atau " + usedPrefix + "stoptebakkimia");

  await m.react(global.react);

  const res = await axios.get(API + "/api/game/tebakkimia?apikey=KazzTzy").catch(() => null);
  if (!res.data?.unsur) return m.reply("𖣂 Gagal ambil soal.");

  sessions[chat] = {
    jawaban: String(res.data?.lambang).toLowerCase(),
    timeout: setTimeout(() => {
      delete sessions[chat];
      KazzTzy.sendMessage(chat, { text: "𖣂 Waktu habis! Jawaban: *" + res.data?.lambang + "*" });
    }, 60000)
  };

  await KazzTzy.sendMessage(chat, {
    text: "╔══[ TEBAKKIMIA ]══╗\n\n𖣂 Apa lambang kimia dari unsur:\n𖣂 " + res.data?.unsur + "\n\n𖣂 Waktu: 60 detik\n𖣂 Hadiah: +3 Limit, +300 Uang, +70 EXP\n╚══════════════════╝"
  }, { quoted: m });

  await m.react(global.reactSuccess);
};

handler.help = ["tebakkimia"];
handler.tags = ["game"];
handler.command = /^tebakkimia$/i;
handler.register = true;
export default handler;
