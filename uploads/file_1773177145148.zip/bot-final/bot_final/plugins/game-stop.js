import { sessions as tebakSessions } from "./game-tebaktebakan.js";
import { sessions as siapaSessions } from "./game-tebaksiapa.js";
import { sessions as benderaSessions } from "./game-tebakbendera.js";
import { sessions as tekaSessions } from "./game-tekateki.js";
import { sessions as warnaSessions } from "./game-tebakwarna.js";
import { sessions as gameSessions } from "./game-tebakgame.js";
import { sessions as lirikSessions } from "./game-tebaklirik.js";
import { sessions as jkt48Sessions } from "./game-tebakjkt48.js";
import { sessions as kataSessions } from "./game-tebakkata.js";
import { sessions as kimiaSessions } from "./game-tebakkimia.js";
import { sessions as laguSessions } from "./game-tebaklagu.js";
import { sessions as lengkapiSessions } from "./game-lengkapikalimat.js";
import { sessions as otakSessions } from "./game-asahotak.js";
import { sessions as susunSessions } from "./game-susunkata.js";
import { sessions as cakSessions } from "./game-caklontong.js";
import { sessions as f100Sessions } from "./game-family100.js";

const map = {
  stoptebak: tebakSessions,
  stoptebaktebakan: tebakSessions,
  stoptebaksiapa: siapaSessions,
  stoptebakbendera: benderaSessions,
  stoptekateki: tekaSessions,
  stoptebakwarna: warnaSessions,
  stoptebakgame: gameSessions,
  stoptebaklirik: lirikSessions,
  stoptebakjkt48: jkt48Sessions,
  stoptebakkata: kataSessions,
  stoptebakkimia: kimiaSessions,
  stoptebaklagu: laguSessions,
  stoplengkapikalimat: lengkapiSessions,
  stopasahotak: otakSessions,
  stopsusunkata: susunSessions,
  stopcaklontong: cakSessions,
  stopfamily100: f100Sessions,
};

let handler = async (m, { command }) => {
  const sessions = map[command];
  if (!sessions) return;
  const s = sessions[m.chat];
  if (!s) return m.reply("𖣂 Tidak ada game aktif.");
  clearTimeout(s.timeout);
  delete sessions[m.chat];
  const jaw = Array.isArray(s.jawabanList) ? s.jawabanList.join(", ") : s.jawaban;
  m.reply("𖣂 Game dihentikan.\n𖣂 Jawaban: *" + jaw + "*");
};

handler.help = ["stoptebak", "stoptebaksiapa", "stoptebakbendera", "stoptekateki", "stoptebakwarna", "stoptebakgame", "stoptebaklirik", "stoptebakjkt48", "stoptebakkata", "stoptebakkimia", "stoptebaklagu", "stoplengkapikalimat", "stopasahotak", "stopsusunkata", "stopcaklontong", "stopfamily100"];
handler.tags = ["game"];
handler.command = /^(stoptebak|stoptebaktebakan|stoptebaksiapa|stoptebakbendera|stoptekateki|stoptebakwarna|stoptebakgame|stoptebaklirik|stoptebakjkt48|stoptebakkata|stoptebakkimia|stoptebaklagu|stoplengkapikalimat|stopasahotak|stopsusunkata|stopcaklontong|stopfamily100)$/i;
export default handler;
