import axios from 'axios'

const talktoAI = async (query) => {
  const botName = "Beebop"
  const role = "AI Companion"
  const sessionID =
    Math.random().toString(36).substring(2, 15) +
    Math.random().toString(36).substring(2, 15)

  const smsg = {
    data: {
      botName,
      role,
      message: `B::Hello!\nU::${query}`
    }
  }

  const sres = await axios.post(
    "https://talkto-api.pfpmaker.workers.dev/api/send-message",
    smsg,
    {
      headers: {
        "Content-Type": "application/json",
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36",
        Referer: "https://talkto.ai/"
      },
      timeout: 15000
    }
  )

  if (sres.data.response !== "Message sent") {
    throw new Error("Gagal mengirim pesan ke AI")
  }

  const hash = sres.data.hash
  const blob = Buffer.from(`B::Hello!\nU::${query}`).toString("base64")

  const getmsg = {
    data: { hash, role, sessionID, blob }
  }

  const getres = await axios.post(
    "https://talkto-api.pfpmaker.workers.dev/api/get-message",
    getmsg,
    {
      headers: {
        "Content-Type": "application/json",
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36",
        Referer: "https://talkto.ai/"
      },
      timeout: 15000
    }
  )

  if (getres.data.response !== "Message received") {
    throw new Error("Gagal mendapatkan jawaban dari AI")
  }

  return getres.data.message
}

let handler = async (m, { text }) => {
  if (!text) return m.reply('Masukkan pertanyaan.')

  try {
    await m.react('⏳')
    const res = await talktoAI(text)
    await m.reply(res)
  } catch (e) {
    m.reply('Terjadi kesalahan.')
  }
}

handler.help = ['talkai <teks>']
handler.tags = ['ai']
handler.command = ['talkai', 'beebop']

export default handler