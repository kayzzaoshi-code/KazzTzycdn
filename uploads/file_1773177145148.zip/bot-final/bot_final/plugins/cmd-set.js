let handler = async (m, { text, usedPrefix, command }) => {
	if (!m.quoted) throw `Balas sticker/foto/audio/gif/video dengan perintah *${usedPrefix + command}*`;
	if (!m.quoted.fileSha256) throw 'SHA256 Hash Missing';
	if (!text) throw `Penggunaan:\n${usedPrefix + command} <teks>\n\nContoh:\n${usedPrefix + command} .menu`;
	
	const q = m.quoted;
	const mime = (q.msg || q).mimetype || "";
	const validTypes = [
		"image/webp",
		"image/jpeg",
		"image/png",
		"image/gif",
		"audio/",
		"video/"
	];
	
	const isValid = validTypes.some(type => mime.includes(type));
	if (!isValid) throw 'Reply sticker, foto, audio, gif, atau video!';
	
	let sticker = db.data.sticker;
	let hash = m.quoted.fileSha256;
	if (sticker[hash] && sticker[hash].locked) throw 'Kamu tidak memiliki izin untuk mengubah perintah media ini';
	
	sticker[hash] = {
		text,
		mentionedJid: m.mentionedJid,
		creator: m.sender,
		at: Date.now(),
		locked: false,
	};
	m.reply(`✅ Success!\n\nKirim media ini lagi untuk trigger:\n${text}`);
};

handler.help = ['setcmd <teks>'];
handler.tags = ['database'];
handler.command = ['setcmd'];

export default handler;
