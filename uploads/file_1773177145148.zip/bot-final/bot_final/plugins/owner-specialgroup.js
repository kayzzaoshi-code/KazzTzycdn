const SPECIAL_GC_LINK = "https://chat.whatsapp.com/KJu5KYX5mWBLSP8Q6aRFBG";

let handler = async (m, { KazzTzy, args, isOwner }) => {
  if (!isOwner) return;

  const settings = global.db.data.settings[KazzTzy.user.jid];
  if (!settings.specialGroup) settings.specialGroup = { on: false, jid: null };

  const sub = (args[0] || "").toLowerCase();
  const sub2 = (args[1] || "").toLowerCase();

  if (sub === "group" && sub2 === "on") {
    if (!settings.specialGroup.jid) {
      return m.reply(
        "𖣂 Belum ada grup yang ditentukan.\n" +
        "Set dulu dengan: .special set <link/jid grup>"
      );
    }
    settings.specialGroup.on = true;
    return m.reply(
      "╔══[ SPECIAL GROUP ON ]══╗\n" +
      "𖣂 Status  : AKTIF\n" +
      "𖣂 Grup    : " + settings.specialGroup.jid + "\n" +
      "𖣂 Semua user harus masuk grup ini\n" +
      "𖣂 untuk bisa pakai bot.\n" +
      "╚════════════════════════╝"
    );
  }

  if (sub === "group" && sub2 === "off") {
    settings.specialGroup.on = false;
    return m.reply(
      "╔══[ SPECIAL GROUP OFF ]══╗\n" +
      "𖣂 Status : NONAKTIF\n" +
      "𖣂 Semua user bisa pakai bot.\n" +
      "╚══════════════════════════╝"
    );
  }

  if (sub === "set") {
    const input = args[1] || "";
    const isLink = input.includes("chat.whatsapp.com");
    const isJid = input.includes("@g.us");

    if (!isLink && !isJid) {
      return m.reply(
        "𖣂 Format: .special set <link/jid>\n" +
        "Contoh:\n" +
        ".special set https://chat.whatsapp.com/xxx\n" +
        ".special set 120363xxx@g.us"
      );
    }

    if (isLink) {
      try {
        const code = input.split("/").pop();
        const info = await KazzTzy.groupGetInviteInfo(code);
        settings.specialGroup.jid = info.id;
        settings.specialGroup.name = info.subject;
        return m.reply(
          "╔══[ SPECIAL GROUP SET ]══╗\n" +
          "𖣂 Grup  : " + info.subject + "\n" +
          "𖣂 JID   : " + info.id + "\n" +
          "𖣂 Sekarang aktifkan: .special group on\n" +
          "╚══════════════════════════╝"
        );
      } catch (e) {
        return m.reply("𖣂 Gagal ambil info grup: " + e.message);
      }
    }

    settings.specialGroup.jid = input;
    return m.reply(
      "╔══[ SPECIAL GROUP SET ]══╗\n" +
      "𖣂 JID   : " + input + "\n" +
      "𖣂 Sekarang aktifkan: .special group on\n" +
      "╚══════════════════════════╝"
    );
  }

  if (sub === "status") {
    return m.reply(
      "╔══[ SPECIAL GROUP STATUS ]══╗\n" +
      "𖣂 Status : " + (settings.specialGroup.on ? "ON" : "OFF") + "\n" +
      "𖣂 Grup   : " + (settings.specialGroup.jid || "Belum diset") + "\n" +
      (settings.specialGroup.name ? "𖣂 Nama  : " + settings.specialGroup.name + "\n" : "") +
      "╚═══════════════════════════╝"
    );
  }

  m.reply(
    "╔══[ SPECIAL GROUP ]══╗\n" +
    "𖣂 .special set <link/jid>\n" +
    "𖣂 .special group on\n" +
    "𖣂 .special group off\n" +
    "𖣂 .special status\n" +
    "╚═════════════════════╝"
  );
};

handler.before = async function (m) {
  if (m.isBaileys || m.fromMe) return true;

  const settings = global.db.data.settings?.[KazzTzy.user.jid];
  if (!settings?.specialGroup?.on || !settings?.specialGroup?.jid) return true;

  const isOwner = global.owner.map(([n]) => n + "@s.whatsapp.net").includes(m.sender);
  if (isOwner) return true;

  try {
    const meta = await KazzTzy.groupMetadata(settings.specialGroup.jid);
    const members = meta.participants.map(p => p.id);
    if (!members.includes(m.sender)) {
      await KazzTzy.sendMessage(m.chat, {
        text: [
          "𖣂 Kamu belum bergabung ke grup khusus!",
          "𖣂 Gabung dulu untuk bisa pakai bot:",
          "",
          SPECIAL_GC_LINK
        ].join("\n")
      }, { quoted: m });
      return false;
    }
  } catch {
    return true;
  }

  return true;
};

handler.help = ["special [group on/off/set/status]"];
handler.tags = ["owner"];
handler.command = /^special$/i;
handler.owner = true;

export default handler;
