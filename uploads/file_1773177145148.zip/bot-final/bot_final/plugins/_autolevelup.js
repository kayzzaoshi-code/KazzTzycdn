import { canLevelUp } from "../lib/levelling.js";

export async function after(m) {
  if (!m.sender) return true;

  const user = global.db.data.users?.[m.sender];
  if (!user || !user.registered) return true;

  if (!canLevelUp(user.level, user.exp, global.multiplier)) return true;

  const before = user.level;
  while (canLevelUp(user.level, user.exp, global.multiplier)) {
    user.level++;
  }

  const name = KazzTzy.getName(m.sender) || m.sender.split("@")[0];

  await KazzTzy.sendMessage(m.chat, {
    text: [
      "LEVEL UP!",
      "",
      "𖣂 " + name + " naik level!",
      "𖣂 " + before + " -> " + user.level,
      "𖣂 EXP: " + user.exp
    ].join("\n")
  }, { quoted: m });

  return true;
}
