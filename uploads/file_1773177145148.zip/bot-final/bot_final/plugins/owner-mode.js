let handler = async (m, { KazzTzy, usedPrefix, command }) => {
	const settings = global.db.data.settings[KazzTzy.user.jid];
	
	if (command === 'self') {
		settings.public = false;
		m.reply('Bot sekarang dalam mode *SELF*\nHanya owner yang bisa menggunakan bot');
	} else if (command === 'public') {
		settings.public = true;
		m.reply('Bot sekarang dalam mode *PUBLIC*\nSemua orang bisa menggunakan bot');
	}
};

handler.help = ['self', 'public'];
handler.tags = ['owner'];
handler.command = /^(self|public)$/i;
handler.owner = true;

export default handler;
