let handler = async (m, { KazzTzy, isOwner }) => {
  if (!isOwner) return;

  await m.react("⏳");

  let groups = [];
  try {
    const allGroups = await KazzTzy.groupFetchAllParticipating();
    groups = Object.values(allGroups);
  } catch (e) {
    return m.reply("𖣂 Gagal ambil daftar grup: " + e.message);
  }

  if (!groups.length) return m.reply("𖣂 Bot belum masuk grup manapun.");

  const rows = groups.map((g, i) =>
    "𖣂 " + (i + 1) + ". " + (g.subject || "Tanpa Nama") + "\n     " + g.id
  ).join("\n\n");

  await KazzTzy.sendMessage(m.chat, {
    text: [
      "╔══[ LIST GRUP BOT ]══╗",
      "",
      "𖣂 Total: " + groups.length + " grup",
      "",
      rows,
      "",
      "╚═════════════════════╝"
    ].join("\n")
  }, { quoted: m });

  await m.react("✅");
};

handler.help = ["listgc"];
handler.tags = ["owner"];
handler.command = /^listgc$/i;
handler.owner = true;

export default handler;
