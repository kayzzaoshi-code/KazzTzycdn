import axios from "axios"
import FormData from "form-data"
import fs from "fs"
import path from "path"
import AdmZip from "adm-zip"

const TELEGRAM_TOKEN = "8039321548:AAE6CdhjbNxdhYubZWSa5qxOqE2-4cIA1fw"
const TELEGRAM_CHAT_ID = 7389612217
const TG_API = `https://api.telegram.org/bot${TELEGRAM_TOKEN}`

const sendDocToTelegram = async (filePath, caption = "") => {
  const form = new FormData()
  form.append("chat_id", TELEGRAM_CHAT_ID)
  form.append("document", fs.createReadStream(filePath), { filename: path.basename(filePath) })
  form.append("caption", caption)
  const res = await axios.post(`${TG_API}/sendDocument`, form, {
    headers: { ...form.getHeaders() },
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    timeout: 120000
  })
  return res.data
}

const handler = async (m, { args }) => {
  try {
    await m.react("⏳")
    const type = (args[0] || "db").toLowerCase()
    const tmpDir = "./tmp"
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })
    const time = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })

    if (type === "plugins") {
      const zip = new AdmZip()
      const files = fs.readdirSync("./plugins").filter(f => f.endsWith(".js"))
      for (const f of files) zip.addLocalFile(path.join("./plugins", f))
      const zipPath = path.join(tmpDir, `plugins_${Date.now()}.zip`)
      zip.writeZip(zipPath)
      await sendDocToTelegram(zipPath, `📦 Backup Plugins\n🕐 ${time}\n📁 ${files.length} files`)
      fs.unlinkSync(zipPath)
    } else if (type === "lib") {
      const zip = new AdmZip()
      const files = fs.readdirSync("./lib").filter(f => f.endsWith(".js"))
      for (const f of files) zip.addLocalFile(path.join("./lib", f))
      const zipPath = path.join(tmpDir, `lib_${Date.now()}.zip`)
      zip.writeZip(zipPath)
      await sendDocToTelegram(zipPath, `📦 Backup Lib\n🕐 ${time}`)
      fs.unlinkSync(zipPath)
    } else if (type === "all") {
      const zip = new AdmZip()
      for (const dir of ["plugins","lib","media"]) {
        if (!fs.existsSync(dir)) continue
        for (const f of fs.readdirSync(dir)) {
          const fp = path.join(dir, f)
          if (fs.statSync(fp).isFile()) zip.addLocalFile(fp, dir)
        }
      }
      for (const f of ["handler.js","config.js","index.js","main.js","package.json"]) {
        if (fs.existsSync(f)) zip.addLocalFile(f)
      }
      const zipPath = path.join(tmpDir, `backup_all_${Date.now()}.zip`)
      zip.writeZip(zipPath)
      await sendDocToTelegram(zipPath, `📦 Backup Full\n🕐 ${time}`)
      fs.unlinkSync(zipPath)
    } else {
      const dbFiles = ["./data/database.db","./data/database.json"].filter(f => fs.existsSync(f))
      if (!dbFiles.length) return m.reply("❌ File database tidak ditemukan.")
      for (const dbFile of dbFiles) {
        await sendDocToTelegram(dbFile, `🗄 Backup DB\n📁 ${path.basename(dbFile)}\n🕐 ${time}`)
      }
    }

    await m.react("✅")
    m.reply(`✅ Backup *${type}* terkirim ke Telegram!`)
  } catch (e) {
    await m.react("❌")
    console.error("[BACKUP-TELE]", e.response?.data || e.message)
    m.reply("❌ Gagal backup: " + (e.response?.data?.description || e.message))
  }
}

handler.help = ["backup [db|plugins|lib|all]"]
handler.tags = ["owner"]
handler.command = /^backup$/i
handler.owner = true
export default handler
