import axios from "axios";
import { Sticker, StickerTypes } from "wa-sticker-formatter";

let handler = async (m, { KazzTzy, text }) => {
    try {
        await m.react(global.react || "⏳");

        if (!text) return m.reply("❌ Masukkan teks untuk dijadikan sticker.");

        const url = `https://api.deline.web.id/maker/attp?text=${encodeURIComponent(text)}`;

        const res = await axios.get(url, { responseType: "arraybuffer" });

        const sticker = new Sticker(res.data, {
            pack: global.packname || "Sticker Bot",
            author: global.author || "Bot",
            type: StickerTypes.FULL,
            quality: 100
        });

        const stickerBuffer = await sticker.toBuffer();

        await KazzTzy.sendMessage(
            m.chat,
            { sticker: stickerBuffer },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e.message || e));
    }
};

handler.help = ["attp <teks>"];
handler.tags = ["maker"];
handler.command = /^(attp|texttopfp|ttfp)$/i;
handler.register = true;
handler.limit = true;

export default handler;