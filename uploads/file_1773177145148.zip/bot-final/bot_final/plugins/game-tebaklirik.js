import axios from "axios";

const API = "https://kayzzidgf.my.id";
export const sessions = {};

let handler = async (m, { KazzTzy, usedPrefix }) => {
  const chat = m.chat;
  if (sessions[chat]) return m.reply("𖣂 Masih ada soal aktif! Jawab dulu atau " + usedPrefix + "stoptebaklirik");

  await m.react(global.react);

  const res = await axios.get(API + "/api/game/tebaklirik?apikey=KazzTzy").catch(() => null);
  if (!res.data?.data?.soal) return m.reply("𖣂 Gagal ambil soal.");

  sessions[chat] = {
    jawaban: String(res.data?.data?.jawaban).toLowerCase(),
    timeout: setTimeout(() => {
      delete sessions[chat];
      KazzTzy.sendMessage(chat, { text: "𖣂 Waktu habis! Jawaban: *" + res.data?.data?.jawaban + "*" });
    }, 60000)
  };

  await KazzTzy.sendMessage(chat, {
    text: "╔══[ TEBAKLIRIK ]══╗\n\n𖣂 Lengkapi lirik lagu ini:\n𖣂 " + res.data?.data?.soal + "\n\n𖣂 Waktu: 60 detik\n𖣂 Hadiah: +3 Limit, +300 Uang, +70 EXP\n╚══════════════════╝"
  }, { quoted: m });

  await m.react(global.reactSuccess);
};

handler.help = ["tebaklirik"];
handler.tags = ["game"];
handler.command = /^tebaklirik$/i;
handler.register = true;
export default handler;
