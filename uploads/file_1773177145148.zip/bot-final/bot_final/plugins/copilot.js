import axios from "axios";

async function sendAIReply(KazzTzy, m, text) {
  return KazzTzy.sendMessage(m.chat, {
    text: String(text),
    mentions: [m.sender],
    contextInfo: {
      externalAdReply: {
        title: "Z4Z Bot",
        body: "KazzTzy",
        thumbnailUrl: "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1772016271450.jpeg",
        sourceUrl: global.source || "https://wa.me/6285795269956",
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m });
}

async function copilotAI(text) {
    if (!text) throw new Error("Parameter q diperlukan");

    const { data } = await axios.get("https://www.kitsulabs.xyz/api/v1/copilot", {
        params: {
            model: "gpt-5",
            prompt: text
        }
    });

    const result = data?.data?.text;

    if (!result) throw new Error("Gagal mendapatkan respon.");

    return result.trim();
}

let handler = async (m, { text }) => {
    const input = m.quoted ? m.quoted.text : text;
    if (!input) return sendAIReply(KazzTzy, m, "Masukkan pertanyaan.");

    try {
        await m.react("⏳");
        const res = await copilotAI(input);
        await sendAIReply(KazzTzy, m, res);
        await m.react("✅");
    } catch (err) {
        await m.react("❌");
        m.reply("Error:\n" + (err.response?.data?.message || err.message));
    }
};

handler.help = ["copilot <text>"];
handler.tags = ["ai"];
handler.command = /^copilot$/i;
handler.limit = true;

export default handler;