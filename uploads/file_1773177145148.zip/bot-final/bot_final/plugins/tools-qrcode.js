let handler = async (m, { KazzTzy, text, usedPrefix, command }) => {
	if (!text) return KazzTzy.reply(m.chat, `Use example: \n${usedPrefix + command} <teks>`, m);
	KazzTzy.sendFile(m.chat, `https://quickchart.io/qr?text=${encodeURIComponent(text)}`, 'qrcode.png', '¯\\_(ツ)_/¯', m);
};

handler.help = ['qrcode <teks>'];
handler.tags = ['tools'];
handler.command = /^qr(code)?$/i;

export default handler;
