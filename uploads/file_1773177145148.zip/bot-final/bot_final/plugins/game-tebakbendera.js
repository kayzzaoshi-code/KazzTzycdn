import axios from "axios";

const API = "https://kayzzidgf.my.id";
export const sessions = {};

let handler = async (m, { KazzTzy, usedPrefix }) => {
  const chat = m.chat;
  if (sessions[chat]) return m.reply("𖣂 Masih ada soal aktif! Jawab dulu atau " + usedPrefix + "stoptebakbendera");

  await m.react(global.react);

  const res = await axios.get(API + "/api/game/tebakbendera?apikey=KazzTzy").catch(() => null);
  if (!res?.data?.status || !res?.data?.soal?.url) return m.reply("𖣂 Gagal ambil soal.");

  sessions[chat] = {
    jawaban: res.data.jawaban.toLowerCase(),
    timeout: setTimeout(() => {
      delete sessions[chat];
      KazzTzy.sendMessage(chat, { text: "𖣂 Waktu habis! Jawaban: *" + res.data.jawaban + "*" });
    }, 60000)
  };

  await KazzTzy.sendMessage(chat, {
    image: { url: res.data.soal.url },
    caption: "╔══[ TEBAK BENDERA ]══╗\n\n𖣂 Bendera negara apa ini?\n\n𖣂 Waktu: 60 detik\n𖣂 Hadiah: +4 Limit, +400 Uang, +80 EXP\n╚══════════════════════╝"
  }, { quoted: m });

  await m.react(global.reactSuccess);
};

handler.help = ["tebakbendera"];
handler.tags = ["game"];
handler.command = /^tebakbendera$/i;
handler.register = true;
export default handler;
