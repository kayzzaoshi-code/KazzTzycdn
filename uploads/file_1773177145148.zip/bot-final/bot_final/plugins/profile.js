import { createHash } from 'crypto';

let handler = async (m, { KazzTzy }) => {
    let user = global.db.data.users[m.sender];
    if (!user.registered) return m.reply('Kamu belum registrasi! Gunakan .daftar <nama>.<umur>');

    let pp;
    try {
        pp = await KazzTzy.profilePictureUrl(m.sender, 'image', 'buffer');
    } catch {
        pp = global.thumbnail; // fallback kalau user tidak punya PP
    }

    let sn = createHash('md5').update(m.sender).digest('hex');

    let cap = `
─── PROFILE ───
• Name: ${user.name}
• Age: ${user.age >= 0 ? user.age : '--'}
• Level: ${user.level || 1}
• Exp: ${user.exp || 0}
• Health: ${user.health || 0}
• Money: ${user.money || 0}
• Limit: ${user.limit || 0}
• Serial: ${sn}
`;

    await KazzTzy.sendMessage(
        m.chat,
        {
            text: cap,
            contextInfo: {
                isForwarded: true,
                forwarded: true,
                externalAdReply: {
                    title: global.namebot,
                    body: '',
                    thumbnail: pp,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                },
            },
        },
        { quoted: m }
    );
};

handler.help = ['profile', 'myprofile'];
handler.tags = ['xp'];
handler.command = /^(profile|me)$/i;

export default handler;