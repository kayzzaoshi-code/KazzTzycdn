import axios from "axios";

let handler = async (m, { KazzTzy, text }) => {
    try {
        await m.react(global.react || "⏳");

        if (!text) return m.reply("❌ Masukkan kata kunci.");

        const { data } = await axios.get("https://api-faa.my.id/faa/tiktok-search", {
            params: { q: text }
        });

        if (!data.status || !data.result || !data.result.length)
            return m.reply("❌ Tidak ditemukan.");

        const random = data.result[Math.floor(Math.random() * data.result.length)];

        const caption =
`📹 *${random.title}*

👤 ${random.author.nickname} (@${random.author.username})
⏱ ${random.duration}
👀 ${random.stats.views} | ❤️ ${random.stats.likes}
🎵 ${random.music.title} - ${random.music.author}`;

        await KazzTzy.sendMessage(
            m.chat,
            {
                video: { url: random.url_nowm },
                caption
            },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e?.response?.data || e.message || e));
    }
};

handler.help = ["ttsearch <query>", "tiktoksearch <query>"];
handler.tags = ["search"];
handler.command = /^(ttsearch|tiktoksearch)$/i;
handler.register = true;
handler.limit = true;

export default handler;