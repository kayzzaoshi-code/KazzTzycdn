import { createCanvas, loadImage } from "canvas";

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) return m.reply(`Masukkan teks!\n\nContoh: ${usedPrefix + command} Kazz Tzy`);

    try {
        await m.react('⏳');

        const bgUrl = "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1771091097762.jpeg";
        const bg = await loadImage(bgUrl);

        const canvas = createCanvas(bg.width, bg.height);
        const ctx = canvas.getContext("2d");

        ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

        let fontSize = 200;
        const maxWidth = canvas.width * 0.95;
        const words = text.toUpperCase().split(" ");
        const fullText = words.join(" ");

        let fontFamily = "Impact";
        if (command === 'ephoto5') fontFamily = "serif";
        if (command === 'ephoto6') fontFamily = "sans-serif";
        if (command === 'ephoto4') fontFamily = "Arial";

        do {
            fontSize -= 2;
            ctx.font = `italic bold ${fontSize}px ${fontFamily}`;
        } while (ctx.measureText(fullText).width > maxWidth && fontSize > 10);

        ctx.textAlign = "left";
        ctx.textBaseline = "middle";

        const totalWidth = ctx.measureText(fullText).width;
        let startX = (canvas.width - totalWidth) / 2;
        const y = canvas.height / 2;

        for (let i = 0; i < words.length; i++) {
            let word = words[i];
            for (let j = 0; j < word.length; j++) {
                let char = word[j];
                
                let mainColor = "#FFFFFF";
                let strokeColor = "#000000";
                let glowColor = "rgba(0, 0, 0, 0.8)";
                let blurLevel = 15;

                if (command === 'ephoto3') {
                    if (j === 0 && i === 0) mainColor = "#FF2E2E";
                    else if (j === 0 && i === 1) mainColor = "#2E5EFF";
                    strokeColor = "#000000";
                } 
                else if (command === 'ephoto4') {
                    mainColor = "#00FBFF";
                    strokeColor = "#004142";
                    glowColor = "#00FBFF";
                    if (j === 0) mainColor = "#FF00D4";
                }
                else if (command === 'ephoto5') {
                    mainColor = "#660000";
                    strokeColor = "#000000";
                    glowColor = "#FF0000";
                    blurLevel = 25;
                    fontFamily = "serif";
                }
                else if (command === 'ephoto6') {
                    mainColor = "#00FF40";
                    strokeColor = "#00330D";
                    glowColor = "#00FF40";
                    blurLevel = 40;
                }

                ctx.shadowColor = glowColor;
                ctx.shadowBlur = blurLevel;
                ctx.shadowOffsetX = command === 'ephoto5' ? 10 : 5;
                ctx.shadowOffsetY = command === 'ephoto5' ? 15 : 5;

                ctx.lineJoin = "round";
                ctx.lineWidth = fontSize / 6;
                ctx.strokeStyle = strokeColor;
                ctx.strokeText(char, startX, y);

                ctx.shadowBlur = 0;
                ctx.shadowOffsetX = 0;
                ctx.shadowOffsetY = 0;
                
                if (command !== 'ephoto5') {
                    ctx.lineWidth = fontSize / 20;
                    ctx.strokeStyle = "#FFFFFF";
                    ctx.strokeText(char, startX, y);
                }

                ctx.fillStyle = mainColor;
                ctx.fillText(char, startX, y);

                startX += ctx.measureText(char).width;
            }
            startX += ctx.measureText(" ").width;
        }

        const buffer = canvas.toBuffer("image/jpeg");
        
        await m.reply(buffer, null, { caption: `✅ Selesai Style: ${command.toUpperCase()}` });
        await m.react('✅');

    } catch (err) {
        await m.react('❌');
        m.reply(err.message);
    }
};

handler.help = ["ephoto3", "ephoto4", "ephoto5", "ephoto6"].map(v => v + " <teks>");
handler.tags = ["maker"];
handler.command = /^(ephoto3|ephoto4|ephoto5|ephoto6)$/i;
handler.register = true;
handler.limit = true;

export default handler;