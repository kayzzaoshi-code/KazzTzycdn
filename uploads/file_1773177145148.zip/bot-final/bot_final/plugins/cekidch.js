const handler = async (m, { text }) => {
    if (!text) return m.reply("🍌 Harap masukkan link channel WhatsApp!");
    if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid!");

    let result = text.split("https://whatsapp.com/channel/")[1];
    let res = await KazzTzy.newsletterMetadata("invite", result);

    let teks = `*✨ ID:* ${res.id}`;

    let buttonMessage = {
        text: teks,
        footer: "KazzTzy",
        templateButtons: [
            { urlButton: { displayText: "Copy ID", url: `https://wa.me/?text=${res.id}` } }
        ]
    };

    return KazzTzy.sendMessage(m.chat, buttonMessage, { quoted: m });
};

handler.help = ["cekidch"];
handler.tags = ["tools"];
handler.command = ["cekidch", "idch"];
export default handler;