import { createCanvas, loadImage } from "canvas"
import moment from "moment-timezone"
import fetch from "node-fetch"

let handler = async (m, { KazzTzy, text, usedPrefix, command }) => {
  if (!text)
    return m.reply(`Format salah\n${usedPrefix + command} timezone|namaPengirim|noHpPengirim|namaTujuan|noHpTujuan|nominal`)

  let [timezone, namaPengirim, noHpPengirim, namaTujuan, noHpTujuan, nominalStr] = text.split("|")

  const validTimezones = {
    WIB: "Asia/Jakarta",
    WITA: "Asia/Makassar",
    WIT: "Asia/Jayapura"
  }

  if (!timezone || !validTimezones[timezone.toUpperCase()])
    return m.reply("Timezone tidak valid gunakan WIB WITA atau WIT")

  const nominal = parseInt(nominalStr)
  if (isNaN(nominal) || nominal < 1 || nominal > 1000000000)
    return m.reply("Nominal tidak valid")

  try {
    await m.react("⏳")

    const now = moment().tz(validTimezones[timezone.toUpperCase()])
    const tanggal = now.format("D MMM YYYY • HH:mm")
    const idTanggal = now.format("YYYYMMDD")

    const idTransaksi1 = idTanggal + Math.random().toString().slice(2, 13)
    const idTransaksi2 = Math.random().toString().slice(2, 21)
    const idMerchant = `•••${Math.random().toString(36).substr(2, 4)}`

    const potongHp = `${noHpPengirim.slice(0, 4)}${"•".repeat(noHpPengirim.length - 8)}${noHpPengirim.slice(-4)}`

    const imageUrl = "https://raw.githubusercontent.com/ChandraGO/Data-Jagoan-Project/refs/heads/master/src/MENTAHAN_DONO.jpg"
    const response = await fetch(imageUrl)
    const buffer = Buffer.from(await response.arrayBuffer())
    const bgImage = await loadImage(buffer)

    const canvas = createCanvas(bgImage.width, bgImage.height)
    const ctx = canvas.getContext("2d")
    ctx.drawImage(bgImage, 0, 0, canvas.width, canvas.height)

    const draw = (t, x, y, font = "23px sans-serif", align = "left", color = "#000") => {
      ctx.font = font
      ctx.fillStyle = color
      ctx.textAlign = align
      ctx.fillText(t, x, y)
    }

    draw(tanggal, 75, 541, "17px sans-serif", "left", "#777")
    draw(`ID DANA ${potongHp}`, 639, 541, "17px sans-serif", "right", "#777")

    draw(`${nominal.toLocaleString()}`, 257, 679, "bold 27px sans-serif", "left", "#282125")
    draw(`ke ${namaTujuan} - ${noHpTujuan}`, 73, 708, "22px sans-serif", "left")

    draw(`Rp${nominal.toLocaleString()}`, 623, 809, "bold 30px sans-serif", "right", "#282125")

    draw(idTransaksi1, 623, 1167, "22px sans-serif", "right")
    draw(idTransaksi2, 623, 1201, "22px sans-serif", "right")
    draw(idMerchant, 623, 1282, "22px sans-serif", "right")

    const resultBuffer = canvas.toBuffer("image/png")

    await KazzTzy.sendMessage(
      m.chat,
      { image: resultBuffer, caption: "Bukti transfer berhasil dibuat" },
      { quoted: m }
    )

    await m.react("✅")
  } catch (e) {
    await m.react("❌")
    m.reply("Terjadi kesalahan")
  }
}

handler.command = ["tfdana"]
handler.help = ["tfdana"]
handler.tags = ["maker"]
handler.register = true

export default handler