import axios from "axios";

const API = "https://kayzzidgf.my.id";
export const sessions = {};

let handler = async (m, { KazzTzy, usedPrefix }) => {
  const chat = m.chat;
  if (sessions[chat]) return m.reply("𖣂 Masih ada soal aktif! Jawab dulu atau " + usedPrefix + "stoptekateki");

  await m.react(global.react);

  const res = await axios.get(API + "/api/game/tekateki?apikey=KazzTzy").catch(() => null);
  if (!res?.data?.status || !res?.data?.data?.soal) return m.reply("𖣂 Gagal ambil soal.");

  const data = res.data.data;

  sessions[chat] = {
    jawaban: data.jawaban.toLowerCase(),
    timeout: setTimeout(() => {
      delete sessions[chat];
      KazzTzy.sendMessage(chat, { text: "𖣂 Waktu habis! Jawaban: *" + data.jawaban + "*" });
    }, 60000)
  };

  await KazzTzy.sendMessage(chat, {
    text: "╔══[ TEKA-TEKI ]══╗\n\n𖣂 " + data.soal + "\n\n𖣂 Waktu: 60 detik\n𖣂 Hadiah: +3 Limit, +250 Uang, +60 EXP\n╚══════════════════╝"
  }, { quoted: m });

  await m.react(global.reactSuccess);
};

handler.help = ["tekateki"];
handler.tags = ["game"];
handler.command = /^tekateki$/i;
handler.register = true;
export default handler;
