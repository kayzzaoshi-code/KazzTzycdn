import axios from 'axios';
const GH_TOKEN = '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';
const GH_OWNER = 'kayzzaoshi-code';
const GH_REPO = 'Uploader';
async function createRepo() {
  try { await axios.post('https://api.github.com/user/repos', { name: GH_REPO, private: false }, { headers: { Authorization: `token ${GH_TOKEN}` } }); } catch {}
}
async function uploadToGitHub(buffer, mimetype = 'application/octet-stream') {
  await createRepo();
  const ext = mimetype.split('/')[1] || 'bin';
  const filename = `file_${Date.now()}.${ext}`;
  const res = await axios.put(`https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${filename}`, { message: `Upload ${filename}`, content: Buffer.from(buffer).toString('base64') }, { headers: { Authorization: `token ${GH_TOKEN}` } });
  return res.data.content.download_url;
}

const DOMAIN = "https://kayzzidgf.my.id";

let handler = async (m, { KazzTzy }) => {
  try {
    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype;
    if (!mime) return m.reply("Reply media untuk diupload.");
    const buffer = await q.download();
    if (!buffer) return m.reply("Gagal download media.");
    const result = await uploadToGitHub(buffer, mime);
    if (!result) return m.reply("Gagal upload ke server.");
    const size = result.size < 1024
      ? result.size + " B"
      : result.size < 1048576
        ? (result.size / 1024).toFixed(1) + " KB"
        : (result.size / 1048576).toFixed(2) + " MB";
    const exp = new Date(result.expires_at).toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
    await KazzTzy.sendMessage(m.chat, {
      text: [
        "Upload Berhasil",
        "",
        "File: " + result.filename,
        "Ukuran: " + size,
        "Link:",
        result.url,
        "",
        "Expired: " + exp + " WIB",
        "File otomatis terhapus setelah 1 jam"
      ].join("\n")
    }, { quoted: m });
  } catch (e) {
    console.error(e);
    m.reply("Terjadi kesalahan: " + e.message);
  }
};

handler.help = ["tourl2", "uploader2"];
handler.tags = ["tools"];
handler.command = /^(tourl2|uploader2)$/i;
handler.limit = true;

export default handler;
