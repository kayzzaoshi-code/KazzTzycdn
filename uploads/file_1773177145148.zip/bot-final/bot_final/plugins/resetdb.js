let handler = async (m, { usedPrefix, command }) => {
    if (!handler.owner) return m.reply("❌ Command ini hanya untuk owner bot.")

    if (!global.db?.data) return m.reply("❌ Database tidak ditemukan.")

    global.db.data.users = {}
    global.db.data.chats = {}
    global.db.data.settings = {}

    m.reply(`✅ Database berhasil direset.\nSemua data user, chat, dan settings telah dihapus.`)
}

handler.help = ['resetdb']
handler.tags = ['owner']
handler.command = /^(resetdb)$/i
handler.owner = true

export default handler