import axios from "axios";

let handler = async (m, { KazzTzy, text }) => {
    try {
        await m.react(global.react || "⏳");

        if (!text) return m.reply("❌ Masukkan judul lagu.\nContoh: .ytplay payphone");

        const { data } = await axios.get("https://api.deline.web.id/downloader/ytplay", {
            params: { q: text }
        });

        if (!data.status || !data.result)
            return m.reply("❌ Lagu tidak ditemukan.");

        const res = data.result;

        const caption =
`🎵 *${res.title}*

🔗 ${res.url}
🎧 Quality: ${res.pick.quality}
📦 Size: ${res.pick.size}`;

        await KazzTzy.sendMessage(
            m.chat,
            {
                image: { url: res.thumbnail },
                caption,
                contextInfo: {
                    externalAdReply: {
                        title: res.title,
                        body: "YouTube Play Downloader",
                        thumbnailUrl: res.thumbnail,
                        sourceUrl: res.url,
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            },
            { quoted: m }
        );

        await KazzTzy.sendMessage(
            m.chat,
            {
                audio: { url: res.dlink },
                mimetype: "audio/mpeg",
                fileName: `${res.title}.mp3`
            },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e?.response?.data || e.message || e));
    }
};

handler.help = ["ytplay <judul>"];
handler.tags = ["downloader"];
handler.command = /^(play)$/i;
handler.register = true;
handler.limit = true;

export default handler;