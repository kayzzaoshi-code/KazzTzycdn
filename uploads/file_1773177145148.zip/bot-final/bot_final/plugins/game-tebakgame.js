import axios from "axios";

const API = "https://kayzzidgf.my.id";
export const sessions = {};

let handler = async (m, { KazzTzy, usedPrefix }) => {
  const chat = m.chat;
  if (sessions[chat]) return m.reply("𖣂 Masih ada soal aktif! Jawab dulu atau " + usedPrefix + "stoptebakgame");

  await m.react(global.react);

  const res = await axios.get(API + "/api/game/tebakgame?apikey=KazzTzy").catch(() => null);
  if (!res?.data?.img) return m.reply("𖣂 Gagal ambil soal.");

  sessions[chat] = {
    jawaban: String(res.data.jawaban).toLowerCase(),
    timeout: setTimeout(() => {
      delete sessions[chat];
      KazzTzy.sendMessage(chat, { text: "𖣂 Waktu habis! Jawaban: *" + res.data.jawaban + "*" });
    }, 60000)
  };

  await KazzTzy.sendMessage(chat, {
    image: { url: res.data.img },
    caption: "╔══[ TEBAKGAME ]══╗\n\n𖣂 Tebak nama game ini!\n\n𖣂 Waktu: 60 detik\n𖣂 Hadiah: +4 Limit, +400 Uang, +80 EXP\n╚══════════════════╝"
  }, { quoted: m });

  await m.react(global.reactSuccess);
};

handler.help = ["tebakgame"];
handler.tags = ["game"];
handler.command = /^tebakgame$/i;
handler.register = true;
export default handler;
