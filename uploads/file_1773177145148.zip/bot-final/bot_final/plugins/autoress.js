let handler = async (m, { KazzTzy, text, args, usedPrefix, command }) => {
    global.db.data.responses = global.db.data.responses || {}
    const setting = global.db.data.settings[KazzTzy.user.jid] || {}

    if (command === 'autores') {
        if (!args[0]) return m.reply(`*PENGGUNAAN*\n\n• ${usedPrefix + command} on\n• ${usedPrefix + command} off`)
        let status = args[0].toLowerCase() === 'on'
        global.db.data.settings[KazzTzy.user.jid].autorespon = status
        return m.reply(`✅ *Auto-Response* berhasil diubah ke: *${status ? 'ON' : 'OFF'}*`)
    }

    if (command === 'setrespon') {
        if (!m.quoted) return m.reply("❌ Reply pesan (teks/sticker/audio) yang ingin dijadikan balasan!")
        if (!text) return m.reply(`❌ Masukkan kata kuncinya!\nContoh: ${usedPrefix + command} hay`)
        let keyword = text.toLowerCase().trim()
        global.db.data.responses[keyword] = m.quoted.vM
        return m.reply(`✅ Berhasil menyetel respon untuk kata kunci: *${keyword}*`)
    }

    if (command === 'delrespon') {
        if (!text) return m.reply("❌ Masukkan kata kunci yang ingin dihapus!")
        let keyword = text.toLowerCase().trim()
        if (!global.db.data.responses[keyword]) return m.reply("❌ Kata kunci tersebut tidak ditemukan.")
        delete global.db.data.responses[keyword]
        return m.reply(`✅ Respon untuk kata kunci *${keyword}* telah dihapus.`)
    }

    if (command === 'listrespon') {
        let keys = Object.keys(global.db.data.responses || {})
        if (keys.length === 0) return m.reply("📂 Belum ada daftar auto-response.")
        let txt = `⡖⢶⣶⣤⣀            ⣀⣤⣶⡶⢲
 ⡇  ⠁⢿⣿⣿⣦       ⣴⣿⣿⠿⠁  ⢸
 𓊈 ─ *LIST AUTO RESPONSE* 𓊈 ˚୨୧.˚─\n\n`
        txt += keys.map((v, i) => `┃ ${i + 1}. ${v}`).join('\n')
        txt += `\n\n╰───┈──.🎀༘⋆──┈───`
        return m.reply(txt)
    }
}

handler.before = async function (m, { KazzTzy }) {
    global.db.data.responses = global.db.data.responses || {}
    const setting = global.db.data.settings[KazzTzy.user.jid] || {}
    if (!setting.autorespon || m.fromMe || !m.text) return
    let keyword = m.text.toLowerCase().trim()
    if (global.db.data.responses[keyword]) {
        let msg = global.db.data.responses[keyword]
        await KazzTzy.copyNForward(m.chat, msg, true)
    }
}

handler.help = ['autores', 'setrespon', 'delrespon', 'listrespon']
handler.tags = ['owner']
handler.command = /^(autores|setrespon|delrespon|listrespon)$/i
handler.owner = true

export default handler