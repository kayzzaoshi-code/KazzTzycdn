import fetch from 'node-fetch';

const API_URL = 'https://kayzzidgf.my.id';
const ADMIN_PASS = '200812';

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Penggunaan:\n${usedPrefix + command} <NamaKey> <limit>\n\nContoh:\n${usedPrefix + command} KazzTzy 1000`;

  const args = text.trim().split(' ');
  const key = args[0];
  const limit = parseInt(args[1]) || 1000;

  let res = await fetch(`${API_URL}/api/apikey/create`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: ADMIN_PASS, key, limit_total: limit }),
  });

  let d = await res.json();
  if (!d.success) throw `❌ Gagal buat key: ${d.message}`;

  m.reply(
    `╔══〔 *API KEY CREATED* 〕══╗\n` +
    `║\n` +
    `║ 🔑 *Key:* ${d.key}\n` +
    `║ 📊 *Limit:* ${d.limit_total}\n` +
    `║ ✅ *Status:* Aktif\n` +
    `║\n` +
    `╚══════════════════════╝`
  );
};

handler.help = ['createkey <NamaKey> <limit>'];
handler.tags = ['owner'];
handler.command = /^createkey$/i;
handler.owner = true;

export default handler;