import axios from "axios";

const API = "https://kayzzidgf.my.id";
export const sessions = {};

let handler = async (m, { KazzTzy, usedPrefix }) => {
  const chat = m.chat;
  if (sessions[chat]) return m.reply("𖣂 Masih ada soal aktif! Jawab dulu atau " + usedPrefix + "stopcaklontong");

  await m.react(global.react);

  const res = await axios.get(API + "/api/game/caklontong?apikey=KazzTzy").catch(() => null);
  if (!res.data?.soal) return m.reply("𖣂 Gagal ambil soal.");

  sessions[chat] = {
    jawaban: String(res.data?.jawaban).toLowerCase(),
    timeout: setTimeout(() => {
      delete sessions[chat];
      KazzTzy.sendMessage(chat, { text: "𖣂 Waktu habis! Jawaban: *" + res.data?.jawaban + "*" });
    }, 60000)
  };

  await KazzTzy.sendMessage(chat, {
    text: "╔══[ CAKLONTONG ]══╗\n\n𖣂 Isi titik-titik:\n𖣂 " + res.data?.soal + "\n\n𖣂 Waktu: 60 detik\n𖣂 Hadiah: +3 Limit, +260 Uang, +60 EXP\n╚══════════════════╝"
  }, { quoted: m });

  await m.react(global.reactSuccess);
};

handler.help = ["caklontong"];
handler.tags = ["game"];
handler.command = /^caklontong$/i;
handler.register = true;
export default handler;
