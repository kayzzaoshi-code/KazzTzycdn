import axios from "axios"
import AdmZip from "adm-zip"
import fs from "fs"
import path from "path"
import { fileURLToPath } from "url"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

let handler = async (m, { KazzTzy, text, isOwner }) => {
  try {
    if (!isOwner) return
    if (!text) return m.reply("nama repo?")
    if (!m.quoted) return m.reply("reply file/zip")

    if (!global.github?.user || !global.github?.token)
      return m.reply("github config belum ada")

    const repoName = text.toLowerCase().replace(/[^a-z0-9-_]/g, "")
    if (repoName.length < 3) return m.reply("nama repo minimal 3 karakter")

    await KazzTzy.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

    const buffer = await m.quoted.download()
    if (!buffer) return m.reply("gagal download media")

    const tmpDir = path.join(__dirname, "../tmp", repoName)
    fs.rmSync(tmpDir, { recursive: true, force: true })
    fs.mkdirSync(tmpDir, { recursive: true })

    let files = []
    const mime = (m.quoted.msg || m.quoted).mimetype || ""

    if (mime.includes("zip")) {
      const zip = new AdmZip(buffer)
      for (const entry of zip.getEntries()) {
        if (entry.isDirectory) continue
        const filePath = path.join(tmpDir, entry.entryName)
        fs.mkdirSync(path.dirname(filePath), { recursive: true })
        fs.writeFileSync(filePath, entry.getData())
        files.push(filePath)
      }
    } else {
      const filename = m.quoted.fileName || "index.html"
      const filePath = path.join(tmpDir, filename)
      fs.writeFileSync(filePath, buffer)
      files.push(filePath)
    }

    const headers = {
      Authorization: `token ${global.github.token}`,
      Accept: "application/vnd.github+json"
    }

    try {
      await axios.post(
        "https://api.github.com/user/repos",
        { name: repoName, auto_init: true, private: false },
        { headers }
      )
    } catch {}

    for (const file of files) {
      const content = fs.readFileSync(file, "base64")
      const relPath = file.replace(tmpDir + "/", "").replace(/\\/g, "/")

      await axios.put(
        `https://api.github.com/repos/${global.github.user}/${repoName}/contents/${relPath}`,
        {
          message: "upload via bot",
          content
        },
        { headers }
      )
    }

    fs.rmSync(tmpDir, { recursive: true, force: true })

    await KazzTzy.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
    m.reply("berhasil upload")
  } catch (e) {
    m.reply(String(e))
  }
}

handler.help = ["upgh <repo>"]
handler.tags = ["owner"]
handler.command = ["upgh"]
handler.owner = true

export default handler