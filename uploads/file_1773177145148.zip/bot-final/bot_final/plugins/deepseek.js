import axios from 'axios';
const GH_TOKEN = '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';
const GH_OWNER = 'kayzzaoshi-code';
const GH_REPO = 'Uploader';
async function createRepo() {
  try { await axios.post('https://api.github.com/user/repos', { name: GH_REPO, private: false }, { headers: { Authorization: `token ${GH_TOKEN}` } }); } catch {}
}
async function uploadToGitHub(buffer, mimetype = 'application/octet-stream') {
  await createRepo();
  const ext = mimetype.split('/')[1] || 'bin';
  const filename = `file_${Date.now()}.${ext}`;
  const res = await axios.put(`https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${filename}`, { message: `Upload ${filename}`, content: Buffer.from(buffer).toString('base64') }, { headers: { Authorization: `token ${GH_TOKEN}` } });
  return res.data.content.download_url;
}

class DeepChat {
  constructor() {
    this.baseUrl = 'https://chat-deep.ai'
    this.ajaxUrl = 'https://chat-deep.ai/wp-admin/admin-ajax.php'
    this.headers = {
      'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',
      'Accept': '*/*',
      'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
      'Origin': this.baseUrl,
      'Referer': this.baseUrl + '/deepseek-chat/',
      'Sec-Ch-Ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
      'Sec-Ch-Ua-Mobile': '?0',
      'Sec-Ch-Ua-Platform': '"Linux"',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin'
    }
    this.conversationId = null
    this.nonce = '7df78b0165'
  }

  async sendMessage(message) {
    const formData = new FormData()
    formData.append('action', 'deepseek_chat')
    formData.append('message', message)
    formData.append('model', 'default')
    formData.append('nonce', this.nonce)
    formData.append('save_conversation', '0')
    formData.append('session_only', '1')

    if (this.conversationId) {
      formData.append('conversation_id', this.conversationId)
    }

    const response = await axios.post(this.ajaxUrl, formData, {
      headers: {
        ...this.headers,
        ...formData.getHeaders()
      }
    })

    if (response.data?.success && response.data.data?.conversation_id) {
      this.conversationId = response.data.data.conversation_id
    }

    return response.data?.data?.response || 'deepai tidak menanggapi'
  }
}

const handler = async (m, { KazzTzy, text, reply }) => {
  if (!text) return reply('masukkan pertanyaan')

  try {
    await m.react('⏳')

    const scraper = new DeepChat()
    const response = await scraper.sendMessage(text)

    await m.react('✅')

    await KazzTzy.sendMessage(
      m.chat,
      { text: response },
      { quoted: m }
    )
  } catch (e) {
    console.error(e)
    await m.react('❌')
    reply('error')
  }
}

handler.help = ['deepchat']
handler.tags = ['ai']
handler.command = /^(deepseek)$/i
handler.register = true
handler.limit = true

export default handler
