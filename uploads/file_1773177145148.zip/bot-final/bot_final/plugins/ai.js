import axios from "axios";

async function sendAIReply(KazzTzy, m, text) {
  return KazzTzy.sendMessage(m.chat, {
    text: String(text),
    mentions: [m.sender],
    contextInfo: {
      externalAdReply: {
        title: "Z4Z Bot",
        body: "KazzTzy",
        thumbnailUrl: "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1772016271450.jpeg",
        sourceUrl: global.source || "https://wa.me/6285795269956",
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m });
}

let handler = async (m, { KazzTzy, text }) => {
    try {
        await m.react(global.react || "⏳");

        if (!text) return sendAIReply(KazzTzy, m, "❌ Masukkan teks untuk AI Realtime.");

        const { data } = await axios.get("https://api-faa.my.id/faa/ai-realtime", {
            params: { text }
        });

        if (!data.status) return sendAIReply(KazzTzy, m, "❌ Gagal mendapatkan respon dari AI Realtime.");

        await KazzTzy.sendMessage(
            m.chat,
            { text: data.result },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e?.response?.data || e.message || e));
    }
};

handler.help = ["ai <text>"];
handler.tags = ["ai"];
handler.command = /^ai$/i;
handler.register = true;
handler.limit = true;

export default handler;