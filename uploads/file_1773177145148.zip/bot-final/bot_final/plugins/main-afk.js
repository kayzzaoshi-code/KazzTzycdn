
import chalk from "chalk";

let handler = async (m, { text, KazzTzy }) => {
  let user = global.db.data.users[m.sender];
  user.afk = +new Date();
  user.afkReason = text;

  const name = KazzTzy.getName(m.sender) || m.sender.split("@")[0];
  await KazzTzy.sendMessage(m.chat, {
    text: [
      "╔══[ AFK MODE ]══╗",
      "",
      "𖣂 " + name + " sekarang AFK",
      text ? "𖣂 Alasan : " + text : "𖣂 Alasan : -",
      "",
      "╚════════════════╝",
    ].join("\n"),
  }, { quoted: m });
};

handler.help    = ["afk [alasan]"];
handler.tags    = ["main"];
handler.command = /^afk$/i;

export default handler;
