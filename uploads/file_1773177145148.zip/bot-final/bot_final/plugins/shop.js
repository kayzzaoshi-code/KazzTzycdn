import axios from 'axios';

let prices = {
    bibitapel: 100,
    bibitjeruk: 100,
    bibitdurian: 150,
    bibitmangga: 120,
    bibitpisang: 80,
    apel: 50,
    jeruk: 50,
    durian: 200,
    mangga: 100,
    pisang: 40,
    sword: 500,
    pickaxe: 400,
    axe: 350,
    fishingrod: 300,
    armor: 700,
    potion: 100,
    string: 20,
    wood: 10,
    rock: 15,
    coal: 25,
    iron: 50,
    diamond: 200,
    emerald: 300,
    trash: 5
};

let handler = async (m, { command, text }) => {
    const user = global.db.data.users[m.sender];
    if (!user) return m.reply('User tidak ditemukan.');

    if (command === 'shop') {
        let pp;
        try {
            let res = await axios.get('https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1772307672874.jpeg', { responseType: 'arraybuffer' });
            pp = Buffer.from(res.data);
        } catch {
            pp = null;
        }

        let shop = `
Z4Z RolePlay Store

bibitapel: 100
bibitjeruk: 100
bibitdurian: 150
bibitmangga: 120
bibitpisang: 80

apel: 50
jeruk: 50
durian: 200
mangga: 100
pisang: 40

sword: 500
pickaxe: 400
axe: 350
fishingrod: 300
armor: 700

potion: 100
string: 20
wood: 10
rock: 15
coal: 25
iron: 50
diamond: 200
emerald: 300
trash: 5
`;

        return await KazzTzy.sendMessage(m.chat, {
            text: shop,
            contextInfo: {
                externalAdReply: {
                    title: 'Z4Z RolePlay Store',
                    body: '',
                    thumbnail: pp,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });
    }

    if (command === 'buy') {
        let [item, amount] = text.split(' ');
        amount = parseInt(amount);

        if (!item || !amount || amount <= 0) return m.reply('Gunakan: .buy <item> <jumlah>');
        item = item.toLowerCase();

        if (!prices[item]) return m.reply('Item tidak ditemukan di shop.');

        let cost = prices[item] * amount;
        if (user.money < cost) return m.reply('Uang tidak cukup.');

        user.money -= cost;
        user[item] = (user[item] || 0) + amount;

        return m.reply(`Berhasil membeli ${amount} ${item} seharga ${cost} money.`);
    }
};

handler.help = ['shop', 'buy'];
handler.tags = ['rpg'];
handler.command = /^(shop|buy)$/i;

export default handler;