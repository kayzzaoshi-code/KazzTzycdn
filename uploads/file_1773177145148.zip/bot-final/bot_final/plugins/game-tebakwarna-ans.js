import { sessions } from "./game-tebakwarna.js";

export function before(m) {
  if (!m.text || m.isBaileys) return true;
  const session = sessions[m.chat];
  if (!session) return true;
  if (m.text.trim().toLowerCase() !== session.jawaban) return true;

  clearTimeout(session.timeout);
  delete sessions[m.chat];

  const user = global.db.data.users[m.sender];
  if (user) { user.limit += 4; user.money += 350; user.exp += 70; }

  KazzTzy.sendMessage(m.chat, {
    text: "╔══[ BENAR! ]══╗\n\n𖣂 " + (KazzTzy.getName(m.sender) || m.sender.split("@")[0]) + " menang!\n𖣂 +4 Limit | +350 Uang | +70 EXP\n╚══════════════╝"
  }, { quoted: m });
  return false;
}
