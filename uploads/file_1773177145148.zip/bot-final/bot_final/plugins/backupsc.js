import fs from 'fs'
import { promisify } from 'util'
import cp from 'child_process'

let exec_ = promisify(cp.exec).bind(cp)

const OWNER_JID = '6283167295612@s.whatsapp.net'

let handler = async (m, { conn }) => {
  await KazzTzy.sendMessage(
    m.chat,
    { text: '✨ Sedang memulai proses backup. Harap tunggu...' },
    { quoted: m }
  )

  try {
    let zipFileName = 'NagiSeishro.zip'
    await exec_(`zip -r ${zipFileName} * -x "node_modules/*"`)

    if (!fs.existsSync(zipFileName)) {
      return KazzTzy.sendMessage(
        m.chat,
        { text: '❌ File zip tidak ditemukan.' },
        { quoted: m }
      )
    }

    const fileBuffer = fs.readFileSync(zipFileName)

    await KazzTzy.sendMessage(
      OWNER_JID,
      {
        document: fileBuffer,
        mimetype: 'application/zip',
        fileName: zipFileName,
        caption: '✅ Backup source code'
      }
    )

    await KazzTzy.sendMessage(
      m.chat,
      { text: '✅ Backup berhasil dikirim ke owner.' },
      { quoted: m }
    )

    setTimeout(() => {
      if (fs.existsSync(zipFileName)) fs.unlinkSync(zipFileName)
    }, 5000)
  } catch (err) {
    console.error(err)
    await KazzTzy.sendMessage(
      m.chat,
      { text: '❌ Terjadi kesalahan saat membuat atau mengirim backup.' },
      { quoted: m }
    )
  }
}

handler.help = ['backupsc']
handler.tags = ['owner']
handler.command = /^(backupsc)$/i
handler.owner = true

export default handler