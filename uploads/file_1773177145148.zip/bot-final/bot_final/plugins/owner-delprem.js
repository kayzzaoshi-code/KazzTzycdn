let handler = async (m, { KazzTzy, text }) => {
	if (!text) throw 'Number?.';
	let who;
	if (m.isGroup) {
		if (!m.mentionedJid) throw 'No user mentioned to ban.';
		who = m.mentionedJid[0];
	} else {

		let phoneNumber = text.replace(/[^0-9]/g, ''); // Remove non-numeric characters
		who = phoneNumber + '@s.whatsapp.net';
	}
	let users = global.db.data.users;
	if (users[who]) {
		users[who].premium = false;
		users[who].premiumTime = 0;
		KazzTzy.reply(m.chat, 'Done!', m);
	} else {
		throw 'User not found.';
	}
};

handler.help = ['delprem'];
handler.tags = ['owner'];
handler.command = /^delprem(user)?$/i;
handler.owner = true;

export default handler;
