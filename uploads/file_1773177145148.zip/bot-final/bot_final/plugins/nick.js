import { createCanvas, loadImage } from "canvas";

let handler = async (m, { KazzTzy, text, command }) => {
  try {
    if (!m.quoted) return m.reply(`Reply foto dengan perintah .${command} <nick>`);

    let nick = text || "YOUR NICK";

    let q = m.quoted;
    let mime = (q.msg || q).mimetype || "";
    if (!/image/.test(mime)) return m.reply("Reply foto!");

    const bg = await loadImage("https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1771191256062.jpeg");
    const media = await q.download();
    const userImg = await loadImage(media);

    const canvas = createCanvas(bg.width, bg.height);
    const ctx = canvas.getContext("2d");

    ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

    const circleSize = 130;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, circleSize, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();

    const scale = Math.max((circleSize * 2 + 20) / userImg.width, (circleSize * 2 + 20) / userImg.height);
    const imgWidth = userImg.width * scale;
    const imgHeight = userImg.height * scale;

    ctx.drawImage(
      userImg,
      0, 0, userImg.width, userImg.height,
      centerX - imgWidth / 2,
      centerY - imgHeight / 2,
      imgWidth,
      imgHeight
    );
    ctx.restore();

    ctx.beginPath();
    ctx.arc(centerX, centerY, circleSize + 5, 0, Math.PI * 2);
    ctx.lineWidth = 4;
    ctx.strokeStyle = "#fff";
    ctx.stroke();

    ctx.save();
    ctx.fillStyle = "#fff";
    ctx.strokeStyle = "#000";
    ctx.lineWidth = 2;

    const maxFontSize = 32;
    const minFontSize = 16;
    let fontSize = maxFontSize;
    if (nick.length > 10) {
      fontSize = Math.max(minFontSize, maxFontSize - (nick.length - 10));
    }
    ctx.font = `bold ${fontSize}px serif`;

    const radius = circleSize + 80;
    drawCircularText(ctx, nick.toUpperCase(), centerX, centerY - 25, radius);
    ctx.restore();

    const buffer = canvas.toBuffer("image/png");
    await KazzTzy.sendMessage(m.chat, { image: buffer }, { quoted: m });

  } catch (e) {
    m.reply(String(e));
  }
};

handler.help = ["nick <text>"];
handler.tags = ["maker"];
handler.command = /^nick$/i;
handler.limit = true;

export default handler;

function drawCircularText(ctx, text, centerX, centerY, radius) {
  const chars = text.split('');
  const n = chars.length;
  const arcSpan = Math.PI * 0.7;
  const angleIncrement = n > 1 ? arcSpan / (n - 1) : 0;
  const start = Math.PI / 2 + arcSpan / 2;

  for (let i = 0; i < n; i++) {
    const char = chars[i];
    const angle = start - i * angleIncrement;
    const x = centerX + Math.cos(angle) * radius;
    const y = centerY + Math.sin(angle) * radius;

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle - Math.PI / 2);
    ctx.strokeText(char, 0, 0);
    ctx.fillText(char, 0, 0);
    ctx.restore();
  }
}