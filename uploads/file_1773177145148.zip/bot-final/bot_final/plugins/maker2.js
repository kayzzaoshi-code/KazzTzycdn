import axios from 'axios';
const GH_TOKEN = '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';
const GH_OWNER = 'kayzzaoshi-code';
const GH_REPO = 'Uploader';
async function createRepo() {
  try { await axios.post('https://api.github.com/user/repos', { name: GH_REPO, private: false }, { headers: { Authorization: `token ${GH_TOKEN}` } }); } catch {}
}
async function uploadToGitHub(buffer, mimetype = 'application/octet-stream') {
  await createRepo();
  const ext = mimetype.split('/')[1] || 'bin';
  const filename = `file_${Date.now()}.${ext}`;
  const res = await axios.put(`https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${filename}`, { message: `Upload ${filename}`, content: Buffer.from(buffer).toString('base64') }, { headers: { Authorization: `token ${GH_TOKEN}` } });
  return res.data.content.download_url;
}

const styles = [
  "superhd","toanime","tobabi","toblonde","tobotak","tobrewok",
  "tochibi","todpr","todubai","tofigura","toghibli","tohijab",
  "tohitam","tojapanese","tokacamata","tokamboja","tolego","toliquor",
  "tomaid","tomangu","tomaya","tomekah","tomirror","tomoai",
  "tomonyet","topacarv2","topeci","topiramida","topolaroid",
  "topunk","toputih","toreal","toroblox","toroh","tosad",
  "tosatan","tosdmtinggi","tosingapura","tostreetwear","totato",
  "toturky","tounderground","toviking","tovintage","tozombie"
];

let handler = async (m, { KazzTzy, usedPrefix, command }) => {
    try {
        await m.react(global.react || '⏳');

        const q = m.quoted || m;
        const mime = (q.msg || q).mimetype || "";
        if (!mime.startsWith("image/")) return m.reply(`Contoh penggunaan:\n\n${usedPrefix + command}\nReply gambar`);

        const buffer = await q.download();
        const uploadedUrl = await uploadToGitHub(buffer, mime);
        if (!uploadedUrl) return m.reply("Upload gagal.");

        const res = await axios.get(
            `https://api-faa.my.id/faa/${command}?url=${encodeURIComponent(uploadedUrl)}`,
            { responseType: "arraybuffer", timeout: 60000 }
        );

        await KazzTzy.sendMessage(
            m.chat,
            {
                image: Buffer.from(res.data),
                caption: command.toUpperCase()
            },
            { quoted: m }
        );

        await m.react(global.reactSuccess || '✅');
    } catch (e) {
        await m.react(global.reactError || '❌');
        m.reply(String(e?.response?.data || e.message || e));
    }
};

handler.help = styles;
handler.tags = ["maker"];
handler.command = new RegExp(`^(${styles.join("|")})$`, "i");
handler.register = true;
handler.limit = true;

export default handler;
