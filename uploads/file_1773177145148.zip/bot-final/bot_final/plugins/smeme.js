import { createCanvas, loadImage } from "canvas";
import { Sticker, StickerTypes } from "wa-sticker-formatter";

let handler = async (m, { KazzTzy, text, command }) => {
    try {
        await m.react(global.react || "⏳");

        if (!m.quoted)
            return m.reply(`Balas gambar dengan perintah:\n.${command} <teks atas>|<teks bawah>`);

        let [atas, bawah] = text ? text.split("|") : [];
        atas = (atas || "").toUpperCase();
        bawah = (bawah || "").toUpperCase();

        let q = m.quoted;
        let mime = (q.msg || q).mimetype || "";
        if (!/image/.test(mime)) return m.reply("❌ Hanya bisa gambar!");

        let media = await q.download();
        let image = await loadImage(media);

        const canvas = createCanvas(image.width, image.height);
        const ctx = canvas.getContext("2d");

        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

        let fontSize = Math.floor(canvas.width / 10);

        ctx.font = `bold ${fontSize}px Impact`;
        ctx.textAlign = "center";
        ctx.fillStyle = "white";
        ctx.strokeStyle = "black";
        ctx.lineWidth = fontSize / 15;

        const wrap = (txt) => {
            let words = txt.split(" ");
            let line = "";
            let lines = [];
            for (let word of words) {
                let test = line + word + " ";
                if (ctx.measureText(test).width > canvas.width - 20) {
                    lines.push(line);
                    line = word + " ";
                } else line = test;
            }
            lines.push(line);
            return lines;
        };

        if (atas) {
            let lines = wrap(atas);
            lines.forEach((l, i) => {
                ctx.strokeText(l.trim(), canvas.width / 2, fontSize + 10 + i * fontSize);
                ctx.fillText(l.trim(), canvas.width / 2, fontSize + 10 + i * fontSize);
            });
        }

        if (bawah) {
            let lines = wrap(bawah);
            let lineHeight = fontSize;
            let totalHeight = lines.length * lineHeight;
            let startY = canvas.height - totalHeight + fontSize * 2;

            if (startY + totalHeight > canvas.height - 5)
                startY = canvas.height - totalHeight - 5;

            lines.forEach((l, i) => {
                ctx.strokeText(l.trim(), canvas.width / 2, startY + i * lineHeight);
                ctx.fillText(l.trim(), canvas.width / 2, startY + i * lineHeight);
            });
        }

        const buffer = canvas.toBuffer("image/png");

        const sticker = new Sticker(buffer, {
            pack: global.packname || "KazzTzy",
            author: global.author || "Bot",
            type: StickerTypes.FULL,
            quality: 100
        });

        await KazzTzy.sendMessage(
            m.chat,
            { sticker: await sticker.toBuffer() },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e));
    }
};

handler.help = ["smeme <teks atas>|<teks bawah>"];
handler.tags = ["maker"];
handler.command = /^smeme$/i;
handler.register = true;
handler.limit = true;

export default handler;