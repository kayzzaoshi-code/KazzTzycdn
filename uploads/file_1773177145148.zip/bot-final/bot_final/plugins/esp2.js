import axios from 'axios';
const GH_TOKEN = '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';
const GH_OWNER = 'kayzzaoshi-code';
const GH_REPO = 'Uploader';
async function createRepo() {
  try { await axios.post('https://api.github.com/user/repos', { name: GH_REPO, private: false }, { headers: { Authorization: `token ${GH_TOKEN}` } }); } catch {}
}
async function uploadToGitHub(buffer, mimetype = 'application/octet-stream') {
  await createRepo();
  const ext = mimetype.split('/')[1] || 'bin';
  const filename = `file_${Date.now()}.${ext}`;
  const res = await axios.put(`https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${filename}`, { message: `Upload ${filename}`, content: Buffer.from(buffer).toString('base64') }, { headers: { Authorization: `token ${GH_TOKEN}` } });
  return res.data.content.download_url;
}

import cheerio from 'cheerio'
import { v4 as uuidv4 } from 'uuid'

class EspChat {
  constructor() {
    this.baseUrl = 'https://chatespanolaigratis.com/en/'
    this.ajaxUrl = 'https://chatespanolaigratis.com/wp-admin/admin-ajax.php'
    this.headers = {
      'User-Agent': 'Mozilla/5.0',
      'Origin': 'https://chatespanolaigratis.com',
      'Referer': this.baseUrl
    }
    this.nonce = null
    this.botId = null
    this.postId = null
  }

  async refreshTokens() {
    const { data } = await axios.get(this.baseUrl)

    const $ = cheerio.load(data)
    const container = $('div[id^="aipkit_chat_container_"]')
    const config = JSON.parse(container.attr('data-config'))

    this.nonce = config.nonce
    this.botId = config.botId
    this.postId = config.postId
  }

  async sendMessage(message) {
    if (!this.nonce) await this.refreshTokens()

    const form = new FormData()
    form.append('action', 'aipkit_frontend_chat_message')
    form.append('_ajax_nonce', this.nonce)
    form.append('bot_id', this.botId)
    form.append('post_id', this.postId)
    form.append('message', message)
    form.append('session_id', uuidv4())
    form.append('conversation_uuid', uuidv4())

    const { data } = await axios.post(this.ajaxUrl, form, {
      headers: { ...this.headers, ...form.getHeaders() }
    })

    return (data.data?.reply || data.data?.response || '')
      .replace(/<[^>]*>?/gm, '')
      .trim()
  }
}

const KazzTzy = new EspChat()

const handler = async (m, { text, reply }) => {
  if (!text) return reply('masukkan pertanyaan')

  try {
    await m.react('⏳')

    const response = await KazzTzy.sendMessage(text)

    await m.react('✅')
    reply(response || 'tidak ada respon')

  } catch (e) {
    await m.react('❌')
    reply('error')
  }
}

handler.help = ['esp']
handler.tags = ['ai']
handler.command = /^(esp2)$/i
handler.register = true
handler.limit = true

export default handler
