import axios from "axios"

const base = "https://api.webpilotai.com/rupee/v1/search"

const headers = {
    accept: "application/json, text/plain, */*, text/event-stream",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    authorization: "Bearer null",
    "content-type": "application/json;charset=UTF-8",
    origin: "https://www.webpilot.ai",
    referer: "https://www.webpilot.ai/",
    "user-agent": "Mozilla/5.0"
}

function createParser(onEvent) {
    let buffer = ""

    return (chunk) => {
        buffer += chunk

        const lines = buffer.split("\n")
        buffer = lines.pop()

        for (const line of lines) {
            const trimmed = line.trim()
            if (!trimmed.startsWith("data:")) continue

            const raw = trimmed.slice(5).trim()

            if (raw === "[DONE]") {
                onEvent({ done: true })
                continue
            }

            try {
                onEvent({
                    done: false,
                    data: JSON.parse(raw)
                })
            } catch {
                onEvent({
                    done: false,
                    raw
                })
            }
        }
    }
}

let handler = async (m, { text }) => {
    if (!text) return m.reply("Masukkan query pencarian")

    await m.react("⏳")

    try {
        const res = await axios.post(
            base,
            {
                q: text,
                threadId: ""
            },
            {
                headers,
                responseType: "stream",
                timeout: 60000
            }
        )

        let hasil = ""
        let sumber = []

        const parse = createParser((event) => {
            if (event.done) return

            if (event.raw) return

            const { type, data, action } = event.data

            if (type === "action" && action === "using_internet") {
                sumber.push(`• ${data.title}\n  ${data.link}`)
                return
            }

            if (type === "data" && data?.content !== undefined) {
                hasil += data.content
            }
        })

        res.data.setEncoding("utf8")
        res.data.on("data", parse)

        await new Promise((resolve, reject) => {
            res.data.on("end", resolve)
            res.data.on("error", reject)
        })

        if (!hasil) {
            await m.react("❌")
            return m.reply("Tidak ada hasil")
        }

        let replyText = hasil

        if (sumber.length) {
            replyText += "\n\nSumber:\n" + sumber.join("\n\n")
        }

        await m.reply(replyText)
        await m.react("✅")

    } catch (err) {
        await m.react("❌")
        m.reply("Terjadi kesalahan")
    }
}

handler.help = ["webpilot"]
handler.tags = ["tools"]
handler.command = ["webpilot"]

export default handler