let handler = async (m) => {
    const user = global.db.data.users[m.sender];
    if (!user) return m.reply('User tidak ditemukan.');

    if (m.text === '.ceksaldo') {
        return m.reply(`Saldo Kamu: ${user.money || 0}`);
    }

    if (m.text === '.ceklimit') {
        return m.reply(`Limit Kamu: ${user.limit || 0}`);
    }
};

handler.help = ['ceksaldo', 'ceklimit'];
handler.tags = ['info'];
handler.command = /^(ceksaldo|ceklimit)$/i;

export default handler;