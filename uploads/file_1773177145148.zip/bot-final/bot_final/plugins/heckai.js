import axios from "axios";
import { v4 as uuidv4 } from "uuid";

async function sendAIReply(KazzTzy, m, text) {
  return KazzTzy.sendMessage(m.chat, {
    text: String(text),
    mentions: [m.sender],
    contextInfo: {
      externalAdReply: {
        title: "Z4Z Bot",
        body: "KazzTzy",
        thumbnailUrl: "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1772016271450.jpeg",
        sourceUrl: global.source || "https://wa.me/6285795269956",
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m });
}

let handler = async (m, { KazzTzy, text }) => {
    try {
        await m.react(global.react || "⏳");
        if (!text) return sendAIReply(KazzTzy, m, "❌ Masukkan teks.");

        const sessionId = uuidv4();

        const res = await axios.post(
            "https://api.heckai.weight-wave.com/api/ha/v1/chat",
            {
                model: "meta-llama/llama-4-scout",
                question: text,
                language: "Indonesian",
                sessionId: sessionId,
                previousQuestion: text,
                previousAnswer: null
            },
            {
                headers: {
                    "Content-Type": "application/json"
                },
                responseType: "stream"
            }
        );

        let answer = "";

        await new Promise((resolve, reject) => {
            res.data.on("data", (chunk) => {
                const lines = chunk.toString().split("\n");
                for (let line of lines) {
                    if (line.startsWith("data: ")) {
                        const data = line.replace("data: ", "").trim();
                        if (
                            data &&
                            !data.startsWith("[") &&
                            !data.includes("✩")
                        ) {
                            answer += data;
                        }
                    }
                }
            });

            res.data.on("end", resolve);
            res.data.on("error", reject);
        });

        if (!answer) answer = "Tidak ada respon.";

        await KazzTzy.sendMessage(
            m.chat,
            { text: answer.trim() },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");
    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e?.response?.data || e.message || e));
    }
};

handler.help = ["heckai <teks>"];
handler.tags = ["ai"];
handler.command = /^heckai$/i;
handler.register = true;
handler.limit = true;

export default handler;