import axios from "axios";
import unzipper from "unzipper";

const TOKEN = "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";
const OWNER = "KazzTzyPrivat7777";

async function createRepo(repo) {
  try {
    await axios.post(
      "https://api.github.com/user/repos",
      { name: repo, private: false },
      { headers: { Authorization: `token ${TOKEN}` } }
    );
  } catch {}
}

async function uploadFileToGitHub(repo, filename, buffer) {
  const url = `https://api.github.com/repos/${OWNER}/${repo}/contents/${filename}`;

  let sha = null;
  try {
    const check = await axios.get(url, {
      headers: { Authorization: `token ${TOKEN}` }
    });
    sha = check.data.sha;
  } catch {}

  const data = {
    message: sha ? `Update ${filename}` : `Upload ${filename}`,
    content: buffer.toString("base64"),
    ...(sha && { sha })
  };

  const res = await axios.put(url, data, {
    headers: { Authorization: `token ${TOKEN}` }
  });

  return res.data.content.download_url;
}

let handler = async (m, { KazzTzy, text }) => {
  try {
    if (!text) return m.reply("❌ Format: .uploadzip <namaRepo>");
    const repoName = text.trim();

    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype || "";
    if (!mime.includes("zip"))
      return m.reply("❌ Reply file ZIP untuk diupload.");

    const buffer = await q.download();

    await createRepo(repoName);

    const files = [];
    let rootFolder = null;

    await new Promise((resolve, reject) => {
      const zipStream = unzipper.Parse();

      zipStream.on("entry", async (entry) => {
        if (entry.type === "File") {
          const chunks = [];
          for await (let chunk of entry) chunks.push(chunk);
          const fileBuffer = Buffer.concat(chunks);

          let filePath = entry.path;

          if (!rootFolder) {
            const parts = filePath.split("/");
            if (parts.length > 1) rootFolder = parts[0];
          }

          if (rootFolder && filePath.startsWith(rootFolder + "/")) {
            filePath = filePath.replace(rootFolder + "/", "");
          }

          if (filePath) {
            files.push({
              path: filePath,
              buffer: fileBuffer
            });
          }
        } else {
          entry.autodrain();
        }
      });

      zipStream.on("finish", resolve);
      zipStream.on("error", reject);
      zipStream.end(buffer);
    });

    for (const file of files) {
      await uploadFileToGitHub(repoName, file.path, file.buffer);
    }

    await KazzTzy.sendMessage(
      m.chat,
      { text: `✅ Repo ${repoName} berhasil dibuat & isi ZIP berhasil diupload tanpa folder utama` },
      { quoted: m }
    );

  } catch (e) {
    m.reply("❌ Terjadi kesalahan: " + (e.response?.data?.message || e.message));
  }
};

handler.help = ["uploadzip <namaRepo>"];
handler.tags = ["tools"];
handler.command = /^(uploadzip)$/i;
handler.owner = true;

export default handler;