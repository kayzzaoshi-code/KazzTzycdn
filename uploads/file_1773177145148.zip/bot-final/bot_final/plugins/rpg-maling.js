let stealCooldown = {};

let handler = async (m) => {
    let user = global.db.data.users[m.sender];
    if (!user.registered) return m.reply('Kamu belum registrasi! Gunakan .daftar <nama>.<umur>');

    let now = Date.now();
    let cooldown = 5 * 60 * 1000;
    if (!stealCooldown[m.sender]) stealCooldown[m.sender] = 0;
    let diff = now - stealCooldown[m.sender];
    if (diff < cooldown) return m.reply(`Tunggu ${Math.ceil((cooldown - diff)/1000)} detik lagi untuk mencuri`);

    stealCooldown[m.sender] = now;

    let users = Object.values(global.db.data.users).filter(u => u.registered && u !== user);
    if (users.length === 0) return m.reply('Tidak ada target untuk dicuri');

    let target = users[Math.floor(Math.random() * users.length)];

    let berhasil = Math.random() < 0.6;

    if (!target.money || target.money <= 0) {
        m.reply(`Target ${target.name} tidak memiliki uang`);
        return;
    }

    if (berhasil) {
        let ambil = Math.floor(Math.random() * target.money/2) + 1;
        target.money -= ambil;
        user.money = (user.money || 0) + ambil;
        let limitGain = Math.floor(Math.random() * 3) + 1;
        let expGain = Math.floor(Math.random() * 10) + 5;
        user.limit = (user.limit || 0) + limitGain;
        user.exp = (user.exp || 0) + expGain;
        m.reply(`
*—[ Mencuri Berhasil ]—*
Target: ${target.name}
💹 Money Didapat: ${ambil}
✨ Limit Didapat: ${limitGain}
⚡ Exp Didapat: ${expGain}
`);
    } else {
        let denda = Math.floor(Math.random() * 500) + 100;
        user.money = Math.max((user.money || 0) - denda, 0);
        m.reply(`
*—[ Mencuri Gagal ]—*
Kamu ketahuan!
💹 Denda Money: ${denda}
`);
    }
};

handler.help = ['maling'];
handler.tags = ['game'];
handler.command = /^(maling)$/i;

export default handler;