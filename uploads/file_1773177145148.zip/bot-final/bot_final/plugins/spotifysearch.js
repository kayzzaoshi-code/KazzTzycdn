import axios from 'axios'

const SPOTIFY_CLIENT_ID = '4c4fc8c3496243cbba99b39826e2841f'
const SPOTIFY_CLIENT_SECRET = 'd598f89aba0946e2b85fb8aefa9ae4c8'

const convert = ms => {
 const m = Math.floor(ms / 60000)
 const s = ((ms % 60000) / 1000).toFixed(0)
 return m + ':' + (s < 10 ? '0' : '') + s
}

async function spotifyToken() {
 const { data } = await axios.post(
  'https://accounts.spotify.com/api/token',
  'grant_type=client_credentials',
  {
   headers: {
    Authorization:
     'Basic ' +
     Buffer.from(
      SPOTIFY_CLIENT_ID + ':' + SPOTIFY_CLIENT_SECRET
     ).toString('base64'),
    'Content-Type': 'application/x-www-form-urlencoded'
   }
  }
 )
 return data.access_token
}

async function searchSpotify(query) {
 const token = await spotifyToken()

 const { data } = await axios.get(
  `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=10`,
  { headers: { Authorization: `Bearer ${token}` } }
 )

 if (!data.tracks.items.length)
  throw new Error('Lagu tidak ditemukan')

 return data.tracks.items.map(v => ({
  title: `${v.artists.map(a => a.name).join(', ')} - ${v.name}`,
  duration: convert(v.duration_ms),
  popularity: v.popularity,
  url: v.external_urls.spotify
 }))
}

let handler = async (m, { text, usedPrefix, command }) => {
 try {
  if (!text)
   return m.reply(
    `Cara pakai:\n${usedPrefix + command} judul lagu`
   )

  await m.react('⏳')

  const results = await searchSpotify(text)

  let msg = `🎵 *Hasil pencarian Spotify*\n\n`
  results.forEach((v, i) => {
   msg += `${i + 1}. ${v.title}\n`
   msg += `⏱ ${v.duration} | 🔥 ${v.popularity}%\n`
   msg += `${v.url}\n\n`
  })

  await m.reply(msg.trim())
  await m.react('✅')

 } catch (e) {
  await m.react('❌')
  m.reply('Error: ' + e.message)
 }
}

handler.help = ['spotify <judul>']
handler.command = ['spotifysearch', 'spsearch']
handler.tags = ['tools']
handler.limit = true
handler.register = true

export default handler