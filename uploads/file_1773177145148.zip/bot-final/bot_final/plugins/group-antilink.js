const WARN_DEFAULT = 3;

function getWarn(chat) {
  return chat?.warnLimit || WARN_DEFAULT;
}

async function handleViolation(KazzTzy, m, chat, reason) {
  if (!chat.warns) chat.warns = {};
  const jid = m.sender;
  chat.warns[jid] = (chat.warns[jid] || 0) + 1;
  const warnLimit = getWarn(chat);
  const current = chat.warns[jid];

  if (current >= warnLimit) {
    chat.warns[jid] = 0;
    try {
      await KazzTzy.groupParticipantsUpdate(m.chat, [jid], "remove");
      await KazzTzy.sendMessage(m.chat, {
        text: "𖣂 @" + jid.split("@")[0] + " di-kick karena melanggar " + warnLimit + "x\n𖣂 Alasan: " + reason,
        mentions: [jid]
      });
    } catch {
      await KazzTzy.sendMessage(m.chat, {
        text: "𖣂 @" + jid.split("@")[0] + " warn " + current + "/" + warnLimit + " - " + reason + "\n(Gagal kick, bot bukan admin)",
        mentions: [jid]
      });
    }
  } else {
    try { await KazzTzy.sendMessage(m.chat, { delete: m.key }); } catch {}
    await KazzTzy.sendMessage(m.chat, {
      text: "𖣂 @" + jid.split("@")[0] + " peringatan " + current + "/" + warnLimit + "\n𖣂 Alasan: " + reason,
      mentions: [jid]
    });
  }
}

let handler = async (m, { KazzTzy, text, args, isOwner, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return m.reply("𖣂 Hanya di grup.");
  if (!isOwner && !isAdmin) return m.reply("𖣂 Hanya owner/admin.");

  const chats = global.db.data.chats;
  if (!chats[m.chat]) chats[m.chat] = {};
  const chat = chats[m.chat];

  const cmd = (m.text || "").trim().split(" ")[0].replace(/^[^a-zA-Z]*/, "").toLowerCase();
  const sub = (args[0] || "").toLowerCase();
  const val = (args[1] || "").toLowerCase();

  if (cmd === "antilinkch") {
    if (!["on", "off"].includes(sub)) return m.reply("𖣂 .antilinkch on/off");
    chat.antilinkch = sub === "on";
    return m.reply("𖣂 Antilink Channel: " + (chat.antilinkch ? "ON" : "OFF"));
  }

  if (cmd === "antilinkgroup") {
    if (!["on", "off"].includes(sub)) return m.reply("𖣂 .antilinkgroup on/off");
    chat.antilinkgroup = sub === "on";
    return m.reply("𖣂 Antilink Grup: " + (chat.antilinkgroup ? "ON" : "OFF"));
  }

  if (cmd === "antipromosi") {
    if (sub === "on" || sub === "off") {
      chat.antipromosi = sub === "on";
      return m.reply("𖣂 Antipromosi: " + (chat.antipromosi ? "ON" : "OFF"));
    }
    if (sub === "add") {
      if (!val) return m.reply("𖣂 .antipromosi add <kata>");
      if (!chat.promosiList) chat.promosiList = [];
      if (!chat.promosiList.includes(val)) chat.promosiList.push(val);
      return m.reply("𖣂 Kata promosi ditambah: " + val);
    }
    if (sub === "list") {
      return m.reply(!chat.promosiList?.length ? "𖣂 List kosong." : "𖣂 List:\n" + chat.promosiList.join(", "));
    }
    return m.reply("𖣂 .antipromosi on/off/add/list");
  }

  if (cmd === "antitoxic") {
    if (!["on", "off"].includes(sub)) return m.reply("𖣂 .antitoxic on/off");
    chat.antitoxic = sub === "on";
    return m.reply("𖣂 Anti Toxic: " + (chat.antitoxic ? "ON" : "OFF"));
  }

  if (cmd === "antilinkall") {
    if (sub === "on" || sub === "off") {
      chat.antilinkall = sub === "on";
      return m.reply("𖣂 Antilink Semua: " + (chat.antilinkall ? "ON" : "OFF"));
    }
    if (sub === "add") {
      if (!val) return m.reply("𖣂 .addantilink <link>");
      if (!chat.antiLinkList) chat.antiLinkList = [];
      if (!chat.antiLinkList.includes(val)) chat.antiLinkList.push(val);
      return m.reply("𖣂 Link ditambah ke daftar larangan: " + val);
    }
    return m.reply("𖣂 .antilinkall on/off");
  }

  if (cmd === "addantilink") {
    const link = text;
    if (!link) return m.reply("𖣂 .addantilink <link/kata>");
    if (!chat.antiLinkList) chat.antiLinkList = [];
    if (!chat.antiLinkList.includes(link)) chat.antiLinkList.push(link);
    return m.reply("𖣂 Ditambah: " + link);
  }

  if (cmd === "setwarn") {
    const n = parseInt(sub);
    if (isNaN(n) || n < 1) return m.reply("𖣂 .setwarn <angka>\nContoh: .setwarn 6");
    chat.warnLimit = n;
    return m.reply("𖣂 Batas warn diset ke " + n + "x sebelum kick.");
  }

  m.reply(
    "╔══[ ANTILINK SETTINGS ]══╗\n" +
    "𖣂 .antilinkch on/off\n" +
    "𖣂 .antilinkgroup on/off\n" +
    "𖣂 .antilinkall on/off\n" +
    "𖣂 .addantilink <link>\n" +
    "𖣂 .antipromosi on/off\n" +
    "𖣂 .antipromosi add <kata>\n" +
    "𖣂 .antipromosi list\n" +
    "𖣂 .antitoxic on/off\n" +
    "𖣂 .setwarn <angka>\n" +
    "╚═════════════════════════╝"
  );
};

handler.before = async function (m) {
  if (!m.isGroup || !m.text || m.isBaileys) return true;

  const isOwner = global.owner.map(([n]) => n + "@s.whatsapp.net").includes(m.sender) || m.fromMe;
  if (isOwner) return true;

  const chat = global.db.data.chats?.[m.chat];
  if (!chat) return true;

  const groupMetadata = await KazzTzy.groupMetadata(m.chat).catch(() => null);
  const participants = groupMetadata?.participants || [];
  const isAdmin = participants.find(p => p.id === m.sender)?.admin;
  if (isAdmin) return true;

  const text = m.text || "";

  if (chat.antilinkch) {
    const chRegex = /https?:\/\/(?:www\.)?whatsapp\.com\/channel\/[a-zA-Z0-9]+/gi;
    if (chRegex.test(text)) {
      await handleViolation(KazzTzy, m, chat, "Link channel WhatsApp");
      return false;
    }
  }

  if (chat.antilinkgroup) {
    const gcRegex = /chat\.whatsapp\.com\/[a-zA-Z0-9]+/gi;
    if (gcRegex.test(text)) {
      await handleViolation(KazzTzy, m, chat, "Link grup WhatsApp");
      return false;
    }
  }

  if (chat.antilinkall) {
    const urlRegex = /https?:\/\/[^\s]+/gi;
    if (urlRegex.test(text)) {
      if (chat.antiLinkList?.length) {
        const matched = chat.antiLinkList.some(l => text.toLowerCase().includes(l.toLowerCase()));
        if (matched) {
          await handleViolation(KazzTzy, m, chat, "Link terlarang");
          return false;
        }
      } else {
        await handleViolation(KazzTzy, m, chat, "Link tidak diizinkan");
        return false;
      }
    }
  }

  if (chat.antipromosi) {
    const defaultPromo = ["gabung", "daftar", "join", "promo", "diskon", "jualan", "jual", "beli", "order", "wa.me/", "bit.ly", "s.id/"];
    const promoList = [...defaultPromo, ...(chat.promosiList || [])];
    const lower = text.toLowerCase();
    const matched = promoList.some(k => lower.includes(k));
    if (matched) {
      await handleViolation(KazzTzy, m, chat, "Promosi tidak diizinkan");
      return false;
    }
  }

  if (chat.antitoxic) {
    const toxicWords = [
      "anjing", "anjrit", "bangsat", "kontol", "goblok", "tolol", "babi",
      "peler", "itil", "memek", "jancok", "asu", "bajingan", "kampret",
      "keparat", "tai", "kentut", "brengsek", "setan", "sialan", "lonte",
      "pelacur", "sundal", "bejat", "bacot", "cok", "ngentot", "entot",
      "ngewe", "jembut", "pantat", "bokong", "pepek", "titit", "idiot",
      "bodoh", "dungu", "monyet", "kadal", "ular", "kurang ajar", "bego"
    ];
    const lower = text.toLowerCase();
    const matched = toxicWords.some(w => lower.includes(w));
    if (matched) {
      await handleViolation(KazzTzy, m, chat, "Kata kasar/toxic");
      return false;
    }
  }

  return true;
};

handler.help = ["antilinkch", "antilinkgroup", "antilinkall", "addantilink", "antipromosi", "antitoxic", "setwarn"];
handler.tags = ["group"];
handler.command = /^(antilinkch|antilinkgroup|antipromosi|antitoxic|antilinkall|addantilink|setwarn)$/i;

export default handler;
