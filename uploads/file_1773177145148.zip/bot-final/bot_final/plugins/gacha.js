let handler = async (m, { text }) => {
    const user = global.db.data.users[m.sender];
    if (!user) return m.reply('User tidak ditemukan.');

    let cost = parseInt(text);
    if (!cost || cost <= 0) return m.reply('Gunakan: .gacha <nominal>');
    if (user.money < cost) return m.reply('Uang tidak cukup.');

    user.money -= cost;

    const boxes = ['divine', 'mythic', 'heroic', 'elite', 'standard'];
    const box = boxes[Math.floor(Math.random() * boxes.length)];

    let reward = {};
    let msg = '';

    switch (box) {
        case 'divine':
            reward.money = randomRange(5000, 10000);
            reward.limit = randomRange(5, 10);
            msg = `Divine Box\n+${reward.money} Money\n+${reward.limit} Limit`;
            break;

        case 'mythic':
            reward.money = randomRange(3000, 6000);
            reward.limit = randomRange(3, 6);
            msg = `Mythic Box\n+${reward.money} Money\n+${reward.limit} Limit`;
            break;

        case 'heroic':
            reward.money = randomRange(1500, 3500);
            reward.limit = randomRange(2, 4);
            msg = `Heroic Box\n+${reward.money} Money\n+${reward.limit} Limit`;
            break;

        case 'elite':
            reward.money = randomRange(500, 2000);
            reward.limit = randomRange(1, 3);
            msg = `Elite Box\n+${reward.money} Money\n+${reward.limit} Limit`;
            break;

        case 'standard':
            if (Math.random() < 0.35) {
                reward.money = randomRange(200, 800);
                msg = `Standard Box\n+${reward.money} Money`;
            } else {
                if (Math.random() < 0.5) {
                    msg = 'Zonk Besar! Kamu kehilangan kesempatan.';
                } else {
                    msg = 'Zonk! Tidak mendapatkan apa apa.';
                }
            }
            break;
    }

    if (reward.money) user.money += reward.money;
    if (reward.limit) user.limit = (user.limit || 0) + reward.limit;

    m.reply(`Gacha Result: ${box}\n${msg}`);
};

function randomRange(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

handler.help = ['gacha'];
handler.tags = ['rpg'];
handler.command = /^gacha$/i;

export default handler;