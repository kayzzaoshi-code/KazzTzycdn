import { sessions } from "./game-family100.js";

export function before(m) {
  if (!m.text || m.isBaileys) return true;
  const session = sessions[m.chat];
  if (!session) return true;

  const jawab = m.text.trim().toLowerCase();
  if (!session.jawabanList.includes(jawab)) return true;
  if (session.found.includes(jawab)) return true;

  session.found.push(jawab);

  const user = global.db.data.users[m.sender];
  if (user) { user.limit += 2; user.money += 200; user.exp += 40; }

  const sisa = session.total - session.found.length;

  if (sisa <= 0) {
    clearTimeout(session.timeout);
    delete sessions[m.chat];
    KazzTzy.sendMessage(m.chat, {
      text: "╔══[ FAMILY 100 SELESAI! ]══╗\n\n𖣂 " + (KazzTzy.getName(m.sender) || m.sender.split("@")[0]) + " melengkapi jawaban terakhir!\n𖣂 Semua " + session.total + " jawaban ditemukan!\n╚═══════════════════════════╝"
    }, { quoted: m });
  } else {
    KazzTzy.sendMessage(m.chat, {
      text: "𖣂 *" + jawab + "* BENAR! (+2L +200U +40EXP)\n𖣂 Sisa " + sisa + "/" + session.total + " jawaban."
    }, { quoted: m });
  }

  return false;
}
