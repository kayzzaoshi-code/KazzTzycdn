import fs from "fs"
import path from "path"

let handler = async (m, { KazzTzy }) => {
    const targetUrl = "https://kayzzidgf.my.id/";

    await KazzTzy.sendMessage(m.chat, {
        text: targetUrl,
        contextInfo: {
            externalAdReply: {
                title: global.namaChannel,
                body: global.bodyChannel,
                mediaType: 2,
                thumbnail: fs.readFileSync(path.join("./media/menu.jpg")),
                sourceUrl: global.sourceurl
            }
        }
    }, { quoted: m });
}

handler.help = ['restapi'];
handler.tags = ['main'];
handler.command = /^(restapi)$/i;

export default handler;