let handler = async (m, { text }) => {
    const user = global.db.data.users[m.sender];
    if (!user) return m.reply('User tidak ditemukan.');

    let amount = parseInt(text);
    if (!amount || amount <= 0) return m.reply('Gunakan: .buylimit <jumlah>');

    let price = amount * 15;
    if (user.money < price) return m.reply('Uang tidak cukup.');

    user.money -= price;
    user.limit = (user.limit || 0) + amount;

    m.reply(`Berhasil membeli ${amount} limit seharga ${price} money.`);
};

handler.help = ['buylimit'];
handler.tags = ['rpg'];
handler.command = /^buylimit$/i;

export default handler;