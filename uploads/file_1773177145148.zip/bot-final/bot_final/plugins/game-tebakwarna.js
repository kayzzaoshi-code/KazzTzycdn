import axios from "axios";

const API = "https://kayzzidgf.my.id";
export const sessions = {};

let handler = async (m, { KazzTzy, usedPrefix }) => {
  const chat = m.chat;
  if (sessions[chat]) return m.reply("𖣂 Masih ada soal aktif! Jawab dulu atau " + usedPrefix + "stoptebakwarna");

  await m.react(global.react);

  const res = await axios.get(API + "/api/game/tebakwarna?apikey=KazzTzy").catch(() => null);
  if (!res?.data?.status || !res?.data?.data?.image) return m.reply("𖣂 Gagal ambil soal.");

  const data = res.data.data;

  sessions[chat] = {
    jawaban: String(data.correct).toLowerCase(),
    timeout: setTimeout(() => {
      delete sessions[chat];
      KazzTzy.sendMessage(chat, { text: "𖣂 Waktu habis! Jawaban: *" + data.correct + "*" });
    }, 60000)
  };

  await KazzTzy.sendMessage(chat, {
    image: { url: data.image },
    caption: "╔══[ TEBAK WARNA ]══╗\n\n𖣂 Angka berapa yang kamu lihat?\n\n𖣂 Waktu: 60 detik\n𖣂 Hadiah: +4 Limit, +350 Uang, +70 EXP\n╚════════════════════╝"
  }, { quoted: m });

  await m.react(global.reactSuccess);
};

handler.help = ["tebakwarna"];
handler.tags = ["game"];
handler.command = /^tebakwarna$/i;
handler.register = true;
export default handler;
