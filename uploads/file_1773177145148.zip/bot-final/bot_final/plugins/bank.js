import axios from 'axios';

let handler = async (m, { command, text }) => {
    const user = global.db.data.users[m.sender];
    if (!user.bank) user.bank = 0;

    let pp;
    try {
        let res = await axios.get('https://c.termai.cc/i155/P04VRn.jpeg', { responseType: 'arraybuffer' });
        pp = Buffer.from(res.data);
    } catch {
        pp = null;
    }

    if (command === 'bank') {
        let cap = `
_Hello World Selamat Datang Di Bank Z4Z_

💰 Money: ${user.money}
🏦 Bank : ${user.bank}

.atm Untuk Masukkan uang ke Bank
.withdraw Untuk Menarik Uang Di Bank
`;

        return await KazzTzy.sendMessage(
            m.chat,
            {
                text: cap,
                contextInfo: {
                    externalAdReply: {
                        title: "Bank Z4Z",
                        body: "",
                        thumbnail: pp,
                        mediaType: 1,
                        renderLargerThumbnail: true,
                    },
                },
            },
            { quoted: m }
        );
    }

    if (command === 'bankpp') {
        return await KazzTzy.sendMessage(m.chat, {
            image: pp,
            caption: "Bank Z4Z - Profile"
        });
    }

    if (command === 'atm') {
        let amount = parseInt(text);
        if (!amount || amount <= 0) return m.reply('❌ Masukkan jumlah uang.\nContoh: .atm 500');
        if (user.money < amount) return m.reply('❌ Uang kamu tidak cukup.');

        user.money -= amount;
        user.bank += amount;

        return m.reply(`✅ Berhasil deposit ${amount} ke bank.`);
    }

    if (command === 'withdraw') {
        let amount = parseInt(text);
        if (!amount || amount <= 0) return m.reply('❌ Masukkan jumlah uang.\nContoh: .withdraw 500');
        if (user.bank < amount) return m.reply('❌ Saldo bank tidak cukup.');

        user.bank -= amount;
        user.money += amount;

        return m.reply(`✅ Berhasil tarik ${amount} dari bank.`);
    }
};

handler.help = ['bank', 'bankpp', 'atm', 'withdraw'];
handler.tags = ['rpg'];
handler.command = /^(bank|bankpp|atm|withdraw)$/i;

export default handler;