import * as cheerio from "cheerio";

let handler = async (m, { KazzTzy, text }) => {
    try {
        await m.react(global.react || "⏳");

        if (!text) return m.reply("❌ Masukkan URL TikTok.\nContoh:\n.tt https://vt.tiktok.com/...");

        const body = new URLSearchParams({
            q: text,
            cursor: "0",
            page: "0",
            lang: "id"
        }).toString();

        const res = await fetch("https://savetik.io/api/ajaxSearch", {
            method: "POST",
            headers: {
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "x-requested-with": "XMLHttpRequest",
                "user-agent": "Mozilla/5.0",
                "origin": "https://savetik.io",
                "referer": "https://savetik.io/id/download-tiktok-photos",
                "accept": "*/*"
            },
            body
        });

        const json = await res.json();
        const html = typeof json.data === "string" ? json.data : "";

        if (!html) throw "Gagal mengambil data.";

        const $ = cheerio.load(html);

        const mp4 = $('a:contains("Unduh MP4 [1]")').attr("href") ||
                    $('a:contains("Unduh MP4 [2]")').attr("href") ||
                    $('a:contains("Unduh MP4 HD")').attr("href") || null;

        const mp3 = $('a:contains("Unduh MP3")').attr("href") || null;

        const images = [];
        $(".photo-list ul.download-box li").each((_, el) => {
            const img = $(el).find("a[title='Unduh Gambar']").attr("href");
            if (img) images.push(img);
        });

        if (!mp4 && images.length > 0) {
            for (let img of images) {
                await KazzTzy.sendMessage(
                    m.chat,
                    { image: { url: img } },
                    { quoted: m }
                );
            }

            if (mp3) {
                await KazzTzy.sendMessage(
                    m.chat,
                    {
                        audio: { url: mp3 },
                        mimetype: "audio/mpeg",
                        ptt: false
                    },
                    { quoted: m }
                );
            }
        } else if (mp4) {
            await KazzTzy.sendMessage(
                m.chat,
                {
                    video: { url: mp4 },
                    caption: "✅ TikTok Downloader"
                },
                { quoted: m }
            );

            if (mp3) {
                await KazzTzy.sendMessage(
                    m.chat,
                    {
                        audio: { url: mp3 },
                        mimetype: "audio/mpeg",
                        ptt: false
                    },
                    { quoted: m }
                );
            }
        } else {
            throw "Media tidak ditemukan.";
        }

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e?.message || e));
    }
};

handler.help = ["tt <url>", "tiktok <url>", "ttdl <url>", "tiktokdl <url>"];
handler.tags = ["downloader"];
handler.command = /^(tt|tiktok|ttdl|tiktokdl)$/i;
handler.register = true;
handler.limit = true;

export default handler;