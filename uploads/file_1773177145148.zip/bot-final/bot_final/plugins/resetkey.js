import fetch from 'node-fetch';

const API_URL = 'https://kayzzidgf.my.id';
const ADMIN_PASS = '200812';

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Penggunaan:\n${usedPrefix + command} <NamaKey>\n\nContoh:\n${usedPrefix + command} KazzTzy`;

  const key = text.trim();

  let res = await fetch(`${API_URL}/api/apikey/reset`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: ADMIN_PASS, key }),
  });

  let d = await res.json();
  if (!d.success) throw `❌ Gagal reset: ${d.message}`;

  const keyData = d.key;

  m.reply(
    `╔══〔 *RESET LIMIT KEY* 〕══╗\n` +
    `║\n` +
    `║ ✅ Limit berhasil di-reset!\n` +
    `║\n` +
    `║ 🔑 *Key:* ${keyData.key}\n` +
    `║ 📊 *Limit Total:* ${keyData.limit_total}\n` +
    `║ ⚡ *Terpakai:* 0\n` +
    `║ ✨ *Sisa:* ${keyData.limit_total}\n` +
    `║\n` +
    `╚══════════════════════╝`
  );
};

handler.help = ['resetkey <NamaKey>'];
handler.tags = ['owner'];
handler.command = /^resetkey$/i;
handler.owner = true;

export default handler;