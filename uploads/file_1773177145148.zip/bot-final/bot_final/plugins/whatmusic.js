import axios from 'axios';
const GH_TOKEN = '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';
const GH_OWNER = 'kayzzaoshi-code';
const GH_REPO = 'Uploader';
async function createRepo() {
  try { await axios.post('https://api.github.com/user/repos', { name: GH_REPO, private: false }, { headers: { Authorization: `token ${GH_TOKEN}` } }); } catch {}
}
async function uploadToGitHub(buffer, mimetype = 'application/octet-stream') {
  await createRepo();
  const ext = mimetype.split('/')[1] || 'bin';
  const filename = `file_${Date.now()}.${ext}`;
  const res = await axios.put(`https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${filename}`, { message: `Upload ${filename}`, content: Buffer.from(buffer).toString('base64') }, { headers: { Authorization: `token ${GH_TOKEN}` } });
  return res.data.content.download_url;
}

let handler = async (m, { KazzTzy }) => {
    try {
        await m.react(global.react || "⏳");

        const q = m.quoted ? m.quoted : m;
        const mime = (q.msg || q).mimetype || "";

        if (!mime.startsWith("audio/"))
            return m.reply("❌ Reply audio / kirim audio.");

        const buffer = await q.download();
        const audioUrl = await uploadToGitHub(buffer, "audio.mp3");

        const { data } = await axios.get(
            `https://api.deline.web.id/tools/whatmusic?url=${encodeURIComponent(audioUrl)}`
        );

        if (!data.status)
            return m.reply("❌ Lagu tidak dikenali.");

        const result = data.result;

        const caption =
`🎵 *Lagu Ditemukan!*

📌 Judul: ${result.title}
🎤 Artis: ${result.artists}
👤 Creator API: ${data.creator}`;

        await KazzTzy.sendMessage(
            m.chat,
            { text: caption },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e?.response?.data || e.message || e));
    }
};

handler.help = ["whatmusic (reply audio)"];
handler.tags = ["tools"];
handler.command = /^(whatmusic|findsong|carilagu)$/i;
handler.register = true;
handler.limit = true;

export default handler;
