import fs from 'fs'
import path from 'path'
import { createCanvas, loadImage } from 'canvas'
import moment from 'moment-timezone'

const dir = './data'
const filePath = path.join(dir, 'totalchat.json')
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

const readData = () => {
    try {
        if (!fs.existsSync(filePath)) return {}
        const content = fs.readFileSync(filePath, 'utf8').trim()
        return content ? JSON.parse(content) : {}
    } catch { return {} }
}

const writeData = (data) => {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2))
}

const generateImage = async (groupData, groupMetadata, ppBuffer, KazzTzy, todayKey) => {
    const W = 720
    const participants = groupMetadata.participants || []
    const adminList = participants.filter(p => p.admin || p.superadmin)
    const adminRows = Math.ceil(adminList.length / 4) || 1
    const topSectionH = 220
    const chartSectionH = 260
    const adminSectionH = 50 + adminRows * 32 + 30
    const H = topSectionH + chartSectionH + adminSectionH

    const canvas = createCanvas(W, H)
    const ctx = canvas.getContext('2d')

    ctx.fillStyle = '#f0f2f5'
    ctx.fillRect(0, 0, W, H)

    ctx.fillStyle = '#1a1a2e'
    ctx.fillRect(0, 0, W, topSectionH)

    const ppSize = 130
    const ppX = 22
    const ppY = (topSectionH - ppSize) / 2
    if (ppBuffer) {
        try {
            const img = await loadImage(ppBuffer)
            const r = 10
            ctx.save()
            ctx.beginPath()
            ctx.moveTo(ppX + r, ppY)
            ctx.lineTo(ppX + ppSize - r, ppY)
            ctx.quadraticCurveTo(ppX + ppSize, ppY, ppX + ppSize, ppY + r)
            ctx.lineTo(ppX + ppSize, ppY + ppSize - r)
            ctx.quadraticCurveTo(ppX + ppSize, ppY + ppSize, ppX + ppSize - r, ppY + ppSize)
            ctx.lineTo(ppX + r, ppY + ppSize)
            ctx.quadraticCurveTo(ppX, ppY + ppSize, ppX, ppY + ppSize - r)
            ctx.lineTo(ppX, ppY + r)
            ctx.quadraticCurveTo(ppX, ppY, ppX + r, ppY)
            ctx.closePath()
            ctx.clip()
            ctx.drawImage(img, ppX, ppY, ppSize, ppSize)
            ctx.restore()
        } catch {}
    }

    const tx = ppX + ppSize + 24
    const ty = ppY + 8

    ctx.fillStyle = '#ffffff'
    ctx.font = 'bold 26px sans-serif'
    ctx.textAlign = 'left'
    ctx.fillText(`> ${groupMetadata.subject}`, tx, ty + 28)

    ctx.fillStyle = '#a0a8c0'
    ctx.font = '15px sans-serif'
    ctx.fillText(`${participants.length} MEMBERS`, tx, ty + 58)
    ctx.fillText(`${adminList.length} ADMINS`, tx, ty + 80)

    ctx.fillStyle = '#d0d8f0'
    ctx.font = 'bold 15px sans-serif'
    ctx.fillText(`${groupData.total || 0} TOTAL MESSAGES SENT`, tx, ty + 116)

    ctx.fillStyle = '#ffffff'
    ctx.fillRect(0, topSectionH, W, 3)

    const csY = topSectionH + 3
    ctx.fillStyle = '#1e1e32'
    ctx.fillRect(0, csY, W, chartSectionH)

    ctx.font = '13px sans-serif'
    ctx.fillStyle = '#c0c8e0'
    ctx.textAlign = 'center'
    ctx.fillText('chart', W / 2, csY + 20)

    ctx.save()
    ctx.translate(15, csY + chartSectionH / 2 + 10)
    ctx.rotate(-Math.PI / 2)
    ctx.font = '11px sans-serif'
    ctx.fillStyle = '#707890'
    ctx.textAlign = 'center'
    ctx.fillText('jumlah pesan', 0, 0)
    ctx.restore()

    const todayMoment = moment(todayKey)
    const currentMonth = todayMoment.format('YYYY-MM')
    const todayDate = todayMoment.date()

    const dayNumbers = Array.from({ length: todayDate }, (_, i) => i + 1)

    const daily = groupData.daily || {}
    const dayValues = dayNumbers.map(d => {
        const key = `${currentMonth}-${String(d).padStart(2, '0')}`
        return daily[key]?.total || 0
    })

    const COUNT = dayNumbers.length
    const maxVal = Math.max(...dayValues, 1)

    const chartX = 46
    const chartY = csY + 32
    const chartW = W - 58
    const chartH = 180
    const barW = Math.max(Math.floor(chartW / Math.max(COUNT, 14)) - 2, 4)

    for (let i = 0; i <= 4; i++) {
        const y = chartY + chartH - (i / 4) * chartH
        ctx.beginPath()
        ctx.strokeStyle = '#2c2c4c'
        ctx.lineWidth = 1
        ctx.moveTo(chartX, y)
        ctx.lineTo(chartX + chartW, y)
        ctx.stroke()
        ctx.font = '10px sans-serif'
        ctx.fillStyle = '#606880'
        ctx.textAlign = 'right'
        ctx.fillText(Math.round((maxVal * i) / 4), chartX - 3, y + 4)
    }

    for (let i = 0; i < COUNT; i++) {
        const val = dayValues[i]
        const barH = Math.max((val / maxVal) * chartH, val > 0 ? 2 : 0)
        const x = chartX + i * (barW + 2)
        const y = chartY + chartH - barH

        const grad = ctx.createLinearGradient(x, y, x, chartY + chartH)
        grad.addColorStop(0, '#a899f8')
        grad.addColorStop(1, '#5a4dc4')
        ctx.fillStyle = grad
        ctx.beginPath()
        if (ctx.roundRect) ctx.roundRect(x, y, barW, barH, [3, 3, 0, 0])
        else ctx.rect(x, y, barW, barH)
        ctx.fill()

        if (val > 0) {
            ctx.font = `bold ${val >= 1000 ? 7 : val >= 100 ? 8 : 9}px sans-serif`
            ctx.fillStyle = '#ffffff'
            ctx.textAlign = 'center'
            ctx.fillText(val, x + barW / 2, y - 3)
        }

        ctx.font = `${COUNT > 20 ? 8 : 9}px sans-serif`
        ctx.fillStyle = '#909898'
        ctx.textAlign = 'center'
        ctx.fillText(dayNumbers[i], x + barW / 2, chartY + chartH + 14)
    }

    ctx.font = '11px sans-serif'
    ctx.fillStyle = '#808898'
    ctx.textAlign = 'center'
    ctx.fillText('tanggal', W / 2, chartY + chartH + 28)

    const divY = csY + chartSectionH
    ctx.fillStyle = '#ffffff'
    ctx.fillRect(0, divY, W, 3)

    ctx.fillStyle = '#f0f2f5'
    ctx.fillRect(0, divY + 3, W, H - divY - 3)

    ctx.font = '13px sans-serif'
    ctx.fillStyle = '#666666'
    ctx.textAlign = 'center'
    ctx.fillText('group managed by', W / 2, divY + 32)

    const savedNames = groupData.names || {}
    const colCount = 4
    const colW = W / colCount

    for (const [i, admin] of adminList.entries()) {
        const col = i % colCount
        const row = Math.floor(i / colCount)
        const x = col * colW + colW / 2
        const y = divY + 58 + row * 32

        let rawName = savedNames[admin.id]
        if (!rawName || rawName === admin.id.split('@')[0]) {
            try { rawName = KazzTzy.getName(admin.id) } catch {}
        }
        if (!rawName || rawName === admin.id.split('@')[0]) {
            rawName = admin.id.split('@')[0]
        }

        const name = rawName.length > 16 ? rawName.slice(0, 15) + '...' : rawName
        ctx.font = '13px sans-serif'
        ctx.fillStyle = '#222222'
        ctx.textAlign = 'center'
        ctx.fillText(name, x, y)
    }

    ctx.font = '11px sans-serif'
    ctx.fillStyle = '#aaaaaa'
    ctx.textAlign = 'center'
    ctx.fillText('Create By KazzTzy', W / 2, H - 10)

    return canvas.toBuffer('image/png')
}

let handler = async (m, { KazzTzy }) => {
    const db = readData()
    const groupData = db[m.chat]
    if (!groupData || typeof groupData !== 'object') {
        return m.reply('Belum ada aktivitas chat yang terekam di grup ini.')
    }

    await KazzTzy.sendMessage(m.chat, { react: { text: global.reactload, key: m.key } })

    const groupMetadata = await KazzTzy.groupMetadata(m.chat)

    let ppBuffer = null
    try {
        const ppUrl = await KazzTzy.profilePictureUrl(m.chat, 'image')
        const res = await fetch(ppUrl)
        ppBuffer = Buffer.from(await res.arrayBuffer())
    } catch {}

    const todayKey = moment().tz('Asia/Jakarta').format('YYYY-MM-DD')
    const imgBuf = await generateImage(groupData, groupMetadata, ppBuffer, KazzTzy, todayKey)

    const todayData = groupData.daily?.[todayKey] || {}
    const peakEntry = Object.entries(todayData.hourly || {}).sort((a, b) => b[1] - a[1])[0]
    const tanggal = moment().tz('Asia/Jakarta').locale('id').format('D MMMM YYYY')

    await KazzTzy.sendMessage(m.chat, {
        image: imgBuf,
        caption: `*Group Report*\nTanggal: *${tanggal}*\nPeak di jam: *${peakEntry ? peakEntry[0] + ':00' : '-'}* (${peakEntry ? peakEntry[1] : 0} pesan)`,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idChannel,
                serverMessageId: null,
                newsletterName: global.namaChannel
            }
        }
    }, { quoted: m })

    await KazzTzy.sendMessage(m.chat, { react: { text: global.reactsukses, key: m.key } })
}

handler.before = async function (m) {
    if (!m.isGroup || !m.chat || m.fromMe || !m.sender) return

    const db = readData()
    if (!db[m.chat] || typeof db[m.chat] !== 'object') {
        db[m.chat] = { total: 0, users: {}, daily: {}, names: {} }
    }

    const gc = db[m.chat]
    if (!gc.users) gc.users = {}
    if (!gc.daily) gc.daily = {}
    if (!gc.names) gc.names = {}

    const now = moment().tz('Asia/Jakarta')
    const hour = String(now.hour())
    const dateKey = now.format('YYYY-MM-DD')

    if (m.pushName && m.pushName.trim()) {
        gc.names[m.sender] = m.pushName.trim()
    }

    gc.total = (gc.total || 0) + 1
    gc.users[m.sender] = (gc.users[m.sender] || 0) + 1

    if (!gc.daily[dateKey]) gc.daily[dateKey] = { total: 0, users: {}, hourly: {} }
    const day = gc.daily[dateKey]
    if (!day.users) day.users = {}
    if (!day.hourly) day.hourly = {}
    day.total = (day.total || 0) + 1
    day.users[m.sender] = (day.users[m.sender] || 0) + 1
    day.hourly[hour] = (day.hourly[hour] || 0) + 1

    const cutoff = moment().tz('Asia/Jakarta').subtract(60, 'days').format('YYYY-MM-DD')
    Object.keys(gc.daily).forEach(k => { if (k < cutoff) delete gc.daily[k] })

    writeData(db)
}

handler.help = ['totalchat']
handler.tags = ['group']
handler.command = /^(totalchat|gcstats|groupreport)$/i
handler.group = true

export default handler