import fetch from "node-fetch"

const handler = async (m, { KazzTzy, reply }) => {
  try {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ""
    if (!mime || !/image/.test(mime)) return reply("reply gambar")

    await m.react("⏳")

    const buffer = await q.download()
    const mimeType = /png/.test(mime) ? "image/png" : "image/jpeg"
    const imageBase64 = buffer.toString("base64")

    const res = await fetch("https://api.ocr.space/parse/image", {
      method: "POST",
      headers: { apikey: "helloworld" },
      body: new URLSearchParams({
        base64Image: `data:${mimeType};base64,${imageBase64}`,
        language: "eng"
      })
    })

    if (!res.ok) throw new Error("ocr gagal")
    const json = await res.json()

    const text =
      json?.ParsedResults?.[0]?.ParsedText?.trim() ||
      "teks tidak ditemukan"

    await m.react("✅")

    await KazzTzy.sendMessage(m.chat, { text }, { quoted: m })
  } catch (e) {
    console.error(e)
    await m.react("❌")
    reply("gagal ocr")
  }
}

handler.help = ["ocr"]
handler.tags = ["tools"]
handler.command = ["readtext", "ocr"]
handler.register = true
handler.limit = true

export default handler