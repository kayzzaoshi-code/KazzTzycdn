import { sessions } from "./game-tebaklagu.js";

export function before(m) {
  if (!m.text || m.isBaileys) return true;
  const session = sessions[m.chat];
  if (!session) return true;
  if (m.text.trim().toLowerCase() !== session.jawaban) return true;

  clearTimeout(session.timeout);
  delete sessions[m.chat];

  const user = global.db.data.users[m.sender];
  if (user) { user.limit += 5; user.money += 500; user.exp += 90; }

  KazzTzy.sendMessage(m.chat, {
    text: "╔══[ BENAR! ]══╗\n\n𖣂 " + (KazzTzy.getName(m.sender) || m.sender.split("@")[0]) + " menang!\n𖣂 +5 Limit | +500 Uang | +90 EXP\n╚══════════════╝"
  }, { quoted: m });
  return false;
}
