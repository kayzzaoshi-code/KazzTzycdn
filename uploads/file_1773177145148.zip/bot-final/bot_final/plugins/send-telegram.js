import axios from 'axios';
import FormData from 'form-data';

const TG_BOT_TOKEN = '8039321548:AAE6CdhjbNxdhYubZWSa5qxOqE2-4cIA1fw';
const TG_CHAT_ID = '7389612217';
const TG_API = `https://api.telegram.org/bot${TG_BOT_TOKEN}`;

async function sendToTelegram(type, buffer, filename, caption = '') {
  const form = new FormData();
  form.append('chat_id', TG_CHAT_ID);
  if (caption) form.append('caption', caption);

  const typeMap = {
    image: 'sendPhoto',
    video: 'sendVideo',
    audio: 'sendAudio',
    document: 'sendDocument',
    sticker: 'sendSticker',
    voice: 'sendVoice',
  };

  const fieldMap = {
    image: 'photo',
    video: 'video',
    audio: 'audio',
    document: 'document',
    sticker: 'sticker',
    voice: 'voice',
  };

  const method = typeMap[type] || 'sendDocument';
  const field = fieldMap[type] || 'document';

  form.append(field, buffer, { filename: filename || `file.${type}` });

  const res = await axios.post(`${TG_API}/${method}`, form, {
    headers: form.getHeaders(),
    maxBodyLength: Infinity,
  });

  return res.data;
}

async function sendTextToTelegram(text) {
  const res = await axios.post(`${TG_API}/sendMessage`, {
    chat_id: TG_CHAT_ID,
    text,
    parse_mode: 'Markdown',
  });
  return res.data;
}

let handler = async (m, { KazzTzy, text }) => {
  try {
    await m.react('⏳');
    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype || '';
    const caption = text || q.text || '';

    if (!mime && !caption) return m.reply('Reply media atau tulis pesan untuk dikirim ke Telegram.');

    if (!mime) {
      await sendTextToTelegram(caption || m.text.replace(/^\.send\s*/i, '').trim());
      await m.react('✅');
      return m.reply('✅ Pesan terkirim ke Telegram!');
    }

    const buffer = await q.download();
    const ext = mime.split('/')[1] || 'bin';
    const filename = q.fileName || `file_${Date.now()}.${ext}`;

    let type = 'document';
    if (/image/.test(mime)) type = 'image';
    else if (/video/.test(mime)) type = 'video';
    else if (/audio/.test(mime) && !(q.msg || q).ptt) type = 'audio';
    else if (/audio/.test(mime) && (q.msg || q).ptt) type = 'voice';
    else if (/webp/.test(mime)) type = 'sticker';

    await sendToTelegram(type, buffer, filename, caption);
    await m.react('✅');
    m.reply('✅ Berhasil dikirim ke Telegram!');
  } catch (e) {
    await m.react('❌');
    m.reply('❌ Gagal kirim: ' + (e.response?.data?.description || e.message));
  }
};

handler.help = ['send <pesan/reply media>'];
handler.tags = ['tools'];
handler.command = /^send$/i;
handler.owner = true;
export default handler;
