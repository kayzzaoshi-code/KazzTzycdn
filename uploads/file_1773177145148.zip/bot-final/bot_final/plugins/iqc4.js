import dhIQC from "dh-iqc";

let handler = async (m, { KazzTzy, usedPrefix, command }) => {
    try {
        await m.react(global.react || '⏳');

        const text = m.quoted?.text || m.text?.replace(usedPrefix + command, '').trim();
        if (!text) return m.reply(`Contoh penggunaan:\n${usedPrefix + command} teks`);

        const result = dhIQC(text);

        await KazzTzy.sendMessage(
            m.chat,
            { text: `Hasil IQC:\n\n${result}` },
            { quoted: m }
        );

        await m.react(global.reactSuccess || '✅');

    } catch (e) {
        await m.react(global.reactError || '❌');
        m.reply(String(e?.response?.data || e.message || e));
    }
};

handler.help = ["iqc"];
handler.tags = ["maker"];
handler.command = /^iqc4$/i;
handler.register = true;
handler.limit = true;

export default handler;