import axios from "axios";
import unzipper from "unzipper";

const TOKEN = "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";
const OWNER = "KazzTzyPrivat7777";
const DEFAULT_REPO = "KazzTzySourceApiz";

async function createRepo(repo) {
  try {
    await axios.post(
      "https://api.github.com/user/repos",
      { name: repo, private: false }, // <=== ini jadi public
      { headers: { Authorization: `token ${TOKEN}` } }
    );
  } catch (err) {
    if (err.response?.status === 422) {

      return;
    }
    throw err;
  }
}

async function getFileSha(repo, path) {
  try {
    const res = await axios.get(
      `https://api.github.com/repos/${OWNER}/${repo}/contents/${path}`,
      { headers: { Authorization: `token ${TOKEN}` } }
    );
    return res.data.sha;
  } catch {
    return null;
  }
}

async function uploadFileToGitHub(repo, filename, buffer) {
  let sha = await getFileSha(repo, filename);
  const url = `https://api.github.com/repos/${OWNER}/${repo}/contents/${filename}`;
  const data = {
    message: `Update file ${filename}`,
    content: buffer.toString("base64"),
    ...(sha ? { sha } : {})
  };

  try {
    await axios.put(url, data, {
      headers: { Authorization: `token ${TOKEN}` }
    });
  } catch (err) {

    if (err.response?.data?.message?.includes("but expected")) {
      sha = await getFileSha(repo, filename);
      data.sha = sha;
      await axios.put(url, data, {
        headers: { Authorization: `token ${TOKEN}` }
      });
    } else throw err;
  }
}

let handler = async (m, { KazzTzy, text }) => {
  try {
    const repoName = text?.trim() || DEFAULT_REPO;

    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype;
    if (!mime || !mime.includes("zip"))
      return m.reply("❌ Reply file ZIP untuk diupload.");

    const buffer = await q.download();
    await createRepo(repoName);

    const zip = await unzipper.Open.buffer(buffer);

    for (const entry of zip.files) {
      if (entry.type === "File") {
        const fileBuffer = await entry.buffer();
        await uploadFileToGitHub(repoName, entry.path, fileBuffer);
      }
    }

    await KazzTzy.sendMessage(
      m.chat,
      { text: `✅ Semua file dalam ZIP berhasil diupload/update ke repo: ${repoName}` },
      { quoted: m }
    );
  } catch (e) {
    m.reply(
      "❌ Terjadi kesalahan: " + (e.response?.data?.message || e.message)
    );
  }
};

handler.help = ["uploadzip2 <namaRepo>"];
handler.tags = ["tools"];
handler.command = /^(uploadzip2)$/i;
handler.limit = true;
handler.owner = true;

export default handler;