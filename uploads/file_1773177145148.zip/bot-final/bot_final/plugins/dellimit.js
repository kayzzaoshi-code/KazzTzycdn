let handler = async (m, { text }) => {
    let delValue = parseInt(text) || 0;

    Object.keys(global.db.data.users).forEach(jid => {
        let user = global.db.data.users[jid];
        if (!user.limit) user.limit = 0;
        user.limit -= delValue;
        if (user.limit < 0) user.limit = 0;
    });

    m.reply(`✅ Berhasil mengurangi ${delValue} limit dari semua user`);
};

handler.help = ['dellimit <jumlah>'];
handler.tags = ['owner'];
handler.command = /^(dellimit)$/i;
handler.rowner = true;

export default handler;