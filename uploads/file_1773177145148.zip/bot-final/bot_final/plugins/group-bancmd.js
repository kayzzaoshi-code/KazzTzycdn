let handler = async (m, { KazzTzy, text, args, isOwner, isAdmin }) => {
  if (!m.isGroup) return m.reply("𖣂 Hanya di grup.");
  if (!isOwner && !isAdmin) return m.reply("𖣂 Hanya owner/admin.");

  const chats = global.db.data.chats;
  if (!chats[m.chat]) chats[m.chat] = {};
  const chat = chats[m.chat];
  if (!chat.bannedCmds) chat.bannedCmds = [];

  const sub = (args[0] || "").toLowerCase();

  if (sub === "list") {
    if (!chat.bannedCmds.length) return m.reply("𖣂 Tidak ada command yang di-ban di grup ini.");
    return m.reply(
      "╔══[ BANNED CMD ]══╗\n\n" +
      chat.bannedCmds.map((c, i) => "𖣂 " + (i + 1) + ". " + c).join("\n") +
      "\n\n╚══════════════════╝"
    );
  }

  if (sub === "del" || sub === "hapus") {
    const cmd = (args[1] || "").toLowerCase();
    if (!cmd) return m.reply("𖣂 Sebutkan command yang mau dihapus.");
    chat.bannedCmds = chat.bannedCmds.filter(c => c !== cmd);
    return m.reply("𖣂 Command *" + cmd + "* sudah dihapus dari ban list.");
  }

  if (!text) {
    return m.reply(
      "╔══[ BANCMD ]══╗\n" +
      "𖣂 .bancmd <command>\n" +
      "𖣂 .bancmd list\n" +
      "𖣂 .bancmd del <command>\n" +
      "╚══════════════╝"
    );
  }

  const cmd = sub;
  if (chat.bannedCmds.includes(cmd)) return m.reply("𖣂 Command *" + cmd + "* sudah di-ban.");
  chat.bannedCmds.push(cmd);
  return m.reply("𖣂 Command *" + cmd + "* berhasil di-ban di grup ini.");
};

handler.before = async function (m) {
  if (!m.isGroup) return true;
  const chat = global.db.data.chats?.[m.chat];
  if (!chat?.bannedCmds?.length) return true;
  const isOwner = global.owner.map(([n]) => n + "@s.whatsapp.net").includes(m.sender) || m.fromMe;
  if (isOwner) return true;
  if (!m.text) return true;
  const prefix = global.prefix;
  if (!prefix.test(m.text)) return true;
  const cmd = m.text.slice(1).trim().split(" ")[0].toLowerCase();
  if (chat.bannedCmds.includes(cmd)) {
    KazzTzy.sendMessage(m.chat, { text: "𖣂 Command *" + cmd + "* di-ban di grup ini." }, { quoted: m });
    return false;
  }
  return true;
};

handler.help = ["bancmd <command>"];
handler.tags = ["group"];
handler.command = /^bancmd$/i;

export default handler;
