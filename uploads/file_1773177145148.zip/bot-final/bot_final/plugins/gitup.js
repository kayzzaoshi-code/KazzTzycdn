import axios from "axios"

const TOKEN = "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"
const OWNER = "kayzzaoshi-code"
const REPO = "Uploader"

async function createRepo() {
  try {
    await axios.post(
      "https://api.github.com/user/repos",
      { name: REPO, private: false },
      { headers: { Authorization: `token ${TOKEN}` } }
    )
  } catch {}
}

async function uploadFile(filename, content) {
  await createRepo()
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/contents/${filename}`
  const data = {
    message: `Upload ${filename}`,
    content: Buffer.from(content).toString("base64")
  }
  const res = await axios.put(url, data, {
    headers: { Authorization: `token ${TOKEN}` }
  })
  return res.data.content.download_url
}

let handler = async (m, { KazzTzy }) => {
  try {
    const q = m.quoted || m
    const mime = (q.msg || q).mimetype
    if (!mime) return m.reply("Reply media untuk diupload.")

    const buffer = await q.download()
    const ext = mime.split("/")[1] || "bin"
    const filename = `file_${Date.now()}.${ext}`
    const url = await uploadFile(filename, buffer)

    await KazzTzy.sendMessage(m.chat, { text: `🔗 Link GitHub:\n${url}` }, { quoted: m })
  } catch (e) {
    m.reply("❌ Terjadi kesalahan: " + (e.response?.data?.message || e.message))
  }
}

handler.help = ["ghupload"]
handler.tags = ["tools"]
handler.command = /^(ghupload)$/i
handler.limit = true

export default handler