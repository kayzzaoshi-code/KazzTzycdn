import axios from "axios";

const TOKEN = "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";
const USERNAME = "KazzTzyPrivat7777";

async function uploadGist(filename, content) {
  const res = await axios.post(
    "https://api.github.com/gists",
    {
      description: `Upload via bot`,
      public: true,
      files: {
        [filename]: {
          content
        }
      }
    },
    {
      headers: {
        Authorization: `token ${TOKEN}`,
        Accept: "application/vnd.github+json"
      }
    }
  );

  return res.data.html_url;
}

let handler = async (m, { KazzTzy, text }) => {
  try {
    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype || "";

    if (!text) return m.reply("❌ Format: .uploadgist <namaFile>");
    if (mime) return m.reply("❌ Reply pesan berupa code/text saja.");

    const filename = text.trim();
    const content = q.text || q.caption;

    if (!content) return m.reply("❌ Reply code yang mau diupload ke gist.");

    const url = await uploadGist(filename, content);

    await KazzTzy.sendMessage(
      m.chat,
      { text: `✅ Berhasil upload ke Gist:\n${url}` },
      { quoted: m }
    );

  } catch (e) {
    m.reply("❌ Error: " + (e.response?.data?.message || e.message));
  }
};

handler.help = ["uploadgist <namaFile>"];
handler.tags = ["tools"];
handler.command = /^(uploadgist)$/i;
handler.owner = true;

export default handler;