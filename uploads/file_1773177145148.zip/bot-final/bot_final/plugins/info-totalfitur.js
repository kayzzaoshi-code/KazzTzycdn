let handler = async (m) => {
    let total = Object.values(global.plugins).filter(v => v.help && v.tags).length;
    m.reply(`Total Fitur Bot Saat ini: ${total}`);
};

handler.help = ['totalfitur'];
handler.tags = ['info'];
handler.command = ['totalfitur'];
export default handler;