import fetch from 'node-fetch';
import AdmZip from 'adm-zip';

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `uhm.. nama websitenya mana?\n\npenggunaan:\n${usedPrefix + command} <namawebsite>\n\ncontoh:\n${usedPrefix + command} kazzanime6`;
  if (!m.quoted || !/(zip|html)/.test(m.quoted.mimetype || '')) {
    throw `⚠️ Reply file \`.html\` atau \`.zip\` untuk di-deploy.`;
  }

  const name = text.trim().toLowerCase().replace(/[^a-z0-9-_]/g, '');
  const vercelToken = 'vcp_6a1tkTBOlyp5ooT1N8Zywqx09DYGuSGsxQLz0dtut6SptSazR31IDehl';

  const fileBuffer = await m.quoted.download();
  if (!fileBuffer) throw `❌ Gagal mendownload file.`;

  const headers = {
    Authorization: `Bearer ${vercelToken}`,
    'Content-Type': 'application/json'
  };

  let files = [];

  if (/zip/.test(m.quoted.mimetype)) {
    const zip = new AdmZip(fileBuffer);
    const entries = zip.getEntries();
    entries.forEach(entry => {
      if (!entry.isDirectory) {
        let filePath = entry.entryName.replace(/\\/g, '/');
        if (filePath.includes('/')) {
          filePath = filePath.substring(filePath.indexOf('/') + 1);
        }
        if (filePath) {
          files.push({
            file: filePath,
            data: entry.getData().toString('base64'),
            encoding: 'base64'
          });
        }
      }
    });
  } else {
    files.push({
      file: 'index.html',
      data: fileBuffer.toString('base64'),
      encoding: 'base64'
    });
  }

  await fetch('https://api.vercel.com/v9/projects', {
    method: 'POST',
    headers,
    body: JSON.stringify({ name })
  });

  const deploy = await fetch('https://api.vercel.com/v13/deployments', {
    method: 'POST',
    headers,
    body: JSON.stringify({
      name,
      project: name,
      target: 'production',
      files,
      projectSettings: { framework: null }
    })
  });

  const res = await deploy.json();

  if (res?.url) {
    const deployUrl = `https://${res.url}`;
    const aliasUrl = `https://${name}.vercel.app`;
    m.reply(
      `✅ Web berhasil dibuat!\n` +
      `🌐 Project: ${name}\n` +
      `🔗 Deploy: ${deployUrl}\n` +
      `🏷️ Link: ${aliasUrl}`
    );
  } else {
    throw `❌ Gagal deploy: ${JSON.stringify(res)}`;
  }
};

handler.help = ['cweb <namawebsite>'];
handler.tags = ['owner'];
handler.command = /^cweb$/i;
handler.owner = true;

export default handler;