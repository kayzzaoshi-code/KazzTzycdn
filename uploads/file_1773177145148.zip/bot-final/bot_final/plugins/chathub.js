import axios from "axios";

async function sendAIReply(KazzTzy, m, text) {
  return KazzTzy.sendMessage(m.chat, {
    text: String(text),
    mentions: [m.sender],
    contextInfo: {
      externalAdReply: {
        title: "Z4Z Bot",
        body: "KazzTzy",
        thumbnailUrl: "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1772016271450.jpeg",
        sourceUrl: global.source || "https://wa.me/6285795269956",
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m });
}

async function chatHubAI(text) {
    if (!text) throw new Error("Parameter q diperlukan");

    const { data } = await axios({
        method: "post",
        url: "https://freeaichathub.com/chat",
        headers: {
            authority: "freeaichathub.com",
            accept: "*/*",
            "content-type": "application/json",
            origin: "https://freeaichathub.com",
            referer: "https://freeaichathub.com/",
            "user-agent":
                "Mozilla/5.0 (Android 10; Mobile; rv:147.0) Gecko/147.0 Firefox/147.0"
        },
        data: {
            message: text,
            model: "gpt-3.5-turbo",
            language: "en"
        }
    });

    let result = data;

    if (typeof result === "string") {
        try {
            result = JSON.parse(result);
        } catch {}
    }

    if (result?.choices?.[0]?.message?.content) {
        return result.choices[0].message.content.trim();
    }

    return (
        result?.message ||
        result?.reply ||
        result?.content ||
        "Gagal mendapatkan respon."
    );
}

let handler = async (m, { text }) => {
    const input = m.quoted ? m.quoted.text : text;
    if (!input) return sendAIReply(KazzTzy, m, "Masukkan pertanyaan.");

    try {
        await m.react("⏳");

        const res = await chatHubAI(input);

        await sendAIReply(KazzTzy, m, res);
        await m.react("✅");

    } catch (err) {
        await m.react("❌");
        m.reply("Error:\n" + (err.response?.data?.message || err.message));
    }
};

handler.help = ["chathub <text>"];
handler.tags = ["ai"];
handler.command = /^chathub$/i;
handler.limit = true;

export default handler;