let handler = async (m, { command, text }) => {
    if (!m.quoted) return m.reply('❌ Reply pesan user yang mau ditambah.');

    let amount = parseInt(text);
    if (!amount || amount <= 0) return m.reply('❌ Jumlah tidak valid.');

    let who = m.quoted.sender;
    let user = global.db.data.users[who];
    if (!user) return m.reply('❌ User tidak ditemukan.');

    if (command === 'addsaldo') {
        user.money = (user.money || 0) + amount;
        return m.reply(`✅ Berhasil tambah saldo ${amount} ke @${who.split('@')[0]}`);
    }

    if (command === 'addlimit') {
        user.limit = (user.limit || 0) + amount;
        return m.reply(`✅ Berhasil tambah limit ${amount} ke @${who.split('@')[0]}`);
    }
};

handler.help = ['addsaldo', 'addlimit'];
handler.tags = ['owner'];
handler.command = /^(addsaldo|addlimit)$/i;

export default handler;