import { Sticker, StickerTypes } from "wa-sticker-formatter";

let handler = async (m, { KazzTzy, text, command }) => {
    try {
        await m.react(global.react || "⏳");

        if (!m.quoted) {
            await m.react(global.reactError || "❌");
            return m.reply(`Reply gambar/video/stiker dengan caption .${command} packname|author`);
        }

        let split = text ? text.split("|") : [];
        let packname = split[0] ? split[0].trim() : (global.packname || "Sticker WM");
        let author = split[1] ? split[1].trim() : (global.author || m.pushName);

        let media = await m.quoted.download();

        const sticker = new Sticker(media, {
            pack: packname,
            author: author,
            type: StickerTypes.FULL,
            quality: 70,
            background: "#FFFFFF00"
        });

        const stickerBuffer = await sticker.toBuffer();

        await KazzTzy.sendMessage(
            m.chat,
            { sticker: stickerBuffer },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply("Gagal membuat sticker");
    }
};

handler.help = ["swm <packname>|<author>"];
handler.tags = ["sticker"];
handler.command = /^(swm|steal|stickerwm|take|wm)$/i;
handler.register = true;
handler.limit = true;

export default handler;