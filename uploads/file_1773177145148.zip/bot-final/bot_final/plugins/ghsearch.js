let handler = async (m, { KazzTzy, text }) => {
    try {
        await m.react(global.react || "⏳");

        if (!text) {
            return m.reply("❌ Masukkan query.\nContoh: .ghsearch sc bot store");
        }

        const url = `https://api.github.com/search/repositories?q=${encodeURIComponent(text)}&per_page=30`;

        const res = await fetch(url, {
            headers: {
                "Accept": "application/vnd.github+json",
                "User-Agent": "node"
            }
        });

        if (!res.ok) {
            throw new Error(`GitHub Error: ${res.status}`);
        }

        const data = await res.json();

        const shuffled = data.items
            .sort(() => Math.random() - 0.5)
            .slice(0, 5);

        if (!shuffled.length) {
            return m.reply("❌ Repository tidak ditemukan.");
        }

        let caption = `🔎 *GitHub Search*\n\n`;
        caption += `Total Found: ${data.total_count}\n`;
        caption += `Showing: ${shuffled.length}\n\n`;

        for (let repo of shuffled) {
            caption += `📦 *${repo.full_name}*\n`;
            caption += `⭐ ${repo.stargazers_count} | 🍴 ${repo.forks_count}\n`;
            caption += `💻 ${repo.language || "-"}\n`;
            caption += `🔗 ${repo.html_url}\n`;
            caption += `📥 ${repo.html_url}/archive/refs/heads/${repo.default_branch}.zip\n\n`;
        }

        await KazzTzy.sendMessage(
            m.chat,
            { text: caption },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e?.message || e));
    }
};

handler.help = ["ghsearch <query>"];
handler.tags = ["tools"];
handler.command = /^ghsearch$/i;
handler.register = true;
handler.limit = true;

export default handler;