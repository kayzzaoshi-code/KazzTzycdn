import { generateWAMessageFromContent } from 'baileys';

let handler = async (m, { KazzTzy, usedPrefix, command }) => {
	let q = m.quoted ? m.quoted : m;
	let mime = (q.msg || q).mimetype || q.mediaType || '';
	
	if (!mime) return m.reply(`Kirim/Reply gambar dengan caption *${usedPrefix + command}*`);
	if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Mime ${mime} tidak support`);
	
	try {
		let img = await q.download?.();
		if (!img) return m.reply('Gagal mengunduh gambar!');
		
		await KazzTzy.updateProfilePicture(KazzTzy.user.jid, img);
		m.reply('Sukses mengganti profil bot!');
	} catch (e) {
		console.error(e);
		m.reply('Terjadi kesalahan!');
	}
};

handler.help = ['setppbot'];
handler.tags = ['owner'];
handler.command = /^(setppbot)$/i;
handler.owner = true;

export default handler;
