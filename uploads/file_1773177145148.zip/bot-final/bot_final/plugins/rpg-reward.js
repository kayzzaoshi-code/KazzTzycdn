const rewardConfig = {
    hourly: {
        cooldown: 3600000, // 1 jam
        lastKey: 'lasthourly',
        free: { exp: 100, money: 500, limit: 1 },
        prem: { exp: 200, money: 1000, limit: 2 },
    },

    dailys: {
        cooldown: 86400000, // 1 hari
        lastKey: 'lastdailys',
        free: { exp: 500, money: 1000, limit: 5 },
        prem: { exp: 1000, money: 5000, limit: 10 },
    },

    weeklys: {
        cooldown: 604800000, // 7 hari
        lastKey: 'lastweeklys',
        free: { exp: 2999, money: 7000, limit: 15 },
        prem: { exp: 4999, money: 14000, limit: 30 },
    },

    monthlys: {
        cooldown: 2592000000, // 30 hari
        lastKey: 'lastmonthlys',
        free: { exp: 4999, money: 50000, limit: 30 },
        prem: { exp: 5999, money: 100000, limit: 50 },
    },

    yearlys: {
        cooldown: 31536000000, // 365 hari
        lastKey: 'lastyearlys',
        free: { exp: 20000, money: 500000, limit: 200 },
        prem: { exp: 50000, money: 1000000, limit: 500 },
    },
};

let handler = async (m, { command, isPrems }) => {
    const type = /hourly|hourlys/i.test(command) ? 'hourly'
        : /dailys/i.test(command) ? 'dailys'
        : /weekly|weeklys/i.test(command) ? 'weeklys'
        : /monthly|monthlys/i.test(command) ? 'monthlys'
        : /yearly|yearlys/i.test(command) ? 'yearlys'
        : null;

    if (!type) return;

    const user = global.db.data.users[m.sender];
    const cfg = rewardConfig[type];

    const now = Date.now();
    const remaining = user[cfg.lastKey] + cfg.cooldown - now;

    if (remaining > 0) {
        return m.reply(`⏳ Kamu sudah klaim *${type}*.\nTunggu *${formatTime(remaining)}* lagi.`);
    }

    const reward = isPrems ? cfg.prem : cfg.free;

    user.exp += reward.exp;
    user.money += reward.money;
    user.limit += reward.limit;

    user[cfg.lastKey] = now;

    m.reply(`🎁 *Hadiah ${type}*\n\n+ ${reward.exp} Exp\n+ ${reward.money} Money\n+ ${reward.limit} Limit`);
};

handler.help = ['hourly', 'dailys', 'weeklys', 'monthlys', 'yearlys'];
handler.tags = ['rpg'];
handler.command = /^(hourly|hourlys|dailys|weeklys|monthlys|yearlys)$/i;

export default handler;

function formatTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);

    return `${h} Jam ${m} Menit ${s} Detik`;
}