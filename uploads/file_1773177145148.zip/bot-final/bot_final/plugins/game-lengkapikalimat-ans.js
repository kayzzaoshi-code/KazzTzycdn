import { sessions } from "./game-lengkapikalimat.js";

export function before(m) {
  if (!m.text || m.isBaileys) return true;
  const session = sessions[m.chat];
  if (!session) return true;
  if (m.text.trim().toLowerCase() !== session.jawaban) return true;

  clearTimeout(session.timeout);
  delete sessions[m.chat];

  const user = global.db.data.users[m.sender];
  if (user) { user.limit += 3; user.money += 250; user.exp += 60; }

  KazzTzy.sendMessage(m.chat, {
    text: "╔══[ BENAR! ]══╗\n\n𖣂 " + (KazzTzy.getName(m.sender) || m.sender.split("@")[0]) + " menang!\n𖣂 +3 Limit | +250 Uang | +60 EXP\n╚══════════════╝"
  }, { quoted: m });
  return false;
}
