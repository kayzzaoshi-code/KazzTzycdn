import { createCanvas, loadImage } from 'canvas'
import os from 'os'
import axios from 'axios'
import { execSync } from 'child_process'

const BOT_IMG = 'https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1771796760888.jpeg'
const F = 'Poppins'

const fmtBytes = (b) => {
    if (b >= 1e9) return (b / 1e9).toFixed(2) + ' GB'
    if (b >= 1e6) return (b / 1e6).toFixed(2) + ' MB'
    return (b / 1e3).toFixed(2) + ' KB'
}

const fmtUp = (s) => {
    const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60)
    if (d) return `${d}d ${h}h ${m}m`
    if (h) return `${h}h ${m}m`
    return `${m}m`
}

const rr = (ctx, x, y, w, h, r) => {
    ctx.beginPath()
    ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y)
    ctx.quadraticCurveTo(x + w, y, x + w, y + r)
    ctx.lineTo(x + w, y + h - r)
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h)
    ctx.lineTo(x + r, y + h)
    ctx.quadraticCurveTo(x, y + h, x, y + h - r)
    ctx.lineTo(x, y + r)
    ctx.quadraticCurveTo(x, y, x + r, y)
    ctx.closePath()
}

const cardBg = (ctx, x, y, w, h, r = 16) => {
    rr(ctx, x, y, w, h, r)
    const g = ctx.createLinearGradient(x, y, x + w, y + h)
    g.addColorStop(0, '#0e1830')
    g.addColorStop(1, '#0a1020')
    ctx.fillStyle = g
    ctx.fill()
    ctx.strokeStyle = '#1e3060'
    ctx.lineWidth = 1.2
    ctx.stroke()
}

const txt = (ctx, text, x, y, size, color, weight = '400', align = 'left', base = 'middle') => {
    ctx.font = `${weight} ${size}px ${F}`
    ctx.fillStyle = color
    ctx.textAlign = align
    ctx.textBaseline = base
    ctx.fillText(text, x, y)
    ctx.textAlign = 'left'
    ctx.textBaseline = 'alphabetic'
}

const drawGauge = (ctx, cx, cy, R, pct, clr, track, lw = 16) => {
    const s = Math.PI * 0.78, e = Math.PI * 2.22
    ctx.lineCap = 'round'
    ctx.beginPath(); ctx.arc(cx, cy, R, s, e)
    ctx.strokeStyle = track; ctx.lineWidth = lw; ctx.stroke()
    if (pct > 0) {
        ctx.beginPath(); ctx.arc(cx, cy, R, s, s + (e - s) * Math.min(pct / 100, 1))
        ctx.strokeStyle = clr; ctx.lineWidth = lw; ctx.stroke()
        ctx.shadowColor = clr
        ctx.shadowBlur = 18
        ctx.beginPath(); ctx.arc(cx, cy, R, s, s + (e - s) * Math.min(pct / 100, 1))
        ctx.strokeStyle = clr; ctx.lineWidth = lw; ctx.stroke()
        ctx.shadowBlur = 0
    }
}

const drawBar = (ctx, x, y, w, h, pct, clr) => {
    rr(ctx, x, y, w, h, h / 2); ctx.fillStyle = '#131e38'; ctx.fill()
    if (pct > 0) {
        const fw = Math.max(h, w * Math.min(pct / 100, 1))
        rr(ctx, x, y, fw, h, h / 2)
        const g = ctx.createLinearGradient(x, y, x + fw, y)
        g.addColorStop(0, clr + 'cc')
        g.addColorStop(1, clr)
        ctx.fillStyle = g
        ctx.shadowColor = clr
        ctx.shadowBlur = 10
        ctx.fill()
        ctx.shadowBlur = 0
    }
}

const iconBadge = (ctx, x, y, clr, iconText, size = 40) => {
    const g = ctx.createLinearGradient(x, y, x + size, y + size)
    g.addColorStop(0, clr + '33')
    g.addColorStop(1, clr + '11')
    rr(ctx, x, y, size, size, 10)
    ctx.fillStyle = g; ctx.fill()
    ctx.strokeStyle = clr + '66'; ctx.lineWidth = 1; ctx.stroke()
    txt(ctx, iconText, x + size / 2, y + size / 2, size * 0.5, clr, 'bold', 'center', 'middle')
}

const draw3Cards = async (ctx, imgSrc, px, py, pw, ph) => {
    try {
        const res = await axios.get(imgSrc, { responseType: 'arraybuffer' })
        const img = await loadImage(Buffer.from(res.data))

        const cardW = pw * 0.62
        const cardH = ph * 0.94

        const configs = [
            { dx: px,              dy: py + ph * 0.10, w: cardW * 0.78, h: cardH * 0.78, rot: -0.22, alpha: 0.30 },
            { dx: px + pw * 0.20,  dy: py + ph * 0.05, w: cardW * 0.88, h: cardH * 0.88, rot: -0.12, alpha: 0.60 },
            { dx: px + pw * 0.38,  dy: py,              w: cardW,        h: cardH,        rot: -0.02, alpha: 1.00 },
        ]

        for (const c of configs) {
            ctx.save()
            ctx.globalAlpha = c.alpha
            ctx.translate(c.dx + c.w / 2, c.dy + c.h / 2)
            ctx.rotate(c.rot)
            rr(ctx, -c.w / 2, -c.h / 2, c.w, c.h, 16)
            ctx.clip()
            ctx.drawImage(img, -c.w / 2, -c.h / 2, c.w, c.h)
            ctx.restore()

            ctx.save()
            ctx.globalAlpha = c.alpha * 0.55
            ctx.translate(c.dx + c.w / 2, c.dy + c.h / 2)
            ctx.rotate(c.rot)
            rr(ctx, -c.w / 2, -c.h / 2, c.w, c.h, 16)
            ctx.strokeStyle = '#3a5fa0'
            ctx.lineWidth = 1.8
            ctx.stroke()
            ctx.restore()
        }
    } catch (e) {
        console.error('3card err', e.message)
    }
}

let handler = async (m, { KazzTzy }) => {
    try {
        await KazzTzy.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

        const t0 = Date.now()
        await KazzTzy.sendMessage(m.chat, { react: { text: '📡', key: m.key } })
        const lat = Date.now() - t0
        const latClr = lat < 100 ? '#00ff88' : lat < 300 ? '#ffcc00' : '#ff4455'

        const totalMem = os.totalmem(), freeMem = os.freemem()
        const usedMem = totalMem - freeMem
        const memPct = Math.round((usedMem / totalMem) * 100)

        const cpus = os.cpus()
        const cpuModel = cpus[0]?.model?.trim() || 'Unknown CPU'
        const cpuCores = cpus.length, cpuSpeed = cpus[0]?.speed || 0
        const cpuPct = Math.min(100, Math.round(
            cpus.reduce((a, c) => {
                const tot = Object.values(c.times).reduce((x, v) => x + v, 0)
                return a + (1 - c.times.idle / tot) * 100
            }, 0) / cpus.length
        ))

        let diskUsed = 0, diskTotal = 1, diskFree = 0, diskPct = 0
        try {
            const df = execSync('df -k / | tail -1').toString().trim().split(/\s+/)
            diskTotal = parseInt(df[1]) * 1024; diskUsed = parseInt(df[2]) * 1024; diskFree = parseInt(df[3]) * 1024
            diskPct = Math.round((diskUsed / diskTotal) * 100)
        } catch {}

        let rx = 0, tx = 0, iface = 'eth0'
        try {
            const nets = os.networkInterfaces()
            iface = Object.keys(nets).find(k => k !== 'lo') || 'eth0'
            rx = parseInt(execSync(`cat /sys/class/net/${iface}/statistics/rx_bytes 2>/dev/null || echo 0`).toString()) || 0
            tx = parseInt(execSync(`cat /sys/class/net/${iface}/statistics/tx_bytes 2>/dev/null || echo 0`).toString()) || 0
        } catch {}

        const botName = global.namebot || 'Z4Z'
        const authorName = global.author || 'KazzTzy'
        const hostname = os.hostname().toUpperCase()
        const platform = `${os.platform()} (${os.arch()})`
        const release = os.release()
        const nodeVer = process.version
        const serverUp = fmtUp(os.uptime())
        const botUp = fmtUp(process.uptime())

        const W = 1400, H = 920
        const canvas = createCanvas(W, H)
        const ctx = canvas.getContext('2d')

        ctx.imageSmoothingEnabled = true
        ctx.imageSmoothingQuality = 'high'

        ctx.fillStyle = '#060c1c'
        ctx.fillRect(0, 0, W, H)

        const bgR = ctx.createRadialGradient(W / 2, H * 0.38, 0, W / 2, H * 0.38, 820)
        bgR.addColorStop(0, 'rgba(12,25,70,0.85)')
        bgR.addColorStop(1, 'rgba(2,4,14,0)')
        ctx.fillStyle = bgR; ctx.fillRect(0, 0, W, H)

        const HDR = 110
        const hdrG = ctx.createLinearGradient(0, 0, W, HDR)
        hdrG.addColorStop(0, '#0c1530')
        hdrG.addColorStop(1, '#080f22')
        ctx.fillStyle = hdrG; ctx.fillRect(0, 0, W, HDR)

        ctx.save()
        ctx.shadowColor = '#00cfff'; ctx.shadowBlur = 12
        ctx.fillStyle = '#00cfff'
        ctx.beginPath()
        ctx.moveTo(30, 55); ctx.lineTo(55, 30); ctx.lineTo(80, 55); ctx.lineTo(55, 80); ctx.closePath()
        ctx.fill()
        ctx.shadowBlur = 0; ctx.restore()

        txt(ctx, `${botName} DASHBOARD`, 98, 44, 32, '#ffffff', '700')
        txt(ctx, `${authorName} Interactive.`, 98, 74, 14, '#5a7aaa', '400')

        ctx.save()
        ctx.shadowColor = latClr; ctx.shadowBlur = 20
        txt(ctx, `${lat}ms`, W - 28, 42, 44, latClr, '700', 'right', 'middle')
        ctx.shadowBlur = 0; ctx.restore()
        txt(ctx, 'LATENCY', W - 28, 74, 13, '#5a7aaa', '400', 'right', 'middle')

        ctx.strokeStyle = '#00cfff'; ctx.lineWidth = 0.7; ctx.globalAlpha = 0.3
        ctx.beginPath(); ctx.moveTo(0, HDR); ctx.lineTo(W, HDR); ctx.stroke()
        ctx.globalAlpha = 1

        const P = 18, CY = HDR + P, CH = 280

        const gaugeCards = [
            {
                lbl: 'CPU USAGE',
                sub: `${cpuCores} Cores @ ${cpuSpeed} MHz`,
                pct: cpuPct,
                clr: '#2196f3',
                track: '#0d1f40',
                icon: '⬡',
                iclr: '#2196f3',
                f1: cpuModel.substring(0, 34),
                f2: null
            },
            {
                lbl: 'MEMORY',
                sub: `Total: ${fmtBytes(totalMem)}`,
                pct: memPct,
                clr: '#00e676',
                track: '#0a2218',
                icon: '≡',
                iclr: '#00e676',
                f1: `${fmtBytes(usedMem)} Used`,
                f2: `${fmtBytes(freeMem)} Free`
            },
            {
                lbl: 'STORAGE',
                sub: `Total: ${fmtBytes(diskTotal)}`,
                pct: diskPct,
                clr: '#9c64ff',
                track: '#180f35',
                icon: '◎',
                iclr: '#9c64ff',
                f1: `${fmtBytes(diskUsed)} Used`,
                f2: `${fmtBytes(diskFree)} Free`
            },
        ]

        const GW = Math.floor((W - P * 2 - P * 3) / 4)

        for (let i = 0; i < 3; i++) {
            const gc = gaugeCards[i]
            const cx = P + i * (GW + P)
            cardBg(ctx, cx, CY, GW, CH)

            ctx.save()
            ctx.shadowColor = gc.iclr; ctx.shadowBlur = 10
            iconBadge(ctx, cx + 16, CY + 16, gc.iclr, gc.icon, 40)
            ctx.shadowBlur = 0; ctx.restore()

            txt(ctx, gc.lbl, cx + 64, CY + 28, 18, '#ffffff', '700')
            txt(ctx, gc.sub, cx + 64, CY + 52, 12.5, '#5a7aaa', '400')

            const gx = cx + GW / 2, gy = CY + 164, R = 76
            drawGauge(ctx, gx, gy, R, gc.pct, gc.clr, gc.track)

            ctx.save()
            ctx.shadowColor = '#ffffff'; ctx.shadowBlur = 6
            txt(ctx, `${gc.pct}%`, gx, gy, 34, '#ffffff', '700', 'center', 'middle')
            ctx.shadowBlur = 0; ctx.restore()

            if (gc.f1 && gc.f2) {
                txt(ctx, gc.f1, gx, CY + CH - 38, 12.5, gc.iclr + 'cc', '600', 'center', 'middle')
                txt(ctx, gc.f2, gx, CY + CH - 16, 12.5, '#5a8aaa', '400', 'center', 'middle')
            } else if (gc.f1) {
                txt(ctx, gc.f1, gx, CY + CH - 18, 12, gc.iclr + 'bb', '400', 'center', 'middle')
            }
        }

        const NX = P + 3 * (GW + P)
        const NW = W - NX - P
        cardBg(ctx, NX, CY, NW, CH)

        ctx.save(); ctx.shadowColor = '#00cfff'; ctx.shadowBlur = 10
        iconBadge(ctx, NX + 16, CY + 16, '#00cfff', '❋', 40)
        ctx.shadowBlur = 0; ctx.restore()

        txt(ctx, 'NETWORK', NX + 64, CY + 28, 18, '#ffffff', '700')
        txt(ctx, `Interface: ${iface}`, NX + 64, CY + 52, 12.5, '#5a7aaa', '400')

        txt(ctx, 'RX (Download)', NX + 20, CY + 100, 13, '#8ab0d8', '400')
        ctx.save(); ctx.shadowColor = '#00cfff'; ctx.shadowBlur = 10
        txt(ctx, fmtBytes(rx), NX + 20, CY + 132, 26, '#00cfff', '700')
        ctx.shadowBlur = 0; ctx.restore()

        ctx.strokeStyle = '#1a2e50'; ctx.lineWidth = 0.9
        ctx.beginPath(); ctx.moveTo(NX + 16, CY + 162); ctx.lineTo(NX + NW - 16, CY + 162); ctx.stroke()

        txt(ctx, 'TX (Upload)', NX + 20, CY + 184, 13, '#8ab0d8', '400')
        txt(ctx, fmtBytes(tx), NX + 20, CY + 218, 26, '#cde4ff', '700')

        const IY = CY + CH + P, IH = 86
        const infoArr = [
            { lbl: 'HOSTNAME',     val: hostname,  icon: '▦', clr: '#2196f3' },
            { lbl: 'PLATFORM',     val: platform,  icon: '▤', clr: '#00e676' },
            { lbl: 'BOT UPTIME',   val: botUp,     icon: '◷', clr: '#9c64ff' },
            { lbl: 'SERVER UPTIME',val: serverUp,  icon: '◔', clr: '#ffcc00' },
            { lbl: 'NODE.JS',      val: nodeVer,   icon: '⬡', clr: '#00cfff' },
        ]
        const IW = Math.floor((W - P * 2 - P * 4) / 5)

        for (let i = 0; i < infoArr.length; i++) {
            const it = infoArr[i]
            const ix = P + i * (IW + P)
            cardBg(ctx, ix, IY, IW, IH)
            ctx.save(); ctx.shadowColor = it.clr; ctx.shadowBlur = 8
            txt(ctx, it.icon, ix + 26, IY + 32, 20, it.clr, 'bold', 'center', 'middle')
            ctx.shadowBlur = 0; ctx.restore()
            txt(ctx, it.lbl,  ix + 46, IY + 20, 11.5, '#5a7aaa', '400')
            txt(ctx, it.val,  ix + 46, IY + 50, 17,   '#ffffff',  '700')
        }

        const PFY = IY + IH + P, PFH = H - PFY - P
        cardBg(ctx, P, PFY, W - P * 2, PFH)

        txt(ctx, `${botName} PERFORMANCE`, P + 20, PFY + 30, 22, '#ffffff', '700')
        txt(ctx, `${authorName} Interactive`, P + 20, PFY + 56, 13, '#5a7aaa', '400')

        const BX = P + 20, BW = 480
        const BSTART = PFY + 76
        const BGAP = (PFH - 100) / 4
        const SGAP = (PFH - 100) / 5

        const bars = [
            { lbl: 'CPU Load',        pct: cpuPct,                     val: `${cpuPct.toFixed(1)}%`, clr: '#2196f3' },
            { lbl: 'Memory Usage',    pct: memPct,                     val: `${memPct}%`,            clr: '#00e676' },
            { lbl: 'Disk Usage',      pct: diskPct,                    val: `${diskPct}%`,           clr: '#9c64ff' },
            { lbl: 'Network Latency', pct: Math.min(lat / 5, 100),     val: `${lat}ms`,              clr: latClr, dot: lat < 80 },
        ]

        for (let i = 0; i < bars.length; i++) {
            const b = bars[i]
            const by = BSTART + i * BGAP
            txt(ctx, b.lbl, BX, by, 13, '#8ab0d8', '400')
            txt(ctx, b.val, BX + BW + 14, by + 13, 13, '#8ab0d8', '400', 'left', 'middle')
            if (b.dot) {
                ctx.save(); ctx.shadowColor = b.clr; ctx.shadowBlur = 14
                ctx.beginPath(); ctx.arc(BX + 7, by + 24, 8, 0, Math.PI * 2)
                ctx.fillStyle = b.clr; ctx.fill()
                ctx.shadowBlur = 0; ctx.restore()
            } else {
                drawBar(ctx, BX, by + 16, BW, 14, b.pct, b.clr)
            }
        }

        const SX = BX + BW + 72
        const specs = [
            ['OS Release',    release],
            ['CPU Cores',     `${cpuCores} Cores`],
            ['CPU Speed',     `${cpuSpeed} MHz`],
            ['Total Memory',  fmtBytes(totalMem)],
            ['Free Memory',   fmtBytes(freeMem)],
        ]
        for (let i = 0; i < specs.length; i++) {
            const sy = BSTART + i * SGAP + 12
            txt(ctx, specs[i][0], SX,       sy, 13, '#5a7aaa', '400', 'left', 'middle')
            txt(ctx, specs[i][1], SX + 170, sy, 14, '#cde4ff', '700', 'left', 'middle')
        }

        const IMG_AREA_W = 380
        const IMG_AREA_X = W - P - IMG_AREA_W - 10
        await draw3Cards(ctx, BOT_IMG, IMG_AREA_X, PFY + 8, IMG_AREA_W, PFH - 16)

        const now = new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' })
        txt(ctx, `Dashboard Generated: ${now}`, W / 2, H - 11, 12, '#2a3d60', '400', 'center', 'middle')

        const buf = canvas.toBuffer('image/png')
        await KazzTzy.sendMessage(m.chat, { image: buf, caption: `*📡 ${botName} Dashboard*\n_Latency: ${lat}ms_` })
        await KazzTzy.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

    } catch (e) {
        console.error(e)
        await KazzTzy.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        m.reply('Gagal: ' + e.message)
    }
}

handler.help = ['ping']
handler.tags = ['info']
handler.command = /^(ping|p)$/i

export default handler