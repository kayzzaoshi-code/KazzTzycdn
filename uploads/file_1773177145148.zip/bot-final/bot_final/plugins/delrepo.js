import axios from "axios";

const TOKEN = "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";
const OWNER = "KazzTzyPrivat7777";

async function deleteRepo(repo) {
  const url = `https://api.github.com/repos/${OWNER}/${repo}`;
  await axios.delete(url, {
    headers: { Authorization: `token ${TOKEN}` }
  });
}

let handler = async (m, { text }) => {
  try {
    if (!text) return m.reply("❌ Format: .delrepo <namaRepo>");

    const repoName = text.trim();

    await deleteRepo(repoName);

    m.reply(`✅ Repo ${repoName} berhasil dihapus`);
  } catch (e) {
    m.reply("❌ Terjadi kesalahan: " + (e.response?.data?.message || e.message));
  }
};

handler.help = ["delrepo <namaRepo>"];
handler.tags = ["tools"];
handler.command = /^(delrepo)$/i;
handler.owner = true;

export default handler;