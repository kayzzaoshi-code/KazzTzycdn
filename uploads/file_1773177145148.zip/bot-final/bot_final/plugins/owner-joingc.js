let handler = async (m, { KazzTzy, text, isOwner }) => {
  if (!isOwner) return;

  if (!text) {
    return m.reply(
      "╔══[ JOIN GC ]══╗\n" +
      "𖣂 Masuk ke grup via link\n\n" +
      "Format:\n" +
      ".joingc <link>\n\n" +
      "Contoh:\n" +
      ".joingc https://chat.whatsapp.com/xxx\n" +
      "╚═══════════════╝"
    );
  }

  const input = text.trim();

  if (!input.includes("chat.whatsapp.com")) {
    return m.reply("𖣂 Masukkan link grup yang valid.\nContoh: https://chat.whatsapp.com/xxx");
  }

  await m.react("⏳");

  try {
    const code = input.split("/").pop().split("?")[0];
    const info = await KazzTzy.groupGetInviteInfo(code).catch(() => null);
    await KazzTzy.groupAcceptInvite(code);

    await m.react("✅");
    await KazzTzy.sendMessage(m.chat, {
      text: [
        "╔══[ BERHASIL JOIN ]══╗",
        "",
        "𖣂 Nama  : " + (info?.subject || "-"),
        "𖣂 JID   : " + (info?.id || "-"),
        "𖣂 Member: " + (info?.size || "-") + " orang",
        "",
        "╚══════════════════════╝"
      ].join("\n")
    }, { quoted: m });
  } catch (e) {
    await m.react("❌");
    m.reply("𖣂 Gagal join grup: " + (e.message || e));
  }
};

handler.help = ["joingc <link>"];
handler.tags = ["owner"];
handler.command = /^joingc$/i;
handler.owner = true;

export default handler;
