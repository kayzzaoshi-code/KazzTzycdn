import axios from 'axios';

let handler = async (m) => {
    const user = global.db.data.users[m.sender];
    if (!user) return m.reply('User tidak ditemukan.');

    let pp;
    try {
        let res = await axios.get('https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1772307500109.jpeg', { responseType: 'arraybuffer' });
        pp = Buffer.from(res.data);
    } catch {
        pp = null;
    }

    let inv = `
Inventory
sword: ${user.sword || 0}
pickaxe: ${user.pickaxe || 0}
axe: ${user.axe || 0}
fishingrod: ${user.fishingrod || 0}
armor: ${user.armor || 0}
atm: ${user.atm || 0}

Durability
sword: ${user.sworddurability || 0}
pickaxe: ${user.pickaxedurability || 0}
axe: ${user.axedurability || 0}
fishingrod: ${user.fishingroddurability || 0}
armor: ${user.armordurability || 0}
`;

    await KazzTzy.sendMessage(m.chat, {
        text: inv,
        contextInfo: {
            externalAdReply: {
                title: 'Inventory',
                body: '',
                thumbnail: pp,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
};

handler.help = ['inventory'];
handler.tags = ['rpg'];
handler.command = /^(inventory|inv)$/i;

export default handler;