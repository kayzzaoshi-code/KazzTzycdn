import axios from "axios";

async function sendAIReply(KazzTzy, m, text) {
  return KazzTzy.sendMessage(m.chat, {
    text: String(text),
    mentions: [m.sender],
    contextInfo: {
      externalAdReply: {
        title: "Z4Z Bot",
        body: "KazzTzy",
        thumbnailUrl: "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1772016271450.jpeg",
        sourceUrl: global.source || "https://wa.me/6285795269956",
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m });
}

let handler = async (m, { KazzTzy }) => {
    try {
        await m.react(global.react || "⏳");

        const res = await axios.get("https://openai.idnet.my.id/chat.data", {
            headers: { "User-Agent": "Mozilla/5.0" }
        });

        const data = res.data;
        const index = data.indexOf("content");
        const message = index !== -1 ? data[index + 1] : "Tidak ditemukan";

        await KazzTzy.sendMessage(
            m.chat,
            { text: message },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");
    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e?.response?.data || e.message || e));
    }
};

handler.help = ["chatdata"];
handler.tags = ["tools"];
handler.command = /^openai$/i;
handler.register = true;
handler.limit = true;

export default handler;