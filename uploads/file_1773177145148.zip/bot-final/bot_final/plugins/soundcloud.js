import axios from "axios"
import * as cheerio from "cheerio"

let handler = async (m, { KazzTzy, text }) => {
    try {
        if (!text) return m.reply("Masukkan URL SoundCloud")

        await m.react("⏳")

        const headers = {
            accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "accept-language": "en-US,en;q=0.9",
            origin: "https://downcloudme.com",
            referer: "https://downcloudme.com/soundcloud-playlist-downloader/",
            "user-agent": "Mozilla/5.0",
            "content-type": "application/x-www-form-urlencoded"
        }

        const params = new URLSearchParams()
        params.append("url", text)

        const { data } = await axios.post(
            "https://downcloudme.com/download",
            params.toString(),
            { headers }
        )

        const $ = cheerio.load(data)

        const firstTrack = $(".custom-track-container").first()
        const title = firstTrack.find(".custom-track-title").text().trim()
        const downloadLink = firstTrack.find(".custom-download-btn").attr("href")

        if (!downloadLink) {
            await m.react("❌")
            return m.reply("Gagal mendapatkan link audio")
        }

        const finalUrl = downloadLink.startsWith("http")
            ? downloadLink
            : `https://downcloudme.com${downloadLink}`

        await KazzTzy.sendMessage(m.chat, {
            audio: { url: finalUrl },
            mimetype: "audio/mpeg",
            fileName: `${title}.mp3`
        }, { quoted: m })

        await m.react("✅")

    } catch (err) {
        console.log(err)
        await m.react("❌")
        m.reply("Terjadi kesalahan saat mengambil audio")
    }
}

handler.help = ["scdl"]
handler.tags = ["downloader"]
handler.command = ["scdl"]

export default handler