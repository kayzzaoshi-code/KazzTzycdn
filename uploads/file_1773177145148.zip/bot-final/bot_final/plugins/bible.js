import axios from "axios";

let handler = async (m, { text }) => {
    const input = m.quoted ? m.quoted.text : text;
    if (!input) return m.reply("Masukkan pertanyaan Alkitabnya.");

    try {
        await m.react("⏳");

        const translation = "TB";
        const language = "id";
        const filters = ["bible", "books", "articles"];

        const params = new URLSearchParams({
            question: input,
            translation,
            language,
            "filters[]": filters,
            pro: "false"
        });

        const url = `https://api.bibleai.com/v2/search?${params.toString()}`;

        const response = await axios.get(url, {
            headers: {
                "User-Agent": "Mozilla/5.0",
                Accept: "application/json",
                Origin: "https://bibleai.com",
                Referer: "https://bibleai.com/"
            }
        });

        if (!response.data || response.data.status !== 1) {
            await m.react("❌");
            return m.reply("Tidak ada hasil ditemukan.");
        }

        const { answer, sources } = response.data.data;

        let replyText = `📖 *Jawaban:*\n${answer}\n`;

        if (Array.isArray(sources)) {
            const verses = sources
                .filter(s => s.type === "verse")
                .slice(0, 5)
                .map(s => `\n✝️ ${s.text}`)
                .join("\n");

            replyText += `\n\n📚 *Referensi Ayat:*${verses}`;
        }

        await m.reply(replyText);
        await m.react("✅");

    } catch (err) {
        await m.react("❌");
        m.reply("Terjadi kesalahan:\n" + (err.response?.data?.message || err.message));
    }
};

handler.help = ["bible <pertanyaan>"];
handler.tags = ["ai"];
handler.command = /^bible$/i;
handler.limit = true;

export default handler;