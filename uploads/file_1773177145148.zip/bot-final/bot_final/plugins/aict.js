import fetch from "node-fetch";
import fs from "fs";

let handler = async (m, { KazzTzy, text }) => {
    try {
        await m.react(global.react || "⏳");

        if (!text && !m.quoted) {
            return m.reply("❌ Masukkan pertanyaan atau reply gambar dengan teks.");
        }

        let file = null;
        let question = text || "";

        if (m.quoted && m.quoted.mimetype?.startsWith("image")) {
            const media = await m.quoted.download();
            const filePath = `./tmp_${Date.now()}.jpg`;
            fs.writeFileSync(filePath, media);

            const buffer = fs.readFileSync(filePath);
            file = {
                data: buffer.toString("base64"),
                type: "image/jpeg",
                name: filePath.split("/").pop()
            };

            fs.unlinkSync(filePath);
        }

        const res = await fetch("https://aifreeforever.com/api/generate-ai-answer", {
            method: "POST",
            headers: {
                "accept": "*/*",
                "accept-language": "id-ID",
                "content-type": "application/json",
                "referer": "https://aifreeforever.com/tools/free-chatgpt-no-login"
            },
            body: JSON.stringify({
                question,
                tone: "friendly",
                format: "paragraph",
                file
            })
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const data = await res.json();

        if (!data.answer) {
            return m.reply("❌ Gagal mendapatkan jawaban.");
        }

        await KazzTzy.sendMessage(
            m.chat,
            { text: data.answer },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        console.log(e);
        await m.react(global.reactError || "❌");
        m.reply("Error: " + e.message);
    }
};

handler.help = ["aict <pertanyaan>"];
handler.tags = ["ai"];
handler.command = /^aict$/i;
handler.register = true;
handler.limit = true;

export default handler;