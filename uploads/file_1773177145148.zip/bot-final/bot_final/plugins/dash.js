import { createCanvas, loadImage } from 'canvas'

let handler = async (m, { KazzTzy }) => {
    try {
        await KazzTzy.sendMessage(m.chat, { react: { text: "🕐", key: m.key } })

        const statsData = global.db?.data?.stats || {}
        const pluginsData = global.plugins || {}
        const totalChats = global.db?.data?.chats ? Object.keys(global.db.data.chats).length : 0

        let stats = Object.entries(statsData)
            .map(([key, val]) => {
                let plugin = pluginsData[key] || {}
                let name = Array.isArray(plugin.help) ? plugin.help.join(' , ') : plugin.help || key
                if (/exec/.test(name)) return null
                return { name, ...val }
            })
            .filter(item => item !== null)

        if (!stats.length) return m.reply("❌ Data statistik masih kosong.")

        stats = stats.sort((a, b) => b.total - a.total).slice(0, 12)

        const COLS = 3
        const CARD_W = 360
        const CARD_H = 120
        const PAD = 28
        const HEADER_H = 240
        const SUMMARY_H = 110
        const ROWS = Math.ceil(stats.length / COLS)
        const width = COLS * CARD_W + (COLS + 1) * PAD
        const height = HEADER_H + SUMMARY_H + ROWS * (CARD_H + PAD) + PAD + 40

        const canvas = createCanvas(width, height)
        const ctx = canvas.getContext('2d')

        const bg = ctx.createLinearGradient(0, 0, width, height)
        bg.addColorStop(0, '#1a1a2e')
        bg.addColorStop(0.4, '#16213e')
        bg.addColorStop(0.8, '#0f3460')
        bg.addColorStop(1, '#1a1a2e')
        ctx.fillStyle = bg
        ctx.fillRect(0, 0, width, height)

        ctx.save()
        ctx.globalAlpha = 0.04
        for (let row = 0; row < height / 40; row++) {
            for (let col = 0; col < width / 40; col++) {
                if ((row + col) % 2 === 0) {
                    ctx.fillStyle = '#e8d5a3'
                    ctx.fillRect(col * 40, row * 40, 40, 40)
                }
            }
        }
        ctx.restore()

        const drawGlow = (x, y, r, r_val, g_val, b_val, alpha) => {
            const g = ctx.createRadialGradient(x, y, 0, x, y, r)
            g.addColorStop(0, `rgba(${r_val},${g_val},${b_val},${alpha})`)
            g.addColorStop(1, 'rgba(0,0,0,0)')
            ctx.fillStyle = g
            ctx.beginPath()
            ctx.arc(x, y, r, 0, Math.PI * 2)
            ctx.fill()
        }

        drawGlow(150, 150, 300, 230, 197, 120, 0.10)
        drawGlow(width - 150, 100, 250, 100, 180, 255, 0.08)
        drawGlow(width / 2, height * 0.6, 350, 160, 120, 220, 0.06)

        const drawRect = (x, y, w, h, r, fill, strokeColor, strokeW) => {
            ctx.beginPath()
            ctx.moveTo(x + r, y)
            ctx.lineTo(x + w - r, y)
            ctx.quadraticCurveTo(x + w, y, x + w, y + r)
            ctx.lineTo(x + w, y + h - r)
            ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h)
            ctx.lineTo(x + r, y + h)
            ctx.quadraticCurveTo(x, y + h, x, y + h - r)
            ctx.lineTo(x, y + r)
            ctx.quadraticCurveTo(x, y, x + r, y)
            ctx.closePath()
            if (fill) { ctx.fillStyle = fill; ctx.fill() }
            if (strokeColor) { ctx.strokeStyle = strokeColor; ctx.lineWidth = strokeW || 1; ctx.stroke() }
        }

        const drawDiamond = (cx, cy, size, color) => {
            ctx.save()
            ctx.beginPath()
            ctx.moveTo(cx, cy - size)
            ctx.lineTo(cx + size * 0.6, cy)
            ctx.lineTo(cx, cy + size)
            ctx.lineTo(cx - size * 0.6, cy)
            ctx.closePath()
            ctx.strokeStyle = color
            ctx.lineWidth = 1.5
            ctx.globalAlpha = 0.5
            ctx.stroke()
            ctx.restore()
        }

        for (let i = 0; i < 18; i++) {
            drawDiamond(
                Math.random() * width,
                Math.random() * height,
                4 + Math.random() * 8,
                `rgba(230,197,120,${0.1 + Math.random() * 0.2})`
            )
        }

        for (let i = 0; i < 40; i++) {
            ctx.beginPath()
            ctx.arc(Math.random() * width, Math.random() * height, Math.random() * 1.2, 0, Math.PI * 2)
            ctx.fillStyle = `rgba(255,255,255,${0.05 + Math.random() * 0.15})`
            ctx.fill()
        }

        ctx.save()
        ctx.shadowColor = '#e6c578'
        ctx.shadowBlur = 20
        ctx.fillStyle = '#e6c578'
        ctx.font = 'bold 52px serif'
        ctx.fillText('KazzTzy', PAD, 72)
        ctx.restore()

        ctx.fillStyle = 'rgba(230,213,163,0.7)'
        ctx.font = '16px sans-serif'
        ctx.fillText('R E A L T I M E   D A S H B O A R D', PAD + 3, 100)

        ctx.save()
        ctx.strokeStyle = 'rgba(230,197,120,0.4)'
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(PAD, 112)
        ctx.lineTo(width - PAD, 112)
        ctx.stroke()
        ctx.restore()

        const totalUsage = stats.reduce((a, b) => a + (b.total || 0), 0)
        const totalSuccess = stats.reduce((a, b) => a + (b.success || 0), 0)
        const activeFeatures = stats.filter(s => (Date.now() - s.last) < 600000).length

        const summaryItems = [
            { label: 'Total Usage', value: totalUsage.toLocaleString(), icon: '⚔', color: '#e6c578', gr: '230,197,120' },
            { label: 'Total Success', value: totalSuccess.toLocaleString(), icon: '✦', color: '#7ec8e3', gr: '126,200,227' },
            { label: 'Active Features', value: activeFeatures, icon: '◈', color: '#a8d8a8', gr: '168,216,168' },
            { label: 'Total Chats', value: totalChats.toLocaleString(), icon: '❋', color: '#c9a0dc', gr: '201,160,220' },
        ]

        const sumW = (width - PAD * 5) / 4
        summaryItems.forEach((item, i) => {
            const sx = PAD + i * (sumW + PAD)
            const sy = HEADER_H - 10

            const cardGrad = ctx.createLinearGradient(sx, sy, sx + sumW, sy + 90)
            cardGrad.addColorStop(0, 'rgba(255,255,255,0.07)')
            cardGrad.addColorStop(1, 'rgba(255,255,255,0.02)')
            drawRect(sx, sy, sumW, 90, 8, cardGrad, `rgba(${item.gr},0.4)`, 1)

            ctx.save()
            ctx.shadowColor = item.color
            ctx.shadowBlur = 12
            ctx.fillStyle = item.color
            ctx.font = 'bold 26px sans-serif'
            ctx.fillText(item.value, sx + 14, sy + 38)
            ctx.restore()

            ctx.fillStyle = 'rgba(230,213,163,0.55)'
            ctx.font = '13px sans-serif'
            ctx.fillText(item.label, sx + 14, sy + 62)

            ctx.save()
            ctx.globalAlpha = 0.25
            ctx.fillStyle = item.color
            ctx.font = '28px sans-serif'
            ctx.fillText(item.icon, sx + sumW - 44, sy + 52)
            ctx.restore()

            ctx.save()
            ctx.strokeStyle = item.color
            ctx.lineWidth = 2.5
            ctx.globalAlpha = 0.6
            ctx.shadowColor = item.color
            ctx.shadowBlur = 6
            ctx.beginPath()
            ctx.moveTo(sx + 8, sy + 12)
            ctx.lineTo(sx + 8, sy + 78)
            ctx.stroke()
            ctx.restore()
        })

        const palette = [
            { line: '#e6c578', gr: '230,197,120' },
            { line: '#7ec8e3', gr: '126,200,227' },
            { line: '#a8d8a8', gr: '168,216,168' },
            { line: '#c9a0dc', gr: '201,160,220' },
            { line: '#f4a261', gr: '244,162,97' },
            { line: '#e76f51', gr: '231,111,81' },
        ]

        for (let i = 0; i < stats.length; i++) {
            const s = stats[i]
            const col = i % COLS
            const row = Math.floor(i / COLS)
            const cx = PAD + col * (CARD_W + PAD)
            const cy = HEADER_H + SUMMARY_H + row * (CARD_H + PAD)
            const isOnline = (Date.now() - s.last) < 600000
            const acc = palette[i % palette.length]

            const cardBg = ctx.createLinearGradient(cx, cy, cx + CARD_W, cy + CARD_H)
            cardBg.addColorStop(0, 'rgba(255,255,255,0.06)')
            cardBg.addColorStop(1, 'rgba(255,255,255,0.02)')
            drawRect(cx, cy, CARD_W, CARD_H, 10, cardBg, `rgba(${acc.gr},0.35)`, 1)

            ctx.save()
            ctx.strokeStyle = acc.line
            ctx.lineWidth = 2.5
            ctx.shadowColor = acc.line
            ctx.shadowBlur = 8
            ctx.globalAlpha = 0.8
            ctx.beginPath()
            ctx.moveTo(cx + 1, cy + 14)
            ctx.lineTo(cx + 1, cy + CARD_H - 14)
            ctx.stroke()
            ctx.restore()

            ctx.save()
            ctx.fillStyle = acc.line
            ctx.shadowColor = acc.line
            ctx.shadowBlur = 6
            ctx.font = 'bold 13px monospace'
            ctx.globalAlpha = 0.8
            ctx.fillText(String(i + 1).padStart(2, '0'), cx + 10, cy + 24)
            ctx.restore()

            ctx.fillStyle = '#f0e6c8'
            ctx.font = 'bold 16px sans-serif'
            const nameText = s.name.length > 24 ? s.name.slice(0, 22) + '…' : s.name
            ctx.fillText(nameText, cx + 42, cy + 26)

            const barY = cy + 42
            const barW = CARD_W - 24
            const barH = 5
            const percent = stats[0].total > 0 ? Math.min((s.total || 0) / stats[0].total, 1) : 0

            drawRect(cx + 12, barY, barW, barH, 3, 'rgba(255,255,255,0.07)', null)

            if (percent > 0) {
                ctx.save()
                ctx.shadowColor = acc.line
                ctx.shadowBlur = 6
                const bGrad = ctx.createLinearGradient(cx + 12, 0, cx + 12 + barW * percent, 0)
                bGrad.addColorStop(0, acc.line)
                bGrad.addColorStop(1, `rgba(${acc.gr},0.3)`)
                drawRect(cx + 12, barY, barW * percent, barH, 3, bGrad, null)
                ctx.restore()
            }

            ctx.fillStyle = 'rgba(230,213,163,0.7)'
            ctx.font = '13px sans-serif'
            ctx.fillText('Used: ' + (s.total || 0), cx + 12, cy + 68)

            ctx.fillStyle = '#7ec8e3'
            ctx.font = '13px sans-serif'
            ctx.fillText('OK: ' + (s.success || 0), cx + 105, cy + 68)

            ctx.save()
            ctx.shadowColor = isOnline ? '#a8d8a8' : 'transparent'
            ctx.shadowBlur = isOnline ? 8 : 0
            ctx.fillStyle = isOnline ? '#a8d8a8' : '#555'
            ctx.font = 'bold 12px monospace'
            ctx.fillText(isOnline ? '◉ ACTIVE' : '○ IDLE', cx + 210, cy + 68)
            ctx.restore()

            ctx.fillStyle = 'rgba(200,190,170,0.35)'
            ctx.font = '11px sans-serif'
            const timeText = getTime(s.last)
            const tw = ctx.measureText(timeText).width
            ctx.fillText(timeText, cx + CARD_W - tw - 12, cy + 100)

            drawDiamond(cx + CARD_W - 20, cy + 22, 5, `rgba(${acc.gr},0.6)`)
        }

        ctx.save()
        ctx.strokeStyle = 'rgba(230,197,120,0.2)'
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(PAD, height - 30)
        ctx.lineTo(width - PAD, height - 30)
        ctx.stroke()
        ctx.restore()

        ctx.fillStyle = 'rgba(200,185,145,0.3)'
        ctx.font = '12px monospace'
        ctx.fillText('✦ KazzTzy System  ·  ' + new Date().toLocaleString('id-ID') + '  ·  ' + stats.length + ' features loaded', PAD, height - 12)

        const buffer = canvas.toBuffer('image/png')
        await KazzTzy.sendMessage(m.chat, {
            image: buffer,
            caption: 'Dash'
        })

    } catch (e) {
        console.error(e)
        await KazzTzy.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
        m.reply('❌ Gagal membuat dashboard: ' + e.message)
    }
}

handler.help = ['dash']
handler.tags = ['info']
handler.command = /^(dashboard|dash)$/i
export default handler

function getTime(ms) {
    if (!ms) return "N/A"
    let now = Date.now() - ms
    let mins = Math.floor(now / 60000)
    let hours = Math.floor(mins / 60)
    let days = Math.floor(hours / 24)
    if (days) return days + "d ago"
    if (hours) return hours + "h ago"
    if (mins) return mins + "m ago"
    return "Just now"
}