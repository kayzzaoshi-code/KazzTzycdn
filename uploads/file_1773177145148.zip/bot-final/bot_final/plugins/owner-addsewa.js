import axios from "axios";

const sewaTimers = {};

async function getGroupJid(KazzTzy, input) {
  if (input.includes("@g.us")) return input.trim();
  if (input.includes("chat.whatsapp.com")) {
    const code = input.split("/").pop().split("?")[0];
    const info = await KazzTzy.groupGetInviteInfo(code);
    return info.id;
  }
  return null;
}

function daysToMs(days) {
  return days * 24 * 60 * 60 * 1000;
}

function formatExpiry(ms) {
  const d = Math.floor(ms / 86400000);
  const h = Math.floor((ms % 86400000) / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  if (d > 0) return d + " hari " + h + " jam";
  if (h > 0) return h + " jam " + m + " menit";
  return m + " menit";
}

async function startSewaTimer(KazzTzy, groupJid, expiryTime) {
  const remaining = expiryTime - Date.now();
  if (remaining <= 0) {
    await KazzTzy.groupLeave(groupJid).catch(() => {});
    const sewa = global.db.data.settings[KazzTzy.user.jid]?.sewa || {};
    delete sewa[groupJid];
    if (sewaTimers[groupJid]) {
      clearTimeout(sewaTimers[groupJid]);
      delete sewaTimers[groupJid];
    }
    return;
  }

  if (sewaTimers[groupJid]) clearTimeout(sewaTimers[groupJid]);

  sewaTimers[groupJid] = setTimeout(async () => {
    try {
      await KazzTzy.sendMessage(groupJid, {
        text: "𖣂 Masa sewa bot telah habis. Bot akan keluar. Terima kasih!"
      });
      await KazzTzy.groupLeave(groupJid);
    } catch {}
    const sewa = global.db.data.settings[KazzTzy.user.jid]?.sewa || {};
    delete sewa[groupJid];
    delete sewaTimers[groupJid];
  }, remaining);
}

let handler = async (m, { KazzTzy, text, args, isOwner }) => {
  if (!isOwner) return;

  const settings = global.db.data.settings[KazzTzy.user.jid];
  if (!settings.sewa) settings.sewa = {};
  const sewa = settings.sewa;

  if (!text) {
    const list = Object.entries(sewa);
    if (!list.length) return m.reply("𖣂 Belum ada grup sewa aktif.");
    const rows = list.map(([jid, data]) => {
      const left = data.expiryTime - Date.now();
      return "𖣂 " + (data.name || jid) + "\n     Sisa: " + (left > 0 ? formatExpiry(left) : "EXPIRED");
    }).join("\n\n");
    return m.reply("╔══[ LIST SEWA ]══╗\n\n" + rows + "\n\n╚═════════════════╝");
  }

  const sub = args[0]?.toLowerCase();

  if (sub === "del" || sub === "hapus") {
    const input = args[1] || "";
    const groupJid = await getGroupJid(KazzTzy, input).catch(() => null);
    if (!groupJid) return m.reply("𖣂 JID/link tidak valid.");
    if (sewaTimers[groupJid]) { clearTimeout(sewaTimers[groupJid]); delete sewaTimers[groupJid]; }
    delete sewa[groupJid];
    return m.reply("𖣂 Sewa grup dihapus: " + groupJid);
  }

  const daysMatch = text.match(/(\d+)\s*hari/i);
  if (!daysMatch) {
    return m.reply(
      "╔══[ ADDSEWA ]══╗\n" +
      "𖣂 Format:\n" +
      ".addsewa <link/jid> <Xhari>\n\n" +
      "Contoh:\n" +
      ".addsewa https://chat.whatsapp.com/xxx 15hari\n" +
      ".addsewa 120363xxx@g.us 7hari\n\n" +
      "𖣂 .addsewa → lihat list\n" +
      "𖣂 .addsewa del <jid> → hapus\n" +
      "╚════════════════╝"
    );
  }

  const days = parseInt(daysMatch[1]);
  const linkOrJid = args.find(a => a.includes("chat.whatsapp.com") || a.includes("@g.us")) || "";

  if (!linkOrJid) return m.reply("𖣂 Masukkan link atau JID grup.");

  await m.react("⏳");

  let groupJid;
  let groupName = "-";

  try {
    groupJid = await getGroupJid(KazzTzy, linkOrJid);
    if (!groupJid) throw new Error("JID tidak ditemukan");
    const meta = await KazzTzy.groupMetadata(groupJid).catch(() => null);
    groupName = meta?.subject || groupJid;
  } catch (e) {
    await m.react("❌");
    return m.reply("𖣂 Gagal ambil info grup: " + e.message);
  }

  if (!Object.keys(await KazzTzy.groupFetchAllParticipating().catch(() => ({}))).includes(groupJid)) {
    try {
      const code = linkOrJid.split("/").pop().split("?")[0];
      await KazzTzy.groupAcceptInvite(code);
    } catch {}
  }

  const expiryTime = Date.now() + daysToMs(days);
  sewa[groupJid] = { name: groupName, expiryTime, days };

  await startSewaTimer(KazzTzy, groupJid, expiryTime);

  await m.react("✅");
  await KazzTzy.sendMessage(m.chat, {
    text: [
      "╔══[ SEWA AKTIF ]══╗",
      "",
      "𖣂 Grup  : " + groupName,
      "𖣂 JID   : " + groupJid,
      "𖣂 Durasi: " + days + " hari",
      "𖣂 Habis : " + new Date(expiryTime).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }),
      "",
      "𖣂 Bot otomatis keluar setelah waktu habis.",
      "╚═══════════════════╝"
    ].join("\n")
  }, { quoted: m });
};

handler.help = ["addsewa <link/jid> <Xhari>"];
handler.tags = ["owner"];
handler.command = /^addsewa$/i;
handler.owner = true;

export { sewaTimers, startSewaTimer };
export default handler;
