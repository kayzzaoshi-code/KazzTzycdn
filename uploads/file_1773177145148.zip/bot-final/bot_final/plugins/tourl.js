import axios from 'axios';
const GH_TOKEN = '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';
const GH_OWNER = 'kayzzaoshi-code';
const GH_REPO = 'Uploader';
async function createRepo() {
  try { await axios.post('https://api.github.com/user/repos', { name: GH_REPO, private: false }, { headers: { Authorization: `token ${GH_TOKEN}` } }); } catch {}
}
async function uploadToGitHub(buffer, mimetype = 'application/octet-stream') {
  await createRepo();
  const ext = mimetype.split('/')[1] || 'bin';
  const filename = `file_${Date.now()}.${ext}`;
  const res = await axios.put(`https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${filename}`, { message: `Upload ${filename}`, content: Buffer.from(buffer).toString('base64') }, { headers: { Authorization: `token ${GH_TOKEN}` } });
  return res.data.content.download_url;
}

const KEY = "AIzaBj7z2z3xBjsk";
const DOMAIN = "https://c.termai.cc";

let handler = async (m, { KazzTzy }) => {
  try {
    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype;
    if (!mime) return m.reply("Reply media untuk diupload.");

    const buffer = await q.download();
    const url = await uploadToGitHub(buffer, mime);
    if (!url) return m.reply("❌ Gagal upload ke server.");

    await KazzTzy.sendMessage(m.chat, { text: `🔗 Link hasil upload:\n${url}` }, { quoted: m });
  } catch (e) {
    console.error(e);
    m.reply("❌ Terjadi kesalahan: " + e.message);
  }
};

handler.help = ["tourl", "tolink"];
handler.tags = ["tools"];
handler.command = /^(tourl|tolink)$/i;
handler.limit = true;

export default handler;
