import axios from "axios";

const API = "https://kayzzidgf.my.id";
export const sessions = {};

let handler = async (m, { KazzTzy, usedPrefix }) => {
  const chat = m.chat;
  if (sessions[chat]) return m.reply("𖣂 Masih ada soal aktif! Jawab dulu atau " + usedPrefix + "stoptebaklagu");

  await m.react(global.react);

  const res = await axios.get(API + "/api/game/tebaklagu?apikey=KazzTzy").catch(() => null);
  if (!res?.data?.lagu) return m.reply("𖣂 Gagal ambil soal.");

  sessions[chat] = {
    jawaban: String(res.data.judul).toLowerCase(),
    artis: res.data.artis || "",
    timeout: setTimeout(() => {
      delete sessions[chat];
      KazzTzy.sendMessage(chat, { text: "𖣂 Waktu habis! Jawaban: *" + res.data.judul + "* - " + (res.data.artis || "") });
    }, 60000)
  };

  await KazzTzy.sendMessage(chat, {
    audio: { url: res.data.lagu },
    mimetype: "audio/mpeg",
    ptt: false
  }, { quoted: m });
  await KazzTzy.sendMessage(chat, {
    text: "╔══[ TEBAK LAGU ]══╗\n\n𖣂 Tebak judul lagu ini!\n\n𖣂 Waktu: 60 detik\n𖣂 Hadiah: +5 Limit, +500 Uang, +90 EXP\n╚═══════════════════╝"
  }, { quoted: m });

  await m.react(global.reactSuccess);
};

handler.help = ["tebaklagu"];
handler.tags = ["game"];
handler.command = /^tebaklagu$/i;
handler.register = true;
export default handler;
