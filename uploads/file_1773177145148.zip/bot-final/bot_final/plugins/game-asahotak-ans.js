import { sessions } from "./game-asahotak.js";

export function before(m) {
  if (!m.text || m.isBaileys) return true;
  const session = sessions[m.chat];
  if (!session) return true;
  if (m.text.trim().toLowerCase() !== session.jawaban) return true;

  clearTimeout(session.timeout);
  delete sessions[m.chat];

  const user = global.db.data.users[m.sender];
  if (user) { user.limit += 4; user.money += 350; user.exp += 75; }

  KazzTzy.sendMessage(m.chat, {
    text: "╔══[ BENAR! ]══╗\n\n𖣂 " + (KazzTzy.getName(m.sender) || m.sender.split("@")[0]) + " menang!\n𖣂 +4 Limit | +350 Uang | +75 EXP\n╚══════════════╝"
  }, { quoted: m });
  return false;
}
