import { parentPort } from 'worker_threads';

let handler = async (m, { KazzTzy }) => {
	if (!parentPort) throw 'Dont: node main.js\nDo: node index.js';
	if (global.KazzTzy.user.jid == KazzTzy.user.jid) {
		await m.reply('```R E S T A R T . . .```');
		parentPort.postMessage('restart');
	} else throw '_eeeeeiiittsssss..._';
};

handler.help = ['restart'];
handler.tags = ['owner'];
handler.command = /^(res(tart)?)$/i;
handler.owner = true;

export default handler;
