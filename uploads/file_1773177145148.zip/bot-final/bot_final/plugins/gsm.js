import axios from "axios";
import * as cheerio from "cheerio";

let handler = async (m, { KazzTzy, text }) => {
    try {
        await m.react(global.react || "⏳");

        if (!text) return m.reply("❌ Masukkan nama HP");

        const searchUrl = "https://www.gsmarena.com/results.php3?sQuickSearch=yes&sName=" + encodeURIComponent(text);

        const { data } = await axios.get(searchUrl, {
            headers: { "User-Agent": "Mozilla/5.0" }
        });

        const $ = cheerio.load(data);
        const first = $(".makers li").first();

        if (!first.length) return m.reply("❌ Tidak ditemukan");

        const href = first.find("a").attr("href");
        const detailUrl = "https://www.gsmarena.com/" + href;

        const { data: detailData } = await axios.get(detailUrl, {
            headers: { "User-Agent": "Mozilla/5.0" }
        });

        const $$ = cheerio.load(detailData);

        const name = $$("h1").first().text().trim();
        const image = $$(".specs-photo-main img").attr("src");

        let caption = `📱 *${name}*\n\n`;

        $$("#specs-list table").each((_, table) => {
            const category = $$(table).find("th").first().text().trim();
            if (!category) return;

            caption += `*${category}*\n`;

            $$(table).find("tr").each((_, row) => {
                const key = $$(row).find("td").first().text().trim();
                const val = $$(row).find("td").last().text().trim();
                if (key && val) caption += `• ${key}: ${val}\n`;
            });

            caption += `\n`;
        });

        await KazzTzy.sendMessage(
            m.chat,
            { image: { url: image }, caption },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        console.log(e);
        await m.react(global.reactError || "❌");
        m.reply("Error: " + e.message);
    }
};

handler.help = ["gsm <nama hp>"];
handler.tags = ["tools"];
handler.command = /^gsm$/i;
handler.register = true;
handler.limit = true;

export default handler;