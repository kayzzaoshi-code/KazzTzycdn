import axios from "axios";

const API = "https://kayzzidgf.my.id";
export const sessions = {};

let handler = async (m, { KazzTzy, usedPrefix }) => {
  const chat = m.chat;
  if (sessions[chat]) return m.reply("𖣂 Masih ada soal aktif! Jawab dulu atau " + usedPrefix + "stoptebakjkt48");

  await m.react(global.react);

  const res = await axios.get(API + "/api/game/tebakjkt48?apikey=KazzTzy").catch(() => null);
  if (!res?.data?.gambar) return m.reply("𖣂 Gagal ambil soal.");

  sessions[chat] = {
    jawaban: String(res.data.jawaban).toLowerCase(),
    timeout: setTimeout(() => {
      delete sessions[chat];
      KazzTzy.sendMessage(chat, { text: "𖣂 Waktu habis! Jawaban: *" + res.data.jawaban + "*" });
    }, 60000)
  };

  await KazzTzy.sendMessage(chat, {
    image: { url: res.data.gambar },
    caption: "╔══[ TEBAKJKT48 ]══╗\n\n𖣂 Siapa member JKT48 ini?\n\n𖣂 Waktu: 60 detik\n𖣂 Hadiah: +3 Limit, +300 Uang, +70 EXP\n╚══════════════════╝"
  }, { quoted: m });

  await m.react(global.reactSuccess);
};

handler.help = ["tebakjkt48"];
handler.tags = ["game"];
handler.command = /^tebakjkt48$/i;
handler.register = true;
export default handler;
