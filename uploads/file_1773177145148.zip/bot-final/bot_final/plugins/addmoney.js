let handler = async (m, { text }) => {
    let moneyValue = parseInt(text) || 0;

    Object.keys(global.db.data.users).forEach(jid => {
        let user = global.db.data.users[jid];
        if (!user.money) user.money = 0;
        user.money += moneyValue;
    });

    m.reply(`✅ Berhasil menambahkan ${moneyValue} money ke semua user`);
};

handler.help = ['addmoney <jumlah>'];
handler.tags = ['owner'];
handler.command = /^(addmoney)$/i;
handler.rowner = true;

export default handler;