import fetch from 'node-fetch';

const API_URL = 'https://kayzzidgf.my.id';

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Penggunaan:\n${usedPrefix + command} <NamaKey>\n\nContoh:\n${usedPrefix + command} KazzTzy`;

  const key = text.trim();

  let res = await fetch(`${API_URL}/api/apikey/check?key=${encodeURIComponent(key)}`);
  let d = await res.json();

  if (!d.success) throw `${d.message}`;

  const pct = Math.round((d.used / d.limit_total) * 100);
  const bar = '█'.repeat(Math.round(pct / 10)) + '░'.repeat(10 - Math.round(pct / 10));

  m.reply(
    `CEK API KEY\n\n` +
    `Key: ${d.key}\n\n` +
    `Limit Total: ${d.limit_total}\n` +
    `Terpakai: ${d.used}\n` +
    `Sisa: ${d.remaining}\n\n` +
    `${bar} ${pct}%\n\n` +
    `${d.is_valid ? 'Status: AKTIF' : 'Status: LIMIT HABIS'}`
  );
};

handler.help = ['cekkey <NamaKey>'];
handler.tags = ['tools'];
handler.command = /^cekkey$/i;

export default handler;