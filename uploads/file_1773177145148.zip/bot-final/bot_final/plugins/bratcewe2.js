import { createCanvas, loadImage } from "canvas";
import { Sticker, StickerTypes } from "wa-sticker-formatter";

let DikaHistory = {};

let handler = async (m, { text, usedPrefix, command }) => {
    const input = m.quoted ? (m.quoted.text || m.quoted.caption) : text;
    if (!input) return m.reply(`Masukkan teks untuk ditulis di papan.\nContoh: \`${usedPrefix + command} mana dika?\``);

    if (!DikaHistory[m.sender]) DikaHistory[m.sender] = [];

    try {
        await m.react('⏳');

        const bgUrl = "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1772532607645.jpeg";
        const image = await loadImage(bgUrl);
        
        const canvas = createCanvas(image.width, image.height);
        const ctx = canvas.getContext("2d");

        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

        ctx.fillStyle = "#222222";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";

        let fontSize = 85;
        const maxWidth = 550;
        const maxHeight = 280;
        let lines = [];
        
        while (fontSize > 10) {
            ctx.font = `bold ${fontSize}px sans-serif`;
            lines = [];
            let words = input.split(/\s+/);
            let currentLine = words[0];

            for (let i = 1; i < words.length; i++) {
                let width = ctx.measureText(currentLine + " " + words[i]).width;
                if (width < maxWidth) {
                    currentLine += " " + words[i];
                } else {
                    lines.push(currentLine);
                    currentLine = words[i];
                }
            }
            lines.push(currentLine);

            if (lines.length * (fontSize * 1.1) <= maxHeight && ctx.measureText(lines.reduce((a, b) => a.length > b.length ? a : b)).width <= maxWidth) {
                break;
            }
            fontSize -= 2;
        }

        const x = canvas.width / 2 + 10;
        const centerY = 980; 
        const lineHeight = fontSize * 1.1;
        const totalHeight = (lines.length - 1) * lineHeight;
        const startY = -(totalHeight / 2);

        ctx.save();
        ctx.translate(x, centerY); 
        ctx.rotate(0.02);

        lines.forEach((line, index) => {
            ctx.fillText(line, 0, startY + (index * lineHeight));
        });
        
        ctx.restore();

        const buffer = canvas.toBuffer("image/png");

        const sticker = new Sticker(buffer, {
            pack: 'Brat Cewe',
            author: m.pushName || 'Bot',
            type: StickerTypes.FULL,
            categories: ['🤩', '🎉'],
            id: m.sender,
            quality: 70
        });

        const stickerBuffer = await sticker.toBuffer();
        await m.reply(stickerBuffer);

        DikaHistory[m.sender].push({ code: input });

        await m.react('✅');

    } catch (err) {
        await m.react('❌');
        m.reply(`Terjadi kesalahan!\n\n${err.message || err}`);
    }
};

handler.help = ["bratcewe2 <teks>"];
handler.tags = ["maker"];
handler.command = /^(bratcewe2)$/i;
handler.register = true;
handler.limit = true;

export default handler;