import axios from "axios";

const API = "https://kayzzidgf.my.id";
export const sessions = {};

let handler = async (m, { KazzTzy, usedPrefix }) => {
  const chat = m.chat;
  if (sessions[chat]) return m.reply("𖣂 Masih ada soal aktif! Jawab dulu atau " + usedPrefix + "stopfamily100");

  await m.react(global.react);

  const res = await axios.get(API + "/api/game/family100?apikey=KazzTzy").catch(() => null);
  if (!res?.data?.soal) return m.reply("𖣂 Gagal ambil soal.");

  const jawabanList = Array.isArray(res.data.jawaban) ? res.data.jawaban.map(j => j.toLowerCase()) : [String(res.data.jawaban).toLowerCase()];
  const total = jawabanList.length;

  sessions[chat] = {
    jawabanList,
    found: [],
    soal: res.data.soal,
    total,
    timeout: setTimeout(() => {
      const s = sessions[chat];
      if (!s) return;
      delete sessions[chat];
      KazzTzy.sendMessage(chat, {
        text: "𖣂 Waktu habis!\n𖣂 Jawaban: " + s.jawabanList.join(", ")
      });
    }, 120000)
  };

  await KazzTzy.sendMessage(chat, {
    text: "╔══[ FAMILY 100 ]══╗\n\n𖣂 " + res.data.soal + "\n\n𖣂 Cari " + total + " jawaban!\n𖣂 Waktu: 120 detik\n𖣂 Hadiah per jawaban: +2 Limit, +200 Uang, +40 EXP\n╚═══════════════════╝"
  }, { quoted: m });

  await m.react(global.reactSuccess);
};

handler.help = ["family100"];
handler.tags = ["game"];
handler.command = /^family100$/i;
handler.register = true;
export default handler;
