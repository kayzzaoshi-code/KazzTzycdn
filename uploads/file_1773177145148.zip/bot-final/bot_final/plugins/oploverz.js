import axios from "axios";
import * as cheerio from "cheerio";

const BASE = "https://oploverz.ch";

const http = axios.create({
  baseURL: BASE,
  timeout: 20000,
  headers: {
    "User-Agent":
      "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/124.0.0.0 Mobile Safari/537.36",
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    Referer: BASE + "/",
  },
});

const abs = (href) =>
  href?.startsWith("http")
    ? href
    : BASE + (href?.startsWith("/") ? "" : "/") + href;

async function fetchPage(url) {
  const res = await http.get(url);
  return cheerio.load(res.data);
}

function parseCards($) {
  const results = [];
  $("article.bs").each((_, el) => {
    const a = $(el).find("a").first();
    const link = abs(a.attr("href"));
    const title =
      $(el).find("h2").text().trim() ||
      $(el).find("img").attr("alt") ||
      "";
    const eps = $(el).find(".epx").text().trim();
    if (title && link) results.push({ title, link, eps });
  });
  return results;
}

async function searchAnime(q) {
  const $ = await fetchPage(`/?s=${encodeURIComponent(q)}`);
  return parseCards($);
}

async function getLatest() {
  const $ = await fetchPage("/");
  return parseCards($);
}

async function getDetail(url) {
  const $ = await fetchPage(url);
  const title = $("h1").first().text().trim();
  const synopsis = $(".entry-content p").first().text().trim();
  const episodes = [];

  $(".eplister ul li").each((_, li) => {
    const a = $(li).find("a").first();
    episodes.push({
      title: $(li).find(".epl-title").text().trim(),
      link: abs(a.attr("href")),
    });
  });

  return { title, synopsis, episodes };
}

let handler = async (m, { KazzTzy, text, command }) => {
  try {
    await m.react("⏳");

    if (command === "opsearch") {
      if (!text) return m.reply("Contoh: .opsearch naruto");
      const res = await searchAnime(text);
      if (!res.length) return m.reply("Tidak ditemukan.");

      let msg = `🔍 *Hasil Pencarian*\n\n`;
      res.slice(0, 10).forEach((v, i) => {
        msg += `${i + 1}. ${v.title}\n${v.link}\n\n`;
      });

      return m.reply(msg);
    }

    if (command === "oplatest") {
      const res = await getLatest();
      let msg = `🆕 *Episode Terbaru*\n\n`;
      res.slice(0, 10).forEach((v, i) => {
        msg += `${i + 1}. ${v.title} (${v.eps})\n${v.link}\n\n`;
      });
      return m.reply(msg);
    }

    if (command === "opdetail") {
      if (!text) return m.reply("Contoh: .opdetail <url>");
      const d = await getDetail(text);

      let msg = `📺 *${d.title}*\n\n${d.synopsis}\n\n📂 Episode:\n`;
      d.episodes.slice(0, 10).forEach((e) => {
        msg += `- ${e.title}\n${e.link}\n`;
      });

      return m.reply(msg);
    }

    await m.react("✅");
  } catch (e) {
    await m.react("❌");
    m.reply("Error: " + e.message);
  }
};

handler.help = ["opsearch", "oplatest", "opdetail"];
handler.tags = ["anime"];
handler.command = /^(opsearch|oplatest|opdetail)$/i;
handler.limit = true;

export default handler;