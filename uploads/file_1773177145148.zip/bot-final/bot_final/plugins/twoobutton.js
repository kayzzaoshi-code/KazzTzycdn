import { createCanvas, loadImage } from "canvas";

let handler = async (m, { KazzTzy, text }) => {
    if (!text) return m.reply("Format: .twobutton text kiri|text kanan");

    let [left, right] = text.split("|");
    if (!left || !right) return m.reply("Format: .twobutton text kiri|text kanan");

    left = left.trim();
    right = right.trim();

    const bgUrl = "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1771431452923.jpeg";
    const bg = await loadImage(bgUrl);

    const canvas = createCanvas(bg.width, bg.height);
    const ctx = canvas.getContext("2d");

    ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

    function drawWrappedText(text, centerX, startY, maxWidth) {
        let fontSize = 26;
        ctx.font = `bold ${fontSize}px Sans`;

        while (ctx.measureText(text).width > maxWidth && fontSize > 16) {
            fontSize -= 2;
            ctx.font = `bold ${fontSize}px Sans`;
        }

        const words = text.split(" ");
        let lines = [];
        let current = "";

        for (let word of words) {
            let testLine = current + word + " ";
            if (ctx.measureText(testLine).width > maxWidth) {
                lines.push(current.trim());
                current = word + " ";
            } else {
                current = testLine;
            }
        }
        lines.push(current.trim());

        ctx.textAlign = "center";
        ctx.fillStyle = "#000000";

        let lineHeight = fontSize + 4;
        let offset = startY - ((lines.length - 1) * lineHeight) / 2;

        for (let line of lines) {
            ctx.fillText(line, centerX, offset);
            offset += lineHeight;
        }
    }

    drawWrappedText(left, canvas.width * 0.28, canvas.height * 0.095, 340);
    drawWrappedText(right, canvas.width * 0.72, canvas.height * 0.095, 340);

    const result = canvas.toBuffer("image/png");

    await KazzTzy.sendMessage(
        m.chat,
        { image: result },
        { quoted: m }
    );
};

handler.help = ["twobutton <text kiri|text kanan>"];
handler.tags = ["maker"];
handler.command = /^twobutton$/i;
handler.register = true;
handler.limit = true;

export default handler;