
const fmtDur = (ms) => {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}j ${m % 60}m ${s % 60}d`;
  if (m > 0) return `${m}m ${s % 60}d`;
  return `${s}d`;
};

export function before(m) {
  let user = global.db.data.users[m.sender];

  if (user?.afk > -1) {
    const dur = fmtDur(Date.now() - user.afk);
    m.reply(
      "╔══[ KEMBALI AKTIF ]══╗\n" +
      "𖣂 " + (KazzTzy.getName(m.sender) || m.sender.split("@")[0]) + " sudah kembali\n" +
      "𖣂 Durasi AFK : " + dur + "\n" +
      (user.afkReason ? "𖣂 Alasan    : " + user.afkReason + "\n" : "") +
      "╚═════════════════════╝"
    );
    user.afk = -1;
    user.afkReason = "";
  }

  let jids = [...new Set([
    ...(m.mentionedJid || []),
    ...(m.quoted ? [m.quoted.sender] : []),
  ])];

  for (let jid of jids) {
    let u = global.db.data.users[jid];
    if (!u?.afk || u.afk < 0) continue;
    const dur = fmtDur(Date.now() - u.afk);
    m.reply(
      "╔══[ LAGI AFK ]══╗\n" +
      "𖣂 " + (KazzTzy.getName(jid) || jid.split("@")[0]) + " sedang AFK\n" +
      "𖣂 Durasi    : " + dur + "\n" +
      (u.afkReason ? "𖣂 Alasan    : " + u.afkReason + "\n" : "") +
      "╚═════════════════╝"
    );
  }

  return true;
}
