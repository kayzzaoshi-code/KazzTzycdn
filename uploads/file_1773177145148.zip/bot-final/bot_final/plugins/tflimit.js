import { createCanvas } from 'canvas'
import moment from 'moment-timezone'

let handler = async (m, { KazzTzy, args, command }) => {
    let type = command.toLowerCase().includes('limit') ? 'Limit' : 'Money'
    let key = type.toLowerCase()
    let target = m.mentionedJid?.[0] || m.quoted?.sender
    let amount = parseInt(args[1] || args[0])

    if (!target) throw 'Tag atau reply user yang ingin ditransfer'
    if (!amount || amount < 1) throw 'Jumlah tidak valid'

    let sender = global.db.data.users[m.sender]
    let receiver = global.db.data.users[target]
    if (!sender || !receiver) throw 'User tidak ditemukan'

    let adminFee = Math.floor(Math.random() * 10) + 1
    let tax = Math.floor(amount * 0.02)
    let totalCut = amount + adminFee + tax

    if ((sender[key] || 0) < totalCut) throw `${type} tidak cukup`

    let beforeSender = sender[key] || 0
    let beforeReceiver = receiver[key] || 0

    sender[key] -= totalCut
    receiver[key] = (receiver[key] || 0) + amount

    let afterSender = sender[key]
    let afterReceiver = receiver[key]

    let pushNameSender = m.pushName || m.sender.split('@')[0]
    let pushNameReceiver =
        receiver.name ||
        (await KazzTzy.getName(target)) ||
        target.split('@')[0]

    const width = 900
    const height = 1500
    const canvas = createCanvas(width, height)
    const ctx = canvas.getContext('2d')

    ctx.fillStyle = '#ffffff'
    ctx.fillRect(0, 0, width, height)

    ctx.fillStyle = '#1565C0'
    ctx.fillRect(0, 0, width, 220)

    ctx.fillStyle = '#ffffff'
    ctx.font = 'bold 44px Sans'
    ctx.textAlign = 'center'
    ctx.fillText('DETAIL TRANSAKSI', width / 2, 130)

    ctx.fillStyle = '#4CAF50'
    ctx.beginPath()
    ctx.arc(width / 2, 260, 65, 0, Math.PI * 2)
    ctx.fill()

    ctx.fillStyle = '#ffffff'
    ctx.font = 'bold 70px Sans'
    ctx.fillText('✓', width / 2, 285)

    ctx.fillStyle = '#000'
    ctx.font = 'bold 40px Sans'
    ctx.textAlign = 'center'
    ctx.fillText('Transaksi Berhasil', width / 2, 360)

    ctx.textAlign = 'left'
    let y = 450
    let leftX = 80
    let rightX = width - 80
    let waktu = moment().tz('Asia/Jakarta').format('DD MMM YYYY • HH:mm:ss')

    const row = (label, value, bold = false, color = '#000') => {
        ctx.fillStyle = '#666'
        ctx.font = '26px Sans'
        ctx.textAlign = 'left'
        ctx.fillText(label, leftX, y)

        ctx.textAlign = 'right'
        ctx.fillStyle = color
        ctx.font = bold ? 'bold 28px Sans' : '26px Sans'
        ctx.fillText(value, rightX, y)

        y += 55
    }

    row('Tanggal', waktu)
    row('Jenis', 'Transfer ' + type)

    y += 20
    ctx.strokeStyle = '#e0e0e0'
    ctx.beginPath()
    ctx.moveTo(leftX, y)
    ctx.lineTo(rightX, y)
    ctx.stroke()

    y += 70
    row('Nama Pengirim', pushNameSender)
    row('Nomor Pengirim', m.sender.split('@')[0])

    y += 30
    row('Nama Penerima', pushNameReceiver)
    row('Nomor Penerima', target.split('@')[0])

    y += 30
    ctx.strokeStyle = '#e0e0e0'
    ctx.beginPath()
    ctx.moveTo(leftX, y)
    ctx.lineTo(rightX, y)
    ctx.stroke()

    y += 70
    row('Nominal', amount + ' ' + type, true)
    row('Biaya Admin', adminFee + ' ' + type)
    row('Pajak (2%)', tax + ' ' + type)

    y += 30
    ctx.strokeStyle = '#e0e0e0'
    ctx.beginPath()
    ctx.moveTo(leftX, y)
    ctx.lineTo(rightX, y)
    ctx.stroke()

    y += 70
    row('Saldo Pengirim Sebelum', beforeSender + ' ' + type)
    row('Saldo Pengirim Sesudah', afterSender + ' ' + type)

    y += 30
    row('Saldo Penerima Sebelum', beforeReceiver + ' ' + type)
    row('Saldo Penerima Sesudah', afterReceiver + ' ' + type)

    const buffer = canvas.toBuffer('image/png')

    await KazzTzy.sendMessage(m.chat, {
        image: buffer,
        mentions: [m.sender, target]
    }, { quoted: m })
}

handler.help = ['tflimit @user jumlah','tfmoney @user jumlah']
handler.tags = ['rpg']
handler.command = /^(tflimit|tfmoney)$/i
handler.register = true

export default handler