let handler = async (m, { KazzTzy, text, args, isOwner }) => {
  if (!isOwner) return;

  if (!text) {
    return m.reply(
      "╔══[ QUIT GC ]══╗\n" +
      "𖣂 Keluar dari grup\n\n" +
      "Format:\n" +
      ".qutgc <link/jid>\n\n" +
      "Contoh:\n" +
      ".qutgc https://chat.whatsapp.com/xxx\n" +
      ".qutgc 120363xxx@g.us\n" +
      "╚════════════════╝"
    );
  }

  const input = text.trim();
  await m.react("⏳");

  let groupJid = null;
  let groupName = null;

  if (input.includes("chat.whatsapp.com")) {
    try {
      const code = input.split("/").pop().split("?")[0];
      const info = await KazzTzy.groupGetInviteInfo(code);
      groupJid = info.id;
      groupName = info.subject;
    } catch (e) {
      return m.reply("𖣂 Gagal ambil info grup dari link: " + e.message);
    }
  } else if (input.includes("@g.us")) {
    groupJid = input;
    try {
      const meta = await KazzTzy.groupMetadata(groupJid);
      groupName = meta.subject;
    } catch {
      groupName = groupJid;
    }
  } else {
    return m.reply("𖣂 Input tidak valid. Masukkan link grup atau JID (@g.us).");
  }

  try {
    await KazzTzy.groupLeave(groupJid);
    await m.react("✅");
    await KazzTzy.sendMessage(m.chat, {
      text: [
        "╔══[ KELUAR GRUP ]══╗",
        "",
        "𖣂 Berhasil keluar dari:",
        "𖣂 " + (groupName || groupJid),
        "𖣂 " + groupJid,
        "",
        "╚════════════════════╝"
      ].join("\n")
    }, { quoted: m });
  } catch (e) {
    await m.react("❌");
    m.reply("𖣂 Gagal keluar dari grup: " + e.message);
  }
};

handler.help = ["qutgc <link/jid>"];
handler.tags = ["owner"];
handler.command = /^qutgc$/i;
handler.owner = true;

export default handler;
