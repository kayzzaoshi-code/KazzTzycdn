import axios from "axios";
import { createCanvas, loadImage } from "canvas";
import { Sticker, StickerTypes } from "wa-sticker-formatter";

let handler = async (m, { text, usedPrefix, command }) => {
    const input = m.quoted ? m.quoted.text : text;
    if (!input) return m.reply(`Masukkan teks! Contoh: ${usedPrefix + command} pelit banget`);

    try {
        await m.react("⏳");

        const bgUrl = "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1771830553541.jpeg";
        const resImg = await axios.get(bgUrl, { responseType: "arraybuffer" });
        const background = await loadImage(Buffer.from(resImg.data));

        const canvas = createCanvas(background.width, background.height);
        const ctx = canvas.getContext("2d");
        ctx.drawImage(background, 0, 0);

        const maxWidth = 820;
        const maxHeight = 500;

        const centerX = canvas.width / 2 - 500;
        const centerY = canvas.height * 0.73;

        let fontSize = 230;
        const minFontSize = 120;

        const wrapLines = (size) => {
            ctx.font = `bold ${size}px sans-serif`;
            const words = input.split(" ");
            let lines = [];
            let line = "";

            for (let word of words) {
                let testLine = line ? line + " " + word : word;
                if (ctx.measureText(testLine).width > maxWidth && line) {
                    lines.push(line);
                    line = word;
                } else {
                    line = testLine;
                }
            }

            if (line) lines.push(line);
            return lines;
        };

        let lines = wrapLines(fontSize);

        while (fontSize > minFontSize) {
            ctx.font = `bold ${fontSize}px sans-serif`;
            lines = wrapLines(fontSize);

            const lineHeight = fontSize * 1.25;
            const totalHeight = lines.length * lineHeight;
            const widest = Math.max(...lines.map(l => ctx.measureText(l).width));

            if (widest <= maxWidth && totalHeight <= maxHeight) break;

            fontSize -= 5;
        }

        ctx.fillStyle = "#000000";
        ctx.textAlign = "left";
        ctx.textBaseline = "middle";
        ctx.font = `bold ${fontSize}px sans-serif`;

        const lineHeight = fontSize * 1.25;
        const totalHeight = lines.length * lineHeight;
        let startY = centerY - totalHeight / 2 + fontSize / 2;

        for (let i = 0; i < lines.length; i++) {
            ctx.fillText(lines[i], centerX, startY + i * lineHeight);
        }

        const buffer = canvas.toBuffer();
        const sticker = new Sticker(buffer, {
            pack: "Miku Brat",
            author: "Bot Sticker",
            type: StickerTypes.CROPPED,
            quality: 100
        });

        const webp = await sticker.toBuffer();
        await m.reply(webp, null, { mimetype: "image/webp", sticker: true });
        await m.react("✅");

    } catch (err) {
        await m.react("❌");
        m.reply(err.message);
    }
};

handler.help = ["bratmiku <teks>"];
handler.tags = ["sticker"];
handler.command = /^(bratmiku)$/i;
handler.limit = true;

export default handler;