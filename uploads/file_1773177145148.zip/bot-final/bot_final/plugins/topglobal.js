import { createCanvas, loadImage } from 'canvas'
import axios from 'axios'
import fs from 'fs'

const totalChatFile = './data/totalchat.json'

const readTotalChat = () => {
    try {
        if (!fs.existsSync(totalChatFile)) return {}
        const content = fs.readFileSync(totalChatFile, 'utf8').trim()
        return content ? JSON.parse(content) : {}
    } catch {
        return {}
    }
}

const CARD_HEIGHT = 110
const CARD_GAP = 12
const PADDING_X = 30
const HEADER_H = 140
const FOOTER_H = 80

const getSegments = (str) => {
    const segments = []
    let lastIdx = 0
    let match
    const re = /(\p{Emoji_Presentation}|\p{Emoji}\uFE0F)/gu
    while ((match = re.exec(str)) !== null) {
        if (match.index > lastIdx) segments.push({ type: 'text', content: str.slice(lastIdx, match.index) })
        segments.push({ type: 'emoji', content: match[0] })
        lastIdx = re.lastIndex
    }
    if (lastIdx < str.length) segments.push({ type: 'text', content: str.slice(lastIdx) })
    return segments
}

const emojiCache = {}

const loadEmoji = async (emoji) => {
    if (emojiCache[emoji]) return emojiCache[emoji]
    try {
        const codePoint = Array.from(emoji)
            .map(c => c.codePointAt(0).toString(16))
            .filter(cp => cp !== 'fe0f')
            .join('-')
        const url = `https://cdn.jsdelivr.net/gh/twitter/twemoji@latest/assets/72x72/${codePoint}.png`
        const r = await axios.get(url, { responseType: 'arraybuffer' })
        const img = await loadImage(Buffer.from(r.data))
        emojiCache[emoji] = img
        return img
    } catch {
        return null
    }
}

const preloadEmojisInText = async (text) => {
    const segments = getSegments(text)
    const uniqueEmojis = [...new Set(segments.filter(s => s.type === 'emoji').map(s => s.content))]
    await Promise.all(uniqueEmojis.map(e => loadEmoji(e)))
}

const measureText = (ctx, segments, fontSize) => {
    ctx.font = `bold ${fontSize}px "Segoe UI Semibold", sans-serif`
    let total = 0
    for (const seg of segments) {
        if (seg.type === 'text') total += ctx.measureText(seg.content).width
        else total += fontSize * 1.15
    }
    return total
}

const drawTextWithEmoji = async (ctx, text, x, y, fontSize, color, align = 'left') => {
    const segments = getSegments(text)
    const totalWidth = measureText(ctx, segments, fontSize)

    let currentX = x
    if (align === 'center') currentX = x - totalWidth / 2
    else if (align === 'right') currentX = x - totalWidth

    ctx.textBaseline = 'middle'

    for (const seg of segments) {
        if (seg.type === 'text') {
            ctx.font = `bold ${fontSize}px "Segoe UI Semibold", sans-serif`
            ctx.fillStyle = color
            ctx.textAlign = 'left'
            ctx.fillText(seg.content, currentX, y)
            currentX += ctx.measureText(seg.content).width
        } else {
            const img = await loadEmoji(seg.content)
            const size = fontSize * 1.15
            if (img) {
                ctx.drawImage(img, currentX, y - size / 2, size, size)
            } else {
                ctx.font = `bold ${fontSize}px sans-serif`
                ctx.fillStyle = color
                ctx.textAlign = 'left'
                ctx.fillText(seg.content, currentX, y)
            }
            currentX += size
        }
    }
}

const drawPlainText = (ctx, text, x, y, fontSize, color, fontWeight = 'normal', align = 'left') => {
    ctx.font = `${fontWeight} ${fontSize}px "Segoe UI", sans-serif`
    ctx.fillStyle = color
    ctx.textAlign = align
    ctx.textBaseline = 'middle'
    ctx.fillText(text, x, y)
    ctx.textAlign = 'left'
}

const drawRoundRect = (ctx, x, y, w, h, r) => {
    ctx.beginPath()
    ctx.moveTo(x + r, y)
    ctx.lineTo(x + w - r, y)
    ctx.quadraticCurveTo(x + w, y, x + w, y + r)
    ctx.lineTo(x + w, y + h - r)
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h)
    ctx.lineTo(x + r, y + h)
    ctx.quadraticCurveTo(x, y + h, x, y + h - r)
    ctx.lineTo(x, y + r)
    ctx.quadraticCurveTo(x, y, x + r, y)
    ctx.closePath()
}

const clipCircle = (ctx, x, y, r) => {
    ctx.beginPath()
    ctx.arc(x, y, r, 0, Math.PI * 2)
    ctx.closePath()
    ctx.clip()
}

const getRankColor = (rank) => {
    if (rank === 1) return { bg: '#2a2010', border: '#f0c040', accent: '#ffd700' }
    if (rank === 2) return { bg: '#1a1f2a', border: '#8ab4d4', accent: '#a8c8e8' }
    if (rank === 3) return { bg: '#1f1a18', border: '#c87840', accent: '#e09060' }
    return { bg: '#161820', border: '#3a3d50', accent: '#8890b0' }
}

const drawDiamondBadge = (ctx, cx, cy, size, rank, colors) => {
    ctx.save()
    ctx.translate(cx, cy)
    ctx.rotate(Math.PI / 4)
    ctx.fillStyle = colors.bg
    ctx.strokeStyle = colors.border
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.rect(-size / 2, -size / 2, size, size)
    ctx.fill()
    ctx.stroke()
    ctx.restore()

    ctx.fillStyle = colors.accent
    ctx.font = `bold ${size * 0.55}px "Segoe UI", sans-serif`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText(rank, cx, cy + 1)
    ctx.textAlign = 'left'
    ctx.textBaseline = 'alphabetic'
}

let handler = async (m, { KazzTzy }) => {
    try {
        await KazzTzy.sendMessage(m.chat, { react: { text: '🕐', key: m.key } })

        const totalChatData = readTotalChat()
        const chatCounts = totalChatData[m.chat]?.users || {}

        const usersData = Object.entries(global.db.data.users)
            .filter(([jid, u]) => u.registered)
            .map(([jid, u]) => ({ jid, ...u }))
            .sort((a, b) => (b.money + b.limit + b.level + b.exp) - (a.money + a.limit + a.level + a.exp))
            .slice(0, 10)

        if (!usersData.length) return m.reply('Data user masih kosong.')

        await Promise.all(
            usersData.map(u => preloadEmojisInText(u.name || ''))
        )
        await preloadEmojisInText('⚔ 💰 ⚡ ✨ 💬 🏆')

        const width = 900
        const height = HEADER_H + usersData.length * (CARD_HEIGHT + CARD_GAP) + FOOTER_H
        const canvas = createCanvas(width, height)
        const ctx = canvas.getContext('2d')

        const bgGrad = ctx.createLinearGradient(0, 0, 0, height)
        bgGrad.addColorStop(0, '#0d0e14')
        bgGrad.addColorStop(0.5, '#111318')
        bgGrad.addColorStop(1, '#0a0b10')
        ctx.fillStyle = bgGrad
        ctx.fillRect(0, 0, width, height)

        for (let i = 0; i < 60; i++) {
            const x = Math.random() * width
            const y = Math.random() * height
            const r = Math.random() * 1.2 + 0.3
            const a = Math.random() * 0.6 + 0.1
            ctx.fillStyle = `rgba(200, 210, 255, ${a})`
            ctx.beginPath()
            ctx.arc(x, y, r, 0, Math.PI * 2)
            ctx.fill()
        }

        ctx.strokeStyle = 'rgba(180, 150, 60, 0.3)'
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(PADDING_X, HEADER_H - 2)
        ctx.lineTo(width - PADDING_X, HEADER_H - 2)
        ctx.stroke()

        await drawTextWithEmoji(ctx, '⚔  Top Global Users', PADDING_X + 10, 65, 34, '#f0c040')
        drawPlainText(ctx, 'Global Ranking  •  Z4Z Community', PADDING_X + 12, 105, 18, 'rgba(180,190,220,0.7)', 'normal')

        ctx.fillStyle = 'rgba(255,215,0,0.06)'
        ctx.font = 'bold 90px sans-serif'
        ctx.textAlign = 'right'
        ctx.textBaseline = 'alphabetic'
        ctx.fillText('RANK', width - PADDING_X, 125)
        ctx.textAlign = 'left'

        for (let i = 0; i < usersData.length; i++) {
            const user = usersData[i]
            const rank = i + 1
            const colors = getRankColor(rank)
            const cardY = HEADER_H + i * (CARD_HEIGHT + CARD_GAP)
            const cardW = width - PADDING_X * 2
            const cardX = PADDING_X

            const cardGrad = ctx.createLinearGradient(cardX, cardY, cardX + cardW, cardY)
            cardGrad.addColorStop(0, colors.bg)
            cardGrad.addColorStop(0.6, '#12141c')
            cardGrad.addColorStop(1, '#0e1018')

            ctx.save()
            drawRoundRect(ctx, cardX, cardY, cardW, CARD_HEIGHT, 10)
            ctx.fillStyle = cardGrad
            ctx.fill()
            ctx.strokeStyle = colors.border
            ctx.lineWidth = rank <= 3 ? 1.5 : 0.8
            ctx.stroke()
            ctx.restore()

            if (rank <= 3) {
                ctx.save()
                drawRoundRect(ctx, cardX, cardY, cardW, CARD_HEIGHT, 10)
                ctx.clip()
                const shimmer = ctx.createLinearGradient(cardX, cardY, cardX + cardW, cardY + CARD_HEIGHT)
                shimmer.addColorStop(0, `${colors.accent}08`)
                shimmer.addColorStop(0.5, `${colors.accent}15`)
                shimmer.addColorStop(1, `${colors.accent}05`)
                ctx.fillStyle = shimmer
                ctx.fillRect(cardX, cardY, cardW, CARD_HEIGHT)
                ctx.restore()
            }

            const badgeCX = cardX + 48
            const badgeCY = cardY + CARD_HEIGHT / 2
            drawDiamondBadge(ctx, badgeCX, badgeCY, 44, rank, colors)

            let pp
            try {
                pp = await KazzTzy.profilePictureUrl(user.jid, 'image', 'buffer')
            } catch {
                pp = global.thumbnail
            }

            const avatarX = cardX + 110
            const avatarY = cardY + CARD_HEIGHT / 2
            const avatarR = 38

            ctx.save()
            ctx.beginPath()
            ctx.arc(avatarX, avatarY, avatarR + 3, 0, Math.PI * 2)
            ctx.strokeStyle = colors.border
            ctx.lineWidth = 2
            ctx.stroke()
            ctx.restore()

            try {
                const img = await loadImage(pp)
                ctx.save()
                clipCircle(ctx, avatarX, avatarY, avatarR)
                ctx.drawImage(img, avatarX - avatarR, avatarY - avatarR, avatarR * 2, avatarR * 2)
                ctx.restore()
            } catch {
                ctx.save()
                ctx.beginPath()
                ctx.arc(avatarX, avatarY, avatarR, 0, Math.PI * 2)
                ctx.fillStyle = '#2a2d3e'
                ctx.fill()
                ctx.restore()
            }

            const textX = cardX + 165
            const nameY = cardY + 35

            const displayName = user.name || user.jid.split('@')[0]
            await drawTextWithEmoji(ctx, displayName, textX, nameY, 22, rank <= 3 ? colors.accent : '#d0d8f0')

            drawPlainText(ctx, `Level ${user.level || 1}`, textX, nameY + 26, 15, 'rgba(180,190,220,0.6)', 'normal')

            const statY = cardY + CARD_HEIGHT - 20
            await drawTextWithEmoji(ctx, `💰 ${(user.money || 0).toLocaleString()}`, textX, statY, 14, '#7888aa')
            await drawTextWithEmoji(ctx, `⚡ ${user.limit || 0}`, textX + 150, statY, 14, '#7888aa')
            await drawTextWithEmoji(ctx, `✨ ${user.exp || 0}`, textX + 240, statY, 14, '#7888aa')

            const score = (user.money || 0) + (user.limit || 0) + (user.level || 1) + (user.exp || 0)
            const totalChat = chatCounts[user.jid] || 0
            const scoreX = cardX + cardW - 20

            drawPlainText(ctx, 'Exercise Points', scoreX, cardY + 28, 13, 'rgba(150,160,190,0.5)', 'normal', 'right')
            drawPlainText(ctx, score.toLocaleString(), scoreX, cardY + 62, 32, colors.accent, 'bold', 'right')
            await drawTextWithEmoji(ctx, `💬 ${totalChat}`, scoreX, cardY + 90, 14, 'rgba(0,220,255,0.7)', 'right')
        }

        const footerY = height - FOOTER_H + 20
        ctx.strokeStyle = 'rgba(180, 150, 60, 0.2)'
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(PADDING_X, footerY - 10)
        ctx.lineTo(width - PADDING_X, footerY - 10)
        ctx.stroke()

        drawPlainText(ctx, 'Leaderboard refresh may have a slight delay', width / 2, footerY + 15, 15, 'rgba(120,130,160,0.5)', 'normal', 'center')
        drawPlainText(ctx, `Total Registered: ${Object.values(global.db.data.users).filter(u => u.registered).length} users`, width / 2, footerY + 38, 15, 'rgba(120,130,160,0.5)', 'normal', 'center')

        const buffer = canvas.toBuffer('image/png')
        await KazzTzy.sendMessage(m.chat, { image: buffer, caption: '🏆 *Top Global Users*\n_Z4Z Community Leaderboard_' })
    } catch (e) {
        console.error(e)
        await KazzTzy.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        m.reply('Gagal membuat Top Global: ' + e.message)
    }
}

handler.help = ['topglobal']
handler.tags = ['info']
handler.command = /^(topglobal|topuser)$/i

export default handler