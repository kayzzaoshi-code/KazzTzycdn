import axios from "axios";

let handler = async (m, { KazzTzy }) => {
    try {
        await m.react(global.react || "⏳");

        const res = await axios.get("https://api.deline.web.id/berita/antara");
        const data = res.data;

        if (!data || !data.data || !data.data.length)
            return m.reply("❌ Tidak ada berita.");

        let teks = `📰 *Berita ANTARA Terbaru*\n\n`;

        data.data.slice(0, 10).forEach((v, i) => {
            teks += `*${i+1}. ${v.title}*\n`;
            teks += `${v.link}\n\n`;
        });

        await KazzTzy.sendMessage(m.chat, { text: teks.trim() }, { quoted: m });
        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e?.response?.data || e.message || e));
    }
};

handler.help = ["beritaantara"];
handler.tags = ["random"];
handler.command = /^(beritaantara|antara|berita-antara)$/i;
handler.register = true;
handler.limit = true;

export default handler;