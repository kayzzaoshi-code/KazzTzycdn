import axios from 'axios';
const GH_TOKEN = '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';
const GH_OWNER = 'kayzzaoshi-code';
const GH_REPO = 'Uploader';
async function createRepo() {
  try { await axios.post('https://api.github.com/user/repos', { name: GH_REPO, private: false }, { headers: { Authorization: `token ${GH_TOKEN}` } }); } catch {}
}
async function uploadToGitHub(buffer, mimetype = 'application/octet-stream') {
  await createRepo();
  const ext = mimetype.split('/')[1] || 'bin';
  const filename = `file_${Date.now()}.${ext}`;
  const res = await axios.put(`https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${filename}`, { message: `Upload ${filename}`, content: Buffer.from(buffer).toString('base64') }, { headers: { Authorization: `token ${GH_TOKEN}` } });
  return res.data.content.download_url;
}

let handler = async (m, { text }) => {
  try {
    await m.react(global.react || "⏳");

    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype;
    if (!mime) return m.reply("❌ Reply gambar yang mau diedit.");
    if (!/image/.test(mime)) return m.reply("❌ File harus berupa gambar.");

    const buffer = await q.download();
    const uploadedUrl = await uploadToGitHub(buffer, mime);
    if (!uploadedUrl) return m.reply("❌ Gagal upload gambar.");

    const prompt = text?.trim();
    if (!prompt) return m.reply("❌ Masukkan prompt.\nContoh:\n.editfoto ubah jadi hitam");

    const response = await axios.get("https://api-faa.my.id/faa/editfoto", {
      params: {
        url: uploadedUrl,
        prompt
      },
      responseType: "arraybuffer"
    });

    const imageBuffer = Buffer.from(response.data, "binary");

    await m.reply(imageBuffer, null, {
      mimetype: "image/jpeg",
      caption: `🖼 Edit Foto AI\nPrompt: "${prompt}"`
    });

    await m.react(global.reactSuccess || "✅");

  } catch (err) {
    await m.react(global.reactError || "❌");
    m.reply(`❌ Terjadi kesalahan: ${err.response?.data || err.message || err}`);
  }
};

handler.help = ["editfoto <prompt>"];
handler.tags = ["ai"];
handler.command = /^editfoto$/i;
handler.register = true;
handler.limit = false;

export default handler;
