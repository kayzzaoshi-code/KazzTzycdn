import moment from 'moment-timezone';

const jobs = [
    { name: 'Pedagang', hourStart: 9, hourEnd: 17, money: [1000, 1500], exp: [10,15], limit: [1,2], challenge: 'Menjual Barang' },
    { name: 'Petani', hourStart: 6, hourEnd: 14, money: [1200, 1800], exp: [8,12], limit: [1,2], challenge: 'Memanen Tanaman' },
    { name: 'Penjahit', hourStart: 10, hourEnd: 18, money: [1300, 1700], exp: [9,14], limit: [1,2], challenge: 'Menjahit Pakaian' },
    { name: 'Tukang Bangunan', hourStart: 8, hourEnd: 16, money: [1500, 2000], exp: [12,18], limit: [2,3], challenge: 'Membangun Rumah' },
    { name: 'Driver', hourStart: 7, hourEnd: 15, money: [1100, 1600], exp: [10,15], limit: [1,2], challenge: 'Mengantar Penumpang' },
    { name: 'Guru', hourStart: 8, hourEnd: 16, money: [1400, 1800], exp: [11,16], limit: [1,2], challenge: 'Mengajar Murid' },
    { name: 'Dokter', hourStart: 9, hourEnd: 17, money: [2000, 2500], exp: [15,20], limit: [2,3], challenge: 'Menyembuhkan Pasien' },
    { name: 'Programmer', hourStart: 10, hourEnd: 18, money: [2200, 2800], exp: [18,25], limit: [2,3], challenge: 'Membuat Program' },
    { name: 'Polisi', hourStart: 6, hourEnd: 14, money: [1800, 2200], exp: [14,18], limit: [2,3], challenge: 'Patroli Kejahatan' },
    { name: 'Supir Taxi', hourStart: 7, hourEnd: 15, money: [1200, 1700], exp: [12,16], limit: [1,2], challenge: 'Mengantar Penumpang' }
];

let kerjaCooldown = {};

let handler = {};

handler.lamarkerja = async (m) => {
    let user = global.db.data.users[m.sender];
    if (!user.registered) return m.reply('Kamu belum registrasi! Gunakan .daftar <nama>.<umur>');
    if (user.job) return m.reply(`Kamu sudah bekerja sebagai ${user.job.name}`);

    let list = jobs.map((j, i) => `${i+1}. ${j.name}`).join('\n');
    m.reply(`Pilih pekerjaan dengan mengetik nomor:\n${list}`);
};

handler.pilihkerja = async (m, { text }) => {
    let user = global.db.data.users[m.sender];
    if (!user.registered) return m.reply('Kamu belum registrasi!');
    if (user.job) return m.reply(`Kamu sudah bekerja sebagai ${user.job.name}`);
    let index = parseInt(text) - 1;
    if (!jobs[index]) return m.reply('Nomor pekerjaan tidak valid');

    user.job = jobs[index];
    user.lastKerja = 0;
    m.reply(`✅ Kamu diterima sebagai ${user.job.name}.\nJam kerja: ${user.job.hourStart}:00 - ${user.job.hourEnd}:00`);
};

handler.bekerja = async (m) => {
    let user = global.db.data.users[m.sender];
    if (!user.registered) return m.reply('Kamu belum registrasi!');
    if (!user.job) return m.reply('Kamu belum melamar pekerjaan. Gunakan .lamarkerja');

    let now = moment().tz('Asia/Jakarta');
    let currentHour = now.hour();

    if (currentHour < user.job.hourStart || currentHour >= user.job.hourEnd) {
        m.reply(`Belum waktunya bekerja.\nJam kerja ${user.job.hourStart}:00 - ${user.job.hourEnd}:00`);
        return;
    }

    if (!kerjaCooldown[m.sender]) kerjaCooldown[m.sender] = 0;
    let diff = now.unix() - kerjaCooldown[m.sender];
    if (diff < 120) return m.reply(`Tunggu ${120 - diff} detik lagi untuk bekerja kembali`);

    kerjaCooldown[m.sender] = now.unix();

    let money = Math.floor(Math.random() * (user.job.money[1]-user.job.money[0]+1)) + user.job.money[0];
    let limit = Math.floor(Math.random() * (user.job.limit[1]-user.job.limit[0]+1)) + user.job.limit[0];
    let exp = Math.floor(Math.random() * (user.job.exp[1]-user.job.exp[0]+1)) + user.job.exp[0];

    user.money = (user.money || 0) + money;
    user.limit = (user.limit || 0) + limit;
    user.exp = (user.exp || 0) + exp;

    m.reply(`✅ Kamu bekerja sebagai ${user.job.name} - Tantangan: ${user.job.challenge}
💹 Money: +${money}
✨ Limit: +${limit}
⚡ Exp: +${exp}`);
};

handler.help = ['lamarkerja', 'bekerja'];
handler.tags = ['rpg'];
handler.command = /^(lamarkerja|bekerja)$/i;

export default handler;