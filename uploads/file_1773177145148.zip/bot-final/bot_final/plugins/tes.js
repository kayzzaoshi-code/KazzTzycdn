import { createCanvas, loadImage } from "canvas";
import { Sticker } from "wa-sticker-formatter";

const wrapText = (context, text, maxWidth) => {
    const words = text.split(" ");
    const lines = [];
    let currentLine = words[0];

    for (let i = 1; i < words.length; i++) {
        const word = words[i];
        const width = context.measureText(currentLine + " " + word).width;

        if (width < maxWidth) {
            currentLine += " " + word;
        } else {
            lines.push(currentLine);
            currentLine = word;
        }
    }

    lines.push(currentLine);
    return lines;
};

let handler = async (m, { KazzTzy, text }) => {
    try {
        if (!text) return m.reply("Masukkan teks");

        await KazzTzy.sendMessage(m.chat, {
            react: { text: "💫", key: m.key }
        });

        const bgUrl = "https://c.termai.cc/i172/LpJ.jpeg";
        const image = await loadImage(bgUrl);

        const canvas = createCanvas(image.width, image.height);
        const ctx = canvas.getContext("2d");

        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

        const centerX = 370;
        const centerY = 370;
        const maxWidth = 230;
        const maxHeight = 110;

        let fontSize = 50;

        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle = "#000000";

        let lines = [];

        do {
            ctx.font = `bold ${fontSize}px Sans`;
            lines = wrapText(ctx, text, maxWidth);

            const totalHeight = lines.length * (fontSize * 1.2);
            let exceedsWidth = false;

            for (const line of lines) {
                if (ctx.measureText(line).width > maxWidth) {
                    exceedsWidth = true;
                    break;
                }
            }

            if (totalHeight <= maxHeight && !exceedsWidth) break;

            fontSize--;
        } while (fontSize > 10);

        const lineHeight = fontSize * 1.1;
        const totalHeight = lines.length * lineHeight;
        let startY = centerY - totalHeight / 2 + lineHeight / 2;

        for (const line of lines) {
            ctx.fillText(line, centerX, startY);
            startY += lineHeight;
        }

        const buffer = canvas.toBuffer("image/png");

        const sticker = new Sticker(buffer, {
            pack: "KazzTzy",
            author: "Brat Squidward",
            type: "full"
        });

        await KazzTzy.sendMessage(
            m.chat,
            { sticker: await sticker.toBuffer() },
            { quoted: m }
        );

    } catch (e) {
        m.reply(String(e.message || e));
    }
};

handler.help = ["bratsquidward <teks>"];
handler.tags = ["sticker"];
handler.command = /^(bratsquidward2|squidward)$/i;
handler.limit = true;

export default handler;