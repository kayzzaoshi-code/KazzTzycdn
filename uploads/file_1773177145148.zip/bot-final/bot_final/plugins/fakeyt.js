import axios from 'axios';
const GH_TOKEN = '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';
const GH_OWNER = 'kayzzaoshi-code';
const GH_REPO = 'Uploader';
async function createRepo() {
  try { await axios.post('https://api.github.com/user/repos', { name: GH_REPO, private: false }, { headers: { Authorization: `token ${GH_TOKEN}` } }); } catch {}
}
async function uploadToGitHub(buffer, mimetype = 'application/octet-stream') {
  await createRepo();
  const ext = mimetype.split('/')[1] || 'bin';
  const filename = `file_${Date.now()}.${ext}`;
  const res = await axios.put(`https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${filename}`, { message: `Upload ${filename}`, content: Buffer.from(buffer).toString('base64') }, { headers: { Authorization: `token ${GH_TOKEN}` } });
  return res.data.content.download_url;
}

let handler = async (m, { KazzTzy, text }) => {
    try {
        await m.react(global.react || "⏳");

        if (!m.quoted)
            return m.reply("❌ Reply foto untuk dijadikan avatar.");

        const mime = (m.quoted.msg || m.quoted).mimetype || "";
        if (!mime.startsWith("image/"))
            return m.reply("❌ Reply gambar ya.");

        if (!text)
            return m.reply("❌ Format:\n.ytcomment username|teks komentar");

        const [username, ...rest] = text.split("|");
        const comment = rest.join("|");

        if (!username || !comment)
            return m.reply("❌ Format salah.\nContoh:\n.ytcomment Agas|amel cantik");

        const buffer = await m.quoted.download();
        const avatarUrl = await uploadToGitHub(buffer, "avatar.jpg");

        const apiUrl = `https://api.deline.web.id/maker/ytcomment?text=${encodeURIComponent(comment)}&username=${encodeURIComponent(username)}&avatar=${encodeURIComponent(avatarUrl)}`;

        await KazzTzy.sendMessage(
            m.chat,
            {
                image: { url: apiUrl },
                caption: `💬 Fake YT Comment by ${username}`
            },
            { quoted: m }
        );

        await m.react(global.reactSuccess || "✅");

    } catch (e) {
        await m.react(global.reactError || "❌");
        m.reply(String(e?.response?.data || e.message || e));
    }
};

handler.help = ["ytcomment username|teks"];
handler.tags = ["maker"];
handler.command = /^(ytcomment|fakeyt)$/i;
handler.register = true;
handler.limit = true;

export default handler;
