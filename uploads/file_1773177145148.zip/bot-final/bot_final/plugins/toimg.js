import { writeFileSync, unlinkSync, existsSync, mkdirSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import sharp from 'sharp'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

let handler = async (m, { usedPrefix, command }) => {
    try {
        let q = m.quoted ? m.quoted : m
        let mime = (q.msg || q).mimetype || ''

        if (!/webp/.test(mime)) {
            return m.reply(
`✨ *TOIMAGE ENGINE*
Reply sticker untuk dikonversi menjadi gambar

Contoh:
${usedPrefix + command}`
            )
        }

        const tmpDir = join(__dirname, '../tmp')
        if (!existsSync(tmpDir)) mkdirSync(tmpDir)

        const inputPath = join(tmpDir, `${Date.now()}_sticker.webp`)
        const outputPath = join(tmpDir, `${Date.now()}_toimg.png`)

        const buffer = await q.download()
        writeFileSync(inputPath, buffer)

        await sharp(inputPath)
            .png()
            .toFile(outputPath)

        const imgBuffer = Buffer.from(await sharp(outputPath).toBuffer())

        await KazzTzy.sendMessage(m.chat, {
            image: imgBuffer,
            caption: '✨ Sticker berhasil dikonversi menjadi gambar'
        }, { quoted: m })

        unlinkSync(inputPath)
        unlinkSync(outputPath)

    } catch (err) {
        console.error(err)
        return m.reply('❌ Gagal mengubah sticker menjadi gambar.')
    }
}

handler.help = ['toimg <reply sticker>']
handler.tags = ['tools']
handler.command = /^(toimg|sticker2img|stikertoimg)$/i
handler.limit = true

export default handler