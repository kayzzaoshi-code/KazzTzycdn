import axios from "axios"

let handler = async (m, { text }) => {
  await m.react("⏳")

  try {
    const res = await axios.get("https://elaina-c-ai-chan.vercel.app/chat.html", {
      headers: {
        "User-Agent": "Mozilla/5.0"
      }
    })

    const html = res.data

    await m.reply(html.slice(0, 4000))
    await m.react("✅")

  } catch (e) {
    await m.react("❌")
    m.reply("Gagal mengambil respon")
  }
}

handler.help = ["elainatest"]
handler.tags = ["tools"]
handler.command = ["elainatest"]

export default handler