let handler = async (m, { KazzTzy, args, isOwner }) => {
  if (!m.isGroup) return m.reply("𖣂 Perintah ini hanya untuk grup.");
  if (!isOwner) return m.reply("𖣂 Hanya owner yang bisa gunakan ini.");

  const chats = global.db.data.chats;
  if (!chats[m.chat]) chats[m.chat] = {};
  const chat = chats[m.chat];
  const sub = (args[0] || "").toLowerCase();

  if (sub === "on") {
    chat.isMuted = true;
    return m.reply("╔══[ MUTE ON ]══╗\n𖣂 Bot diam di grup ini.\n𖣂 Grup lain tetap aktif.\n╚═══════════════╝");
  }

  if (sub === "off") {
    chat.isMuted = false;
    return m.reply("╔══[ MUTE OFF ]══╗\n𖣂 Bot aktif kembali di grup ini.\n╚════════════════╝");
  }

  if (sub === "list") {
    const muted = Object.entries(chats).filter(([, c]) => c?.isMuted).map(([jid]) => jid);
    if (!muted.length) return m.reply("𖣂 Tidak ada grup yang di-mute.");
    return m.reply("╔══[ MUTED GROUPS ]══╗\n\n" + muted.map((j, i) => "𖣂 " + (i + 1) + ". " + j).join("\n") + "\n\n╚════════════════════╝");
  }

  m.reply("𖣂 .mute on\n𖣂 .mute off\n𖣂 .mute list");
};

handler.before = async function (m) {
  if (!m.isGroup) return true;
  const chat = global.db.data.chats?.[m.chat];
  if (!chat?.isMuted) return true;
  const isOwner = global.owner.map(([n]) => n + "@s.whatsapp.net").includes(m.sender) || m.fromMe;
  return isOwner;
};

handler.help = ["mute [on/off/list]"];
handler.tags = ["owner"];
handler.command = /^mute$/i;
handler.owner = true;

export default handler;
