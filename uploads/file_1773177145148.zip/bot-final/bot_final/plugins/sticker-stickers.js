import { Sticker } from "wa-sticker-formatter";

let handler = async (m, { text }) => {
	let q = m.quoted ? m.quoted : m;
	let mime = (q.msg || q).mimetype || '';

	if (/image|video|webp/.test(mime)) {
		if ((q.msg?.seconds || q.seconds) > 10) return m.reply('Video harus berdurasi di bawah 10 detik.');

		let media = await q.download();
		let stickerOptions = {};
		if (text) {
			const [packname, author] = text.split(/[,|\-+&]/);
			stickerOptions = {
				pack: packname || 'KazzTzy',
				author: author || 'KazzTzy'
			};
		} else {
			stickerOptions = { pack: 'KazzTzy', author: 'KazzTzy' };
		}

		let sticker = new Sticker(media, stickerOptions);
		let buffer = await sticker.toBuffer();
		KazzTzy.sendMessage(m.chat, { sticker: buffer }, { quoted: m });
	} else {
		m.reply('Kirim atau reply media untuk dijadikan stiker.');
	}
};

handler.help = ['sticker'];
handler.tags = ['sticker'];
handler.command = /^s(tic?ker)?(gif)?$/i;
handler.register = true;

export default handler;