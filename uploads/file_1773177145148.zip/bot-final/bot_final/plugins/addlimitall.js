let handler = async (m, { text }) => {
    let limitValue = parseInt(text) || 0;

    Object.keys(global.db.data.users).forEach(jid => {
        let user = global.db.data.users[jid];
        if (!user.limit) user.limit = 0;
        user.limit += limitValue;
    });

    m.reply(`✅ Berhasil menambahkan ${limitValue} limit ke semua user`);
};

handler.help = ['addlimit <jumlah>'];
handler.tags = ['owner'];
handler.command = /^(addlimitall)$/i;
handler.rowner = true;

export default handler;