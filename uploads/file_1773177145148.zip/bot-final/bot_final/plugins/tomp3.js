import axios from 'axios';
const GH_TOKEN = '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';
const GH_OWNER = 'kayzzaoshi-code';
const GH_REPO = 'Uploader';
async function createRepo() {
  try { await axios.post('https://api.github.com/user/repos', { name: GH_REPO, private: false }, { headers: { Authorization: `token ${GH_TOKEN}` } }); } catch {}
}
async function uploadToGitHub(buffer, mimetype = 'application/octet-stream') {
  await createRepo();
  const ext = mimetype.split('/')[1] || 'bin';
  const filename = `file_${Date.now()}.${ext}`;
  const res = await axios.put(`https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${filename}`, { message: `Upload ${filename}`, content: Buffer.from(buffer).toString('base64') }, { headers: { Authorization: `token ${GH_TOKEN}` } });
  return res.data.content.download_url;
}

async function tomp3(url) {
 const h = {
  'Accept': 'application/json',
  'Content-Type': 'application/json',
  'Authorization': 'Bearer null',
  'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
  'Referer': 'https://www.freeconvert.com/mp3-converter/download'
 }

 const fname = url.split('/').pop()

 const datajob = {
  tasks: {
   import: {
    operation: "import/url",
    url: url,
    filename: fname
   },
   convert: {
    operation: "convert",
    input: "import",
    input_format: "mp4",
    output_format: "mp3",
    options: {
     audio_codec: "libmp3lame",
     audio_rate_control_mp3: "auto",
     audio_sample_rate_mp3_dts_ac3: "auto",
     audio_channel_mp3: "no-change",
     audio_filter_volume: 100,
     audio_filter_fade_in: false,
     audio_filter_fade_out: false,
     audio_filter_reverse: false
    }
   },
   "export-url": {
    operation: "export/url",
    input: "convert"
   }
  }
 }

 const procres = await axios.post('https://api.freeconvert.com/v1/process/jobs', datajob, { headers: h })
 const idjob = procres.data.id

 async function checkjobs() {
  const statsres = await axios.get(`https://api.freeconvert.com/v1/process/jobs/${idjob}`, { headers: h })

  if (statsres.data.status === 'completed') {
   const taskex = statsres.data.tasks.find(task => task.name === 'export-url')
   if (taskex?.result?.url) return taskex.result.url
   throw new Error('URL MP3 tidak ditemukan')
  }

  if (statsres.data.status === 'failed') throw new Error('Konversi gagal')

  await new Promise(resolve => setTimeout(resolve, 2000))
  return checkjobs()
 }

 return await checkjobs()
}

let handler = async (m, { KazzTzy }) => {
 try {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ''

  if (!mime.startsWith('video/')) return m.reply('Mana Videonya Bambang_-')

  await m.react(global.react || '⏳')

  const buffer = await q.download()
  const uploadUrl = await uploadToGitHub(buffer, 'video/mp4')
  const mp3Url = await tomp3(uploadUrl)

  const audioBuffer = await axios.get(mp3Url, { responseType: 'arraybuffer' })

  await KazzTzy.sendMessage(m.chat, {
   audio: audioBuffer.data,
   mimetype: 'audio/mpeg',
   ptt: true
  }, { quoted: m })

  await m.react(global.reactSuccess || '✅')

 } catch (e) {
  await m.react(global.reactError || '❌')
  m.reply(String(e.message || e))
 }
}

handler.help = ['tomp3']
handler.command = ['tomp3']
handler.tags = ['tools']
handler.limit = true
handler.register = true

export default handler
