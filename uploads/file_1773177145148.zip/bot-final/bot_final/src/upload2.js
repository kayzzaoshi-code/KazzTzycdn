import axios from "axios";
import FormData from "form-data";

const DOMAIN = "https://kayzzidgf.my.id";

export async function uploadBuffer(buffer, mimetype = "application/octet-stream") {
  const extRaw = mimetype.split("/")[1]?.split(";")[0] || "bin";
  const extMap = { mpeg: "mp3", quicktime: "mov", "octet-stream": "bin", jpeg: "jpg" };
  const ext    = extMap[extRaw] || extRaw;

  const form = new FormData();
  form.append("file", buffer, {
    filename    : `kazz_${Date.now()}.${ext}`,
    contentType : mimetype,
  });

  const headers = {
    ...form.getHeaders(),
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
  };

  const res = await axios.post(`${DOMAIN}/api/upload`, form, { headers });

  if (!res.data || !res.data.status) {
    throw new Error(res.data?.message || "Upload gagal");
  }

  return res.data.url || res.data.path;
}
