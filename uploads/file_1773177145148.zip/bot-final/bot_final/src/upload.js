import axios from "axios";

const GH_TOKEN  = "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";
const GH_OWNER  = "KazzTzyPrivat7777";
const GH_REPO   = "KazzTzySourceApiz";
const GH_BRANCH = "main";

const ghHeaders = {
  Authorization: `token ${GH_TOKEN}`,
  Accept: "application/vnd.github+json",
};

async function getFileSha(filePath) {
  try {
    const res = await axios.get(
      `https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${filePath}`,
      { headers: ghHeaders }
    );
    return res.data.sha || null;
  } catch {
    return null;
  }
}

export async function uploadBuffer(buffer, mimetype = "application/octet-stream") {
  const extRaw = mimetype.split("/")[1]?.split(";")[0] || "bin";
  const extMap = { mpeg: "mp3", quicktime: "mov", "octet-stream": "bin", jpeg: "jpg" };
  const ext    = extMap[extRaw] || extRaw;
  const fname  = `kazz_${Date.now()}.${ext}`;
  const path   = `uploads/${fname}`;

  const sha  = await getFileSha(path);
  const body = {
    message : sha ? `Update ${fname}` : `Upload ${fname}`,
    content : buffer.toString("base64"),
    branch  : GH_BRANCH,
    ...(sha && { sha }),
  };

  await axios.put(
    `https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${path}`,
    body,
    { headers: ghHeaders }
  );

  return `https://raw.githubusercontent.com/${GH_OWNER}/${GH_REPO}/${GH_BRANCH}/${path}`;
}
