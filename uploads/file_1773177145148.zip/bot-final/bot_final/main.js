//process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
import './config.js';

import { createRequire } from 'module'; // Bring in the ability to create the 'require' method
import path, { join } from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
global.__filename = function filename(pathURL = import.meta.url, rmPrefix = process.platform !== 'win32') {
	return rmPrefix ? (/file:\/\/\//.test(pathURL) ? fileURLToPath(pathURL) : pathURL) : pathToFileURL(pathURL).toString();
};
global.__dirname = function dirname(pathURL) {
	return path.dirname(global.__filename(pathURL, true));
};
global.__require = function require(dir = import.meta.url) {
	return createRequire(dir);
};

import fs from 'fs';
import { spawn } from 'child_process';
import { tmpdir } from 'os';
import { format } from 'util';
import { parentPort } from 'worker_threads';
import { makeWASocket, protoType, serialize } from './lib/simple.js';
import chalk from 'chalk';
import pino from 'pino';
import syntaxerror from 'syntax-error';
import Database from 'better-sqlite3';

import useSQLiteAuthState from './lib/useSQLite.js';

import { Browsers, fetchLatestWaWebVersion, makeCacheableSignalKeyStore } from 'baileys';

protoType();
serialize();

const __dirname = global.__dirname(import.meta.url);

global.prefix = new RegExp('^[' + '‎xzXZ/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\\-'.replace(/[|\\{}[\]()^$+*?.-]/g, '\\$&') + ']');
global.db = {
	sqlite: null,
	data: null,
};

global.loadDatabase = function () {
	if (!global.db.sqlite) {
		const dbFile = path.resolve('./data/database.db');
		fs.mkdirSync(path.dirname(dbFile), { recursive: true });

		global.db.sqlite = new Database(dbFile);
		global.db.sqlite.pragma('journal_mode = WAL');
		global.db.sqlite.pragma('synchronous = NORMAL');
		global.db.sqlite.pragma('wal_autocheckpoint = 1000');

		global.db.sqlite.exec(`
      CREATE TABLE IF NOT EXISTS database (
        id INTEGER PRIMARY KEY,
        data TEXT
      )
    `);
	}

	if (global.db.data !== null) return;

	global.db.data = {
		users: {},
		chats: {},
		stats: {},
		msgs: {},
		sticker: {},
		settings: {},
	};

	const row = global.db.sqlite.prepare('SELECT data FROM database WHERE id = 1').get();

	if (row?.data) {
		try {
			Object.assign(global.db.data, JSON.parse(row.data));
		} catch {
			console.error('[DB] JSON rusak, reset database');
		}
	} else {
		global.db.sqlite.prepare('INSERT OR IGNORE INTO database (id, data) VALUES (1, ?)').run(JSON.stringify(global.db.data));
	}
};
loadDatabase();

const { state, saveCreds } = await useSQLiteAuthState('sessions');
const { version } = await fetchLatestWaWebVersion();
const connectionOptions = {
	auth: {
		creds: state.creds,
		keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: 'fatal', stream: 'store' })),
	},
	version,
	logger: pino({ level: 'silent' }),
	browser: Browsers.ubuntu('Edge'),
	generateHighQualityLinkPreview: true,
	syncFullHistory: false,
	shouldSyncHistoryMessage: () => false,
	markOnlineOnConnect: true,
	connectTimeoutMs: 60_000,
	keepAliveIntervalMs: 30_000,
	retryRequestDelayMs: 250,
	maxMsgRetryCount: 5,
	cachedGroupMetadata: (jid) => KazzTzy.chats[jid],
};

global.KazzTzy = makeWASocket(connectionOptions);

if (!KazzTzy.authState.creds.registered) {
	console.log(chalk.bgWhite(chalk.blue('Generating code...')));
	try {
		setTimeout(async () => {
			let code = await KazzTzy.requestPairingCode(global.pairingNumber);
			code = code?.match(/.{1,4}/g)?.join('-') || code;
			console.log(chalk.cyan(`
       ⣀⣤⣤⣶⣶⣶⣶⣦⣤⡀     
       ⢀⣀⣤⣤⣄⣶⣿⠟⠛⠉   ⢀⣹⣿⡇      
    ⢀⣤⣾⣿⡟⠛⠛⠛⠉    ⠒⠒⠛⠿⠿⠿⠶⣿⣷⣢⣄⡀ 
   ⢠⣿⡟⠉⠈⣻⣦  ⣠⡴⠶⢶⣄        ⠈⠙⠻⣮⣦
  ⢰⣿⠿⣿⡶⠾⢻⡿ ⠠⣿⣄⣠⣼⣿⡇ ⠈⠒⢶⣤⣤⣤⣤⣤⣴⣾⡿
  ⣾⣿ ⠉⠛⠒⠋   ⠻⢿⣉⣠⠟     ⠉⠻⣿⣋⠙⠉⠁ 
  ⣿⡿⠷⠲⢶⣄     ⣀⣤⣤⣀       ⠙⣷⣦   
⠛⠛⢿⣅⣀⣀⣀⣿⠶⠶⠶⢤⣾⠋  ⠙⣷⣄⣀⣀⣀⣀⡀ ⠘⣿⣆  
   ⠈⠉⠉⠉⠁    ⠈⠛⠛⠶⠾⠋⠉⠉⠉⠉⠉⠉⠉⠉⠛⠛⠛⠛ 
Owner : KazzTzy
NameBot : Z4Z
=========================================
 ❖ Script by KazzTzy ❖ 
╭────────────────╼
╎You Pairing : ${code}
╰────────────────╼
			`));
		}, 3000);
	} catch (e) {
		console.log(e);
		fs.rmSync('./sessions', { recursive: true, force: true });
		parentPort.postMessage('restart');
	}
}

if (global.db) {
	setInterval(() => {
		if (global.db.data) {
			global.db.sqlite.prepare('UPDATE database SET data = ? WHERE id = 1').run(JSON.stringify(global.db.data));
		}

		if ((global.support || {}).find) {
			const tmp = [tmpdir(), 'tmp'];
			tmp.forEach((filename) => spawn('find', [filename, '-amin', '3', '-type', 'f', '-delete']));
		}
	}, 5000);
}

async function connectionUpdate(update) {
	const { receivedPendingNotifications, connection, lastDisconnect, isOnline } = update;

	if (connection === 'connecting') console.log(chalk.redBright('⚡ Mengaktifkan Bot, Mohon tunggu sebentar...'));

	if (connection === 'open') console.log(chalk.green('✅ Tersambung'));

	if (isOnline === true) console.log(chalk.green('Status Aktif'));
	else if (isOnline === false) console.log(chalk.red('Status Mati'));

	if (receivedPendingNotifications) console.log(chalk.yellow('Menunggu Pesan Baru'));

	// if (connection === 'close') console.log(chalk.red('⏱️ Koneksi terputus & mencoba menyambung ulang...'))

	const output = lastDisconnect?.error?.output;
	if (output?.payload) {
		if (output.statusCode === 401) {
			console.log(chalk.red('Session logged out. Recreate session...'));
			fs.rmSync('./sessions', { recursive: true, force: true });
			parentPort.postMessage('restart');
			return;
		} else if (output.statusCode === 403) {
			console.log(chalk.red('WhatsApp account banned :D'));
			process.exit(0);
		} else if (output.statusCode === 515) {
			console.log(chalk.yellow('Restart Required, Restarting....'));
		} else if (output.statusCode === 428) {
			console.log(chalk.yellow('Connection closed, Restarting....'));
		} else if (output.statusCode === 408) {
			console.log(chalk.yellow('Connection timed out, Restarting....'));
		} else {
			console.log(chalk.red(output.payload.message));
		}
		await global.reloadHandler(true);
	}

	if (!global.db.data) await global.loadDatabase();
}

// let strQuot = /(["'])(?:(?=(\\?))\2.)*?\1/

let isInit = true;
let handler = await import('./handler.js');
global.reloadHandler = async function (restatConn) {
	try {
		const Handler = await import(`./handler.js?update=${Date.now()}`).catch(console.error);
		if (Object.keys(Handler || {}).length) handler = Handler;
	} catch (e) {
		console.error(e);
	}
	if (restatConn) {
		const oldChats = global.KazzTzy.chats;
		try {
			global.KazzTzy.ws.close();
		} catch {}
		KazzTzy.ev.removeAllListeners();
		global.KazzTzy = makeWASocket(connectionOptions, { chats: oldChats });
		isInit = true;
	}
	if (!isInit) {
		KazzTzy.ev.off('messages.upsert', KazzTzy.handler);
		KazzTzy.ev.off('group-participants.update', KazzTzy.participantsUpdate);
		KazzTzy.ev.off('groups.update', KazzTzy.groupsUpdate);
		KazzTzy.ev.off('message.delete', KazzTzy.onDelete);
		KazzTzy.ev.off('connection.update', KazzTzy.connectionUpdate);
		KazzTzy.ev.off('creds.update', KazzTzy.credsUpdate);
	}

	KazzTzy.welcome =
		'✦━━━━━━[ *WELCOME* ]━━━━━━✦\n\n┏––––––━━━━━━━━•\n│⫹⫺ @subject\n┣━━━━━━━━┅┅┅\n│( 👋 Hallo @user)\n├[ *INTRO* ]—\n│ *Nama:* \n│ *Umur:* \n│ *Gender:*\n┗––––––━━┅┅┅\n\n––––––┅┅ *DESCRIPTION* ┅┅––––––\n@desc';
	KazzTzy.bye = '✦━━━━━━[ *GOOD BYE* ]━━━━━━✦\nSayonara *@user* 👋( ╹▽╹ )';
	KazzTzy.spromote = '@user sekarang admin!';
	KazzTzy.sdemote = '@user sekarang bukan admin!';
	KazzTzy.sDesc = 'Deskripsi telah diubah ke \n@desc';
	KazzTzy.sSubject = 'Judul grup telah diubah ke \n@subject';
	KazzTzy.sIcon = 'Icon grup telah diubah!';
	KazzTzy.sRevoke = 'Link group telah diubah ke \n@revoke';
	KazzTzy.handler = handler.handler.bind(global.KazzTzy);
	KazzTzy.participantsUpdate = handler.participantsUpdate.bind(global.KazzTzy);
	KazzTzy.groupsUpdate = handler.groupsUpdate.bind(global.KazzTzy);
	KazzTzy.onDelete = handler.deleteUpdate.bind(global.KazzTzy);
	KazzTzy.connectionUpdate = connectionUpdate.bind(global.KazzTzy);
	KazzTzy.credsUpdate = saveCreds.bind(global.KazzTzy);

	KazzTzy.ev.on('call', async (calls) => {
		for (const call of calls) {
			const { id, from, status } = call;
			const settings = global.db.data.settings[KazzTzy.user.jid];
			if (status === 'offer' && settings.anticall) {
				await KazzTzy.rejectCall(id, from);
				console.log('Menolak panggilan dari', from);
			}
		}
	});

	KazzTzy.ev.on('messages.upsert', KazzTzy.handler);
	KazzTzy.ev.on('group-participants.update', KazzTzy.participantsUpdate);
	KazzTzy.ev.on('groups.update', KazzTzy.groupsUpdate);
	KazzTzy.ev.on('message.delete', KazzTzy.onDelete);
	KazzTzy.ev.on('connection.update', KazzTzy.connectionUpdate);
	KazzTzy.ev.on('creds.update', KazzTzy.credsUpdate);
	isInit = false;
	return true;
};

const pluginFolder = global.__dirname(join(__dirname, './plugins/index'));
const pluginFilter = (filename) => /\.js$/.test(filename);
global.plugins = {};

async function filesInit() {
	for (let filename of fs.readdirSync(pluginFolder).filter(pluginFilter)) {
		try {
			let file = global.__filename(join(pluginFolder, filename));
			const module = await import(file);
			global.plugins[filename] = module.default || module;
		} catch (e) {
			KazzTzy.logger.error(`❌ Failed to load plugins ${filename}: ${e}`);
			delete global.plugins[filename];
		}
	}
}
filesInit()
	.then((_) => console.log(`Successfully Loaded ${Object.keys(global.plugins).length} Plugins`))
	.catch(console.error);

global.reload = async (_ev, filename) => {
	if (pluginFilter(filename)) {
		let dir = global.__filename(join(pluginFolder, filename), true);
		if (filename in global.plugins) {
			if (fs.existsSync(dir)) KazzTzy.logger.info(`re - require plugin '${filename}'`);
			else {
				KazzTzy.logger.warn(`deleted plugin '${filename}'`);
				return delete global.plugins[filename];
			}
		} else KazzTzy.logger.info(`requiring new plugin '${filename}'`);
		let err = syntaxerror(fs.readFileSync(dir), filename, {
			sourceType: 'module',
			allowAwaitOutsideFunction: true,
		});
		if (err) KazzTzy.logger.error(`syntax error while loading '${filename}'\n${format(err)}`);
		else
			try {
				const module = await import(`${global.__filename(dir)}?update=${Date.now()}`);
				global.plugins[filename] = module.default || module;
			} catch (e) {
				KazzTzy.logger.error(`error require plugin '${filename}\n${format(e)}'`);
			} finally {
				global.plugins = Object.fromEntries(Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b)));
			}
	}
};
Object.freeze(global.reload);
fs.watch(pluginFolder, global.reload);
await global.reloadHandler();

// Quick Test
async function _quickTest() {
	let test = await Promise.all(
		[
			spawn('ffmpeg'),
			spawn('ffprobe'),
			spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-filter_complex', 'color', '-frames:v', '1', '-f', 'webp', '-']),
			spawn('convert'),
			spawn('magick'),
			spawn('gm'),
			spawn('find', ['--version']),
		].map((p) => {
			return Promise.race([
				new Promise((resolve) => {
					p.on('close', (code) => {
						resolve(code !== 127);
					});
				}),
				new Promise((resolve) => {
					p.on('error', (_) => resolve(false));
				}),
			]);
		})
	);
	let [ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find] = test;
	//console.log(test)
	let s = (global.support = {
		ffmpeg,
		ffprobe,
		ffmpegWebp,
		convert,
		magick,
		gm,
		find,
	});
	// require('./lib/sticker').support = s
	Object.freeze(global.support);

	if (!s.ffmpeg) KazzTzy.logger.warn('Please install ffmpeg for sending videos (apt install ffmpeg)');
	if (s.ffmpeg && !s.ffmpegWebp) KazzTzy.logger.warn('Stickers may not animated without libwebp on ffmpeg (--enable-ibwebp while compiling ffmpeg)');
	if (!s.convert && !s.magick && !s.gm) KazzTzy.logger.warn('Stickers may not work without imagemagick if libwebp on ffmpeg doesnt isntalled (apt install imagemagick)');
}

_quickTest()
	.then(() => KazzTzy.logger.info('☑️ Quick Test Done'))
	.catch(console.error);

function closeDB() {
	try {
		global.db.sqlite.close();
		console.log('Database closed');
	} catch (e) {
		console.error(e);
	}
}
process.on('uncaughtException', console.error);
process.on('exit', closeDB);
process.on('SIGINT', closeDB);
process.on('SIGTERM', closeDB);
