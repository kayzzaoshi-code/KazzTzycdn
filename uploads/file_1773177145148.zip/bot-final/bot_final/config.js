import { watchFile, unwatchFile } from 'fs';
import chalk from 'chalk';
import { fileURLToPath } from 'url';

global.pairingNumber = 6283142277149;
global.owner = [['6283167295612', 'KazzTzy', true]];

global.namebot = 'Z4Z';
global.author = 'KazzTzy';
global.source = 'https://chat.whatsapp.com/LF76mRDRwLlI4pdbMi0d5A?mode=hqrc';

global.wait = 'Loading...';
global.eror = 'Terjadi Kesalahan...';

global.pakasir = {
	slug: 'kilersbotz',
	apikey: 'bWDO2M8GcfruzXscdKNQJC3vw8Y8PV13',
	expired: 30, //1 = 1menit. 30 = 30menit
};

// config.js
global.APIs = {
    kayzz: "kayzzidgf.my.id"
}

global.APIKeys = {
    "https://kayzzidgf.my.id": "ygddoshama"
}

global.APIs = { kayzz: "https://kayzzidgf.my.id" }
global.APIKeys = { "https://kayzzidgf.my.id": "yangddoshama" }
global.thumbnail = "https://raw.githubusercontent.com/kayzzaoshi-code/Uploader/main/file_1771783298362.jpeg"
global.mediaUrl = "https://chat.whatsapp.com/LYWuk6aQXUuGfgcDrzL5Ah"
global.sourceUrl = "https://wa.me/6285795269956"
global.errorTitle = "❌ Format Salah..."
global.errorBody = "Harap masukkan teks nya"
global.react = '⏳'
global.reactSuccess = '✅'
global.reactError = '❌'

global.stickpack = 'Croted By';
global.stickauth = namebot;

global.multiplier = 38; // The higher, The harder levelup

/*============== EMOJI ==============*/
global.rpg = {
	emoticon(string) {
		string = string.toLowerCase();
		let emot = {
			level: '📊',
			limit: '🎫',
			health: '❤️',
			stamina: '🔋',
			exp: '✨',
			money: '💹',
			bank: '🏦',
			potion: '🥤',
			diamond: '💎',
			common: '📦',
			uncommon: '🛍️',
			mythic: '🎁',
			legendary: '🗃️',
			superior: '💼',
			pet: '🔖',
			trash: '🗑',
			armor: '🥼',
			sword: '⚔️',
			pickaxe: '⛏️',
			fishingrod: '🎣',
			wood: '🪵',
			rock: '🪨',
			string: '🕸️',
			horse: '🐴',
			cat: '🐱',
			dog: '🐶',
			fox: '🦊',
			petFood: '🍖',
			iron: '⛓️',
			gold: '🪙',
			emerald: '❇️',
			upgrader: '🧰',
		};
		let results = Object.keys(emot)
			.map((v) => [v, new RegExp(v, 'gi')])
			.filter((v) => v[1].test(string));
		if (!results.length) return '';
		else return emot[results[0][0]];
	},
};

let file = fileURLToPath(import.meta.url);
watchFile(file, () => {
	unwatchFile(file);
	console.log(chalk.redBright("Update 'config.js'"));
	import(`${file}?update=${Date.now()}`);
});
